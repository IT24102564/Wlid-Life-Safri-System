-- WildTrack Database Setup Script
-- Run this in MySQL Workbench before starting the application
-- MySQL Credentials: username=root, password=nimesh5741

-- Create database if it doesn't exist
CREATE DATABASE IF NOT EXISTS wildtrack_db;
USE wildtrack_db;

-- Grant privileges to root user
GRANT ALL PRIVILEGES ON wildtrack_db.* TO 'root'@'localhost';
FLUSH PRIVILEGES;

-- Verify connection
SELECT 'Database wildtrack_db created successfully!' as status;

-- Optional: Create tables manually (Spring Boot will auto-create them)
-- But this ensures the database is accessible

-- Test table creation
CREATE TABLE IF NOT EXISTS test_connection (
    id INT AUTO_INCREMENT PRIMARY KEY,
    message VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO test_connection (message) VALUES ('Database connection successful!');

SELECT * FROM test_connection;

-- Clean up test table
DROP TABLE test_connection;

-- Show database info
SHOW DATABASES;
SELECT DATABASE() as current_database;
