# 🚗 Tour Crew Manager System - Complete Guide

## 📋 Overview

The Tour Crew Manager system is a comprehensive resource allocation module that manages drivers, guides, and jeeps for confirmed safari bookings. It acts as the bridge between booking confirmation and final resource assignment.

---

## 🔐 Login Credentials

```
📧 Email: tourmanager@wildtrack.com
🔑 Password: tour123
🔒 Role: TOUR_MANAGER
🌐 Dashboard: http://localhost:8080/tour-crew-manager/dashboard
```

---

## 🔄 Complete Booking Workflow

### **Step 1: Tourist Creates Booking**
- Tourist selects package and creates booking
- **Status**: `PENDING`
- Appears on Booking Officer dashboard

### **Step 2: Booking Officer Approves**
- Booking Officer reviews and approves booking
- **Status**: `PENDING` → `CONFIRMED`
- Appears on Tour Crew Manager dashboard

### **Step 3: Tour Crew Manager Allocates Resources**
- Tour Crew Manager assigns:
  - 🚗 Driver
  - 👨‍🏫 Guide
  - 🚙 Jeep
- **Status**: `CONFIRMED` → `ALLOCATED`
- Resources saved to booking record
- Booking Officer is notified

### **Step 4: Final Confirmation**
- Booking Officer sees allocated resources
- Can proceed with final confirmation to tourist
- **Status**: `ALLOCATED` → `COMPLETED` (after safari)

---

## 🎯 Tour Crew Manager Features

### **1. Dashboard** (`/tour-crew-manager/dashboard`)

#### **Statistics Overview:**
- ⏳ Awaiting Allocation - Confirmed bookings needing resources
- ✅ Allocated - Bookings with assigned resources
- 📅 Today's Safaris - Safaris scheduled for today
- 🚗 Available Drivers - Total drivers in system
- 👨‍🏫 Available Guides - Guides marked as available
- 🚙 Available Jeeps - Jeeps marked as available

#### **Confirmed Bookings Section:**
- Shows all bookings with `CONFIRMED` status
- Displays booking details:
  - Tourist name and contact
  - Package details
  - Safari date
  - Number of guests
  - Total price
  - Booking timestamp

#### **Resource Allocation Form:**
For each confirmed booking:
- **Select Driver** - Dropdown of all drivers
- **Select Guide** - Dropdown of available guides only
- **Select Jeep** - Dropdown of available jeeps only
- **Notes** - Optional special instructions
- **Allocate Button** - Assigns resources and updates status

#### **Today's Allocated Safaris:**
- Table showing today's safaris with assigned resources
- Displays driver, guide, jeep for each booking

#### **Recent Allocations:**
- Last 10 allocated bookings
- Shows allocation timestamp
- Quick reference for recent work

---

### **2. Resource Management** (`/tour-crew-manager/resources`)

Complete CRUD operations for all resources:

#### **🚗 Driver Management**

**Create Driver:**
- Full Name
- Email (must be unique)
- Phone
- License Number
- Auto-assigned DRIVER role

**View Drivers:**
- Table with all drivers
- Shows ID, name, email, phone

**Delete Driver:**
- Remove driver from system
- Confirmation required

#### **👨‍🏫 Guide Management**

**Create Guide:**
- Name
- Phone
- Experience (e.g., "5 years")
- Availability status (Yes/No)

**Update Guide:**
- Edit all guide details
- Change availability status

**Toggle Availability:**
- Quick switch between Available/Unavailable
- Visual status badge

**Delete Guide:**
- Remove guide from system
- Confirmation required

#### **🚙 Jeep Management**

**Create Jeep:**
- Registration Number (e.g., "ABC-1234")
- Model (e.g., "Toyota Land Cruiser")
- Capacity (number of passengers)
- Availability status (Yes/No)

**Update Jeep:**
- Edit all jeep details
- Change availability status

**Toggle Availability:**
- Quick switch between Available/Unavailable
- Visual status badge

**Delete Jeep:**
- Remove jeep from system
- Confirmation required

---

## 🗄️ Database Schema

### **Booking Table Updates**
```sql
ALTER TABLE bookings ADD COLUMN driver_id BIGINT;
ALTER TABLE bookings ADD CONSTRAINT fk_booking_driver 
    FOREIGN KEY (driver_id) REFERENCES users(id);
```

### **Resource Allocations Table**
```sql
CREATE TABLE resource_allocations (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    booking_id BIGINT NOT NULL UNIQUE,
    driver_id BIGINT,
    guide_id BIGINT,
    jeep_id BIGINT,
    allocated_by BIGINT,
    allocated_at DATETIME,
    notes TEXT,
    driver_notified BOOLEAN DEFAULT FALSE,
    guide_notified BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (booking_id) REFERENCES bookings(id),
    FOREIGN KEY (driver_id) REFERENCES users(id),
    FOREIGN KEY (guide_id) REFERENCES guides(id),
    FOREIGN KEY (jeep_id) REFERENCES jeeps(id),
    FOREIGN KEY (allocated_by) REFERENCES users(id)
);
```

---

## 📊 Booking Officer Integration

### **Updated Dashboard Features:**

#### **New Statistics:**
- 🚗 Resources Allocated - Count of ALLOCATED bookings

#### **Allocated Bookings Section:**
- Shows all bookings with `ALLOCATED` status
- Displays assigned resources:
  - **Driver** - Full name
  - **Guide** - Name
  - **Jeep** - Registration number
- Sorted by most recent allocation first

#### **Workflow:**
1. Booking Officer approves booking → Status: `CONFIRMED`
2. Tour Crew Manager allocates resources → Status: `ALLOCATED`
3. Booking Officer sees allocated resources
4. Booking Officer can proceed with final confirmation

---

## 🔒 Security & Access Control

### **Role-Based Access:**
- Only users with `TOUR_MANAGER` role can access
- Automatic redirect to `/tour-crew-manager/dashboard` on login
- Protected routes: `/tour-crew-manager/**`

### **Authentication:**
```java
@GetMapping("/dashboard")
public String dashboard(Authentication auth, Model model) {
    // Verify TOUR_MANAGER role
    boolean hasRole = auth.getAuthorities().stream()
        .anyMatch(a -> a.getAuthority().equals("ROLE_TOUR_MANAGER"));
    
    if (!hasRole) {
        return "redirect:/safe-dashboard";
    }
    // ... dashboard logic
}
```

---

## 🎨 User Interface

### **Dashboard Design:**
- Clean, modern interface
- Color-coded statistics
- Responsive grid layout
- Real-time availability indicators
- Success/error notifications
- Confirmation dialogs for destructive actions

### **Resource Management:**
- Tabbed interface (Drivers | Guides | Jeeps)
- Inline forms for quick creation
- Table view with action buttons
- Visual availability badges
- Responsive design

---

## 🔔 Notifications

### **Current Implementation:**
- Success messages on allocation
- Error messages for validation failures
- Availability checks before allocation

### **Future Enhancements:**
- Email notifications to drivers
- SMS notifications to guides
- Dashboard notifications for Booking Officer
- Real-time updates using WebSockets

---

## 📝 Business Logic

### **Resource Allocation Rules:**

1. **Booking Status Validation:**
   - Only `CONFIRMED` bookings can be allocated
   - Cannot allocate to already allocated bookings

2. **Resource Availability:**
   - Guides must be marked as `available`
   - Jeeps must be marked as `available`
   - Drivers can be any user with DRIVER role

3. **Allocation Process:**
   - Create `ResourceAllocation` record
   - Update `Booking` with driver, guide, jeep
   - Change booking status to `ALLOCATED`
   - Set allocation timestamp
   - Record allocating manager

4. **Data Integrity:**
   - One allocation per booking (unique constraint)
   - Foreign key constraints ensure referential integrity
   - Transactional operations prevent partial updates

---

## 🚀 API Endpoints

### **Dashboard:**
- `GET /tour-crew-manager/dashboard` - Main dashboard
- `POST /tour-crew-manager/allocate` - Allocate resources
- `GET /tour-crew-manager/allocation-details/{bookingId}` - Get allocation details

### **Resource Management:**
- `GET /tour-crew-manager/resources` - Resource management page

### **Driver Operations:**
- `POST /tour-crew-manager/driver/create` - Create driver
- `POST /tour-crew-manager/driver/delete/{id}` - Delete driver

### **Guide Operations:**
- `POST /tour-crew-manager/guide/create` - Create guide
- `POST /tour-crew-manager/guide/update/{id}` - Update guide
- `POST /tour-crew-manager/guide/toggle-availability/{id}` - Toggle availability
- `POST /tour-crew-manager/guide/delete/{id}` - Delete guide

### **Jeep Operations:**
- `POST /tour-crew-manager/jeep/create` - Create jeep
- `POST /tour-crew-manager/jeep/update/{id}` - Update jeep
- `POST /tour-crew-manager/jeep/toggle-availability/{id}` - Toggle availability
- `POST /tour-crew-manager/jeep/delete/{id}` - Delete jeep

---

## 🧪 Testing Workflow

### **Complete End-to-End Test:**

1. **Login as Tourist** (`user123@gmail.com` / `user123`)
   - Browse packages
   - Create a booking for future date
   - Status should be `PENDING`

2. **Login as Booking Officer** (`bookingofficer@wildtrack.com` / `booking123`)
   - See pending booking
   - Approve the booking
   - Status changes to `CONFIRMED`

3. **Login as Tour Crew Manager** (`tourmanager@wildtrack.com` / `tour123`)
   - See confirmed booking in dashboard
   - Go to Resource Management
   - Create driver, guide, jeep if needed
   - Return to dashboard
   - Allocate resources to the booking
   - Status changes to `ALLOCATED`

4. **Login as Booking Officer** (again)
   - See allocated booking with resources
   - View driver, guide, jeep assignments
   - Proceed with final confirmation

---

## 📈 Statistics & Reporting

### **Dashboard Metrics:**
- Total confirmed bookings awaiting allocation
- Total allocated bookings
- Today's safari count
- Resource availability counts
- Recent allocation history

### **Resource Utilization:**
- Active drivers count
- Available vs. unavailable guides
- Available vs. unavailable jeeps
- Allocation trends

---

## 🛠️ Troubleshooting

### **Common Issues:**

**Issue: "Booking must be CONFIRMED before allocation"**
- Solution: Ensure Booking Officer has approved the booking first

**Issue: "Selected guide is not available"**
- Solution: Go to Resource Management and mark guide as available

**Issue: "Selected jeep is not available"**
- Solution: Go to Resource Management and mark jeep as available

**Issue: "Resources already allocated for this booking"**
- Solution: Booking has already been allocated, check allocated bookings list

**Issue: "Email already exists" when creating driver**
- Solution: Use a unique email address for each driver

---

## 🎯 Best Practices

1. **Resource Management:**
   - Keep resource availability updated
   - Mark resources unavailable when under maintenance
   - Regularly review and clean up unused resources

2. **Allocation Process:**
   - Check safari date before allocating
   - Verify guest count matches jeep capacity
   - Add notes for special requirements
   - Double-check allocations before confirming

3. **Data Integrity:**
   - Don't delete resources that have active allocations
   - Keep driver contact information updated
   - Maintain accurate guide experience records

---

## 📞 Support

For issues or questions:
- Check application logs for detailed error messages
- Review booking status in database
- Verify resource availability
- Contact system administrator

---

## 🎉 Summary

The Tour Crew Manager system provides:
- ✅ Complete resource allocation workflow
- ✅ Full CRUD operations for drivers, guides, jeeps
- ✅ Real-time availability tracking
- ✅ Integration with Booking Officer dashboard
- ✅ Secure role-based access control
- ✅ Clean, intuitive user interface
- ✅ Comprehensive booking status management

**Login and start managing your safari resources today!** 🚗🦁
