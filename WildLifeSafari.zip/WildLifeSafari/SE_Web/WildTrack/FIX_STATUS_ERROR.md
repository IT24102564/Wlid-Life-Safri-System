# 🔧 Fix: "Data truncated for column 'status'" Error

## ❌ **Error Message:**
```
❌ Error: could not execute statement [Data truncated for column 'status' at row 1]
```

## 🐛 **Root Cause:**

The database column `status` in the `bookings` table is too small (probably VARCHAR(20) or less) to store the new enum value `PENDING_USER_CONFIRMATION` which is 27 characters long.

---

## ✅ **Solution:**

### **Step 1: Run SQL Migration Script**

Open MySQL Workbench and run this script:

```sql
USE wildtrack_db;

-- Alter the status column to accommodate longer enum values
ALTER TABLE bookings 
MODIFY COLUMN status VARCHAR(50);

-- Verify the change
DESCRIBE bookings;

SELECT 'Status column updated successfully!' as message;
```

**OR** run the provided file:
```
File: database-migration-fix-status.sql
Location: c:/Users/nimes/OneDrive/Desktop/SE_Web/WildTrack/
```

### **Step 2: Restart Application**

After running the SQL script:
1. Stop your Spring Boot application
2. Restart it
3. The error should be gone

---

## 📋 **What Was Changed:**

### **1. Booking.java Model**
Added column length specification:
```java
@Enumerated(EnumType.STRING)
@Column(length = 50)  // ← ADDED THIS
private BookingStatus status;
```

### **2. Database Schema**
Changed column definition:
```sql
-- Before:
status VARCHAR(20)  -- Too small!

-- After:
status VARCHAR(50)  -- Can fit all enum values
```

---

## 🔄 **All Booking Status Values:**

| Status | Length | Fits in VARCHAR(50)? |
|--------|--------|---------------------|
| PENDING | 7 chars | ✅ Yes |
| PENDING_USER_CONFIRMATION | 27 chars | ✅ Yes (was too long for VARCHAR(20)) |
| CONFIRMED | 9 chars | ✅ Yes |
| ALLOCATED | 9 chars | ✅ Yes |
| CANCEL_PENDING | 14 chars | ✅ Yes |
| CANCELLED | 9 chars | ✅ Yes |
| COMPLETED | 9 chars | ✅ Yes |

---

## 🧪 **How to Test After Fix:**

### **Test 1: Modify Allocation**
```
1. Login as Booking Officer
2. Send allocation request to Tour Crew Manager
3. Login as Tour Crew Manager
4. Click "Modify"
5. Select different resources
6. Add explanation
7. Submit
8. ✅ Should work without error
9. ✅ Booking status should be PENDING_USER_CONFIRMATION
```

### **Test 2: Verify Database**
```sql
USE wildtrack_db;

-- Check column definition
DESCRIBE bookings;
-- Should show: status varchar(50)

-- Check actual data
SELECT id, status, safari_date FROM bookings;
-- Should show PENDING_USER_CONFIRMATION without truncation
```

---

## 🚨 **If Error Still Occurs:**

### **Option 1: Manual Database Update**
```sql
USE wildtrack_db;

-- Drop and recreate the table (WARNING: Deletes data!)
DROP TABLE IF EXISTS bookings;

-- Restart application - Spring Boot will recreate with correct schema
```

### **Option 2: Force Schema Update**
In `application.properties`, temporarily change:
```properties
# Change from:
spring.jpa.hibernate.ddl-auto=update

# To:
spring.jpa.hibernate.ddl-auto=create-drop
```

**⚠️ WARNING:** This will delete all data! Only use for testing.

After restart, change back to:
```properties
spring.jpa.hibernate.ddl-auto=update
```

---

## 📝 **Additional Fix: Driver Field**

The error also mentions `driver_id`. Make sure the `driver` field is properly configured:

### **In Booking.java:**
```java
@ManyToOne(fetch = FetchType.EAGER)
@JoinColumn(name = "driver_id")
private User driver;
```

### **In Database:**
```sql
-- Check if driver_id column exists
DESCRIBE bookings;

-- If missing, add it:
ALTER TABLE bookings 
ADD COLUMN driver_id BIGINT,
ADD CONSTRAINT fk_booking_driver 
FOREIGN KEY (driver_id) REFERENCES users(id);
```

---

## ✅ **Complete Fix Checklist:**

- [ ] Run SQL migration script to increase status column size
- [ ] Verify column changed: `DESCRIBE bookings;`
- [ ] Restart Spring Boot application
- [ ] Test Tour Crew Manager modify function
- [ ] Verify no truncation error
- [ ] Check booking status in database
- [ ] Test complete workflow

---

## 🎯 **Expected Result After Fix:**

### **Before Fix:**
```
❌ Error: Data truncated for column 'status'
❌ Modify function fails
❌ Cannot set PENDING_USER_CONFIRMATION status
```

### **After Fix:**
```
✅ No truncation error
✅ Modify function works
✅ Status saved as PENDING_USER_CONFIRMATION
✅ Complete workflow functional
```

---

## 🚀 **Quick Fix Command:**

Run this in MySQL Workbench:
```sql
USE wildtrack_db;
ALTER TABLE bookings MODIFY COLUMN status VARCHAR(50);
```

Then restart your application.

**That's it! Error should be fixed.** 🎉
