-- Update the role column to accommodate longer role names like PACKAGE_BUILDER
-- Run this SQL script in your MySQL database

USE wildtrack_db;

-- First, let's see what tables exist
SHOW TABLES;

-- Check the structure of user_roles table
DESCRIBE user_roles;

-- Check current data in user_roles
SELECT * FROM user_roles;

-- Now alter the role column to VARCHAR(50)
-- Try different variations in case the column name is different
ALTER TABLE user_roles MODIFY role VARCHAR(50) NOT NULL;

-- Verify the change
DESCRIBE user_roles;

-- Display success message
SELECT 'Role column updated successfully! Can now store PACKAGE_BUILDER role.' AS Status;
