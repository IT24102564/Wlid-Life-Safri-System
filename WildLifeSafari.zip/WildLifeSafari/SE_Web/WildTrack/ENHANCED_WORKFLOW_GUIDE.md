# 🔄 Enhanced Resource Allocation Workflow - Complete Guide

## 📋 Overview

The enhanced workflow creates a **request-approval system** between Booking Officer and Tour Crew Manager for resource allocation.

---

## 🔄 Complete Workflow

### **Step 1: Tourist Creates Booking**
- Tourist selects package and creates booking
- **Status**: `PENDING`
- Appears on Booking Officer dashboard

### **Step 2: Booking Officer Approves Booking**
- Booking Officer reviews and approves booking
- **Status**: `PENDING` → `CONFIRMED`
- Booking now ready for resource allocation

### **Step 3: Booking Officer Creates Allocation Request (CHECK)**
- Booking Officer clicks **"Check Allocation"** button
- Selects desired resources:
  - 🚗 Driver
  - 👨‍🏫 Guide
  - 🚙 Jeep
- Adds optional notes
- **Allocation Status**: `PENDING_APPROVAL`
- Request sent to Tour Crew Manager

### **Step 4: Tour Crew Manager Reviews Request**
Tour Crew Manager has **3 options**:

#### **Option A: APPROVE (Resources Available)**
- Reviews requested resources
- All resources are available
- Clicks **"✅ Approve"**
- **Allocation Status**: `APPROVED`
- **Booking Status**: `ALLOCATED`
- Booking Officer notified

#### **Option B: MODIFY (Different Resources Needed)**
- Reviews requested resources
- Some resources unavailable
- Selects alternative resources
- Clicks **"✏️ Modify & Approve"**
- **Allocation Status**: `MODIFIED`
- **Booking Status**: `ALLOCATED`
- Booking Officer sees modified resources

#### **Option C: REJECT (No Resources Available)**
- Reviews requested resources
- No suitable resources available
- Provides rejection reason
- Clicks **"❌ Reject"**
- **Allocation Status**: `REJECTED`
- **Booking Status**: Remains `CONFIRMED`
- Booking Officer can create new request

### **Step 5: Booking Officer Views Response**
- Sees allocation status on dashboard
- **If APPROVED**: Sees approved resources
- **If MODIFIED**: Sees what was changed
- **If REJECTED**: Sees rejection reason
- Can proceed with final confirmation

---

## 🎯 Key Features

### **For Booking Officer:**

1. **Check Allocation Button**
   - Available for CONFIRMED bookings
   - Opens form to select resources
   - Creates allocation request

2. **Allocation Status Tracking**
   - **Pending**: Waiting for Tour Crew Manager
   - **Approved**: Resources confirmed as requested
   - **Modified**: Resources changed by manager
   - **Rejected**: Request denied with reason

3. **Dashboard Sections:**
   - ⏳ Pending Allocation Requests
   - ✅ Approved Allocations
   - ✏️ Modified Allocations
   - ❌ Rejected Allocations

### **For Tour Crew Manager:**

1. **Pending Requests Queue**
   - Shows all allocation requests
   - Displays requested resources
   - Shows booking details
   - Booking Officer notes visible

2. **Action Buttons:**
   - **✅ Approve** - Accept as-is
   - **✏️ Modify** - Change resources
   - **❌ Reject** - Decline request

3. **Resource Availability Check**
   - Real-time availability status
   - Can view all drivers, guides, jeeps
   - Toggle availability as needed

---

## 📊 Database Schema

### **ResourceAllocation Table**
```sql
CREATE TABLE resource_allocations (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    booking_id BIGINT NOT NULL UNIQUE,
    
    -- Requested by Booking Officer
    requested_driver_id BIGINT,
    requested_guide_id BIGINT,
    requested_jeep_id BIGINT,
    requested_by BIGINT,
    requested_at DATETIME,
    officer_notes TEXT,
    
    -- Approved/Modified by Tour Crew Manager
    approved_driver_id BIGINT,
    approved_guide_id BIGINT,
    approved_jeep_id BIGINT,
    reviewed_by BIGINT,
    reviewed_at DATETIME,
    manager_notes TEXT,
    
    -- Status tracking
    status VARCHAR(50), -- PENDING_APPROVAL, APPROVED, REJECTED, MODIFIED
    rejection_reason TEXT,
    
    FOREIGN KEY (booking_id) REFERENCES bookings(id),
    FOREIGN KEY (requested_driver_id) REFERENCES users(id),
    FOREIGN KEY (requested_guide_id) REFERENCES guides(id),
    FOREIGN KEY (requested_jeep_id) REFERENCES jeeps(id),
    FOREIGN KEY (approved_driver_id) REFERENCES users(id),
    FOREIGN KEY (approved_guide_id) REFERENCES guides(id),
    FOREIGN KEY (approved_jeep_id) REFERENCES jeeps(id),
    FOREIGN KEY (requested_by) REFERENCES users(id),
    FOREIGN KEY (reviewed_by) REFERENCES users(id)
);
```

---

## 🔌 API Endpoints

### **Booking Officer Endpoints:**

```
POST /booking-officer/check-allocation/{bookingId}
Parameters:
  - driverId: Long
  - guideId: Long
  - jeepId: Long
  - notes: String (optional)
Response: Redirect to dashboard with success message
```

### **Tour Crew Manager Endpoints:**

```
POST /tour-crew-manager/approve-allocation/{allocationId}
Parameters:
  - notes: String (optional)
Response: Redirect to dashboard with success message

POST /tour-crew-manager/modify-allocation/{allocationId}
Parameters:
  - driverId: Long
  - guideId: Long
  - jeepId: Long
  - notes: String (optional)
Response: Redirect to dashboard with success message

POST /tour-crew-manager/reject-allocation/{allocationId}
Parameters:
  - reason: String (required)
Response: Redirect to dashboard with success message
```

---

## 💡 Usage Examples

### **Example 1: Successful Approval**

1. **Booking Officer**:
   ```
   Booking #123 - Safari on 2025-01-15
   Selects: Driver John, Guide Sarah, Jeep ABC-1234
   Clicks "Check Allocation"
   ```

2. **Tour Crew Manager**:
   ```
   Sees request for Booking #123
   Checks availability - All available ✅
   Clicks "Approve"
   ```

3. **Booking Officer**:
   ```
   Sees: "✅ APPROVED"
   Driver: John
   Guide: Sarah
   Jeep: ABC-1234
   ```

### **Example 2: Modified Allocation**

1. **Booking Officer**:
   ```
   Booking #124 - Safari on 2025-01-16
   Selects: Driver Mike, Guide Tom, Jeep XYZ-5678
   Clicks "Check Allocation"
   ```

2. **Tour Crew Manager**:
   ```
   Sees request for Booking #124
   Checks: Mike unavailable, Tom available, XYZ-5678 available
   Selects alternative: Driver Jane
   Clicks "Modify & Approve"
   Notes: "Mike on leave, assigned Jane instead"
   ```

3. **Booking Officer**:
   ```
   Sees: "✏️ MODIFIED"
   Requested: Driver Mike
   Approved: Driver Jane ⚠️
   Guide: Tom ✅
   Jeep: XYZ-5678 ✅
   Manager Notes: "Mike on leave, assigned Jane instead"
   ```

### **Example 3: Rejected Request**

1. **Booking Officer**:
   ```
   Booking #125 - Safari on 2025-01-17
   Selects: Driver Alex, Guide Lisa, Jeep DEF-9012
   Clicks "Check Allocation"
   ```

2. **Tour Crew Manager**:
   ```
   Sees request for Booking #125
   Checks: All resources unavailable
   Clicks "Reject"
   Reason: "All jeeps under maintenance on this date"
   ```

3. **Booking Officer**:
   ```
   Sees: "❌ REJECTED"
   Reason: "All jeeps under maintenance on this date"
   Can create new request with different date
   ```

---

## 🎨 UI Components

### **Booking Officer Dashboard - New Sections:**

1. **Confirmed Bookings with Check Button**
```html
<div class="booking-card">
    <h4>Booking #123</h4>
    <form action="/booking-officer/check-allocation/123" method="post">
        <select name="driverId">...</select>
        <select name="guideId">...</select>
        <select name="jeepId">...</select>
        <textarea name="notes"></textarea>
        <button>🔍 Check Allocation</button>
    </form>
</div>
```

2. **Allocation Status Display**
```html
<div class="allocation-status approved">
    <span class="badge">✅ APPROVED</span>
    <p>Driver: John Doe</p>
    <p>Guide: Sarah Smith</p>
    <p>Jeep: ABC-1234</p>
</div>

<div class="allocation-status modified">
    <span class="badge">✏️ MODIFIED</span>
    <p>Requested Driver: Mike → Approved: Jane ⚠️</p>
    <p>Manager Notes: Mike on leave</p>
</div>

<div class="allocation-status rejected">
    <span class="badge">❌ REJECTED</span>
    <p>Reason: All jeeps under maintenance</p>
</div>
```

### **Tour Crew Manager Dashboard - New Section:**

```html
<div class="pending-request">
    <h4>Allocation Request #45</h4>
    <p>Booking #123 - Safari on 2025-01-15</p>
    <p>Requested by: Officer Smith</p>
    
    <div class="requested-resources">
        <p>🚗 Driver: John Doe</p>
        <p>👨‍🏫 Guide: Sarah Smith</p>
        <p>🚙 Jeep: ABC-1234</p>
    </div>
    
    <div class="actions">
        <form action="/tour-crew-manager/approve-allocation/45" method="post">
            <button class="btn-success">✅ Approve</button>
        </form>
        
        <button class="btn-warning" onclick="showModifyForm()">✏️ Modify</button>
        
        <button class="btn-danger" onclick="showRejectForm()">❌ Reject</button>
    </div>
</div>
```

---

## 🔔 Notification Flow

### **When Booking Officer Creates Request:**
- ✅ Allocation request created
- 📧 Tour Crew Manager dashboard shows new request
- 🔔 Pending count increases

### **When Tour Crew Manager Approves:**
- ✅ Resources allocated to booking
- 📧 Booking Officer dashboard shows approval
- 🔔 Booking status updated to ALLOCATED

### **When Tour Crew Manager Modifies:**
- ✏️ Different resources allocated
- 📧 Booking Officer sees changes highlighted
- 🔔 Manager notes explain modifications

### **When Tour Crew Manager Rejects:**
- ❌ Request marked as rejected
- 📧 Booking Officer sees rejection reason
- 🔔 Can create new request

---

## 🧪 Testing Workflow

### **Complete End-to-End Test:**

1. **Login as Tourist** (`user123@gmail.com` / `user123`)
   - Create booking for future date
   - Status: PENDING

2. **Login as Booking Officer** (`bookingofficer@wildtrack.com` / `booking123`)
   - Approve booking
   - Status: CONFIRMED
   - Click "Check Allocation"
   - Select driver, guide, jeep
   - Submit request
   - See "Pending Allocation Requests" section

3. **Login as Tour Crew Manager** (`tourmanager@wildtrack.com` / `tour123`)
   - See pending request
   - Check resource availability
   - **Test Scenario A**: Click "Approve"
   - **Test Scenario B**: Click "Modify", select different resources
   - **Test Scenario C**: Click "Reject", provide reason

4. **Login as Booking Officer** (again)
   - View allocation status
   - See approved/modified/rejected status
   - Verify resources displayed correctly

---

## ✅ Benefits of Enhanced Workflow

1. **Clear Communication**
   - Booking Officer requests specific resources
   - Tour Crew Manager provides feedback
   - Both parties see allocation history

2. **Flexibility**
   - Tour Crew Manager can modify if needed
   - Rejection with reason allows re-planning
   - Notes field for additional context

3. **Accountability**
   - Tracks who requested what
   - Records who approved/modified/rejected
   - Timestamps for all actions

4. **Resource Management**
   - Real-time availability checking
   - Prevents double-booking
   - Clear visibility of resource status

5. **Audit Trail**
   - Complete history of allocation requests
   - Status changes tracked
   - Notes preserved for reference

---

## 🎉 Summary

The enhanced workflow provides:
- ✅ Request-approval system
- ✅ Approve/Modify/Reject options
- ✅ Status tracking for both roles
- ✅ Clear communication channel
- ✅ Resource availability validation
- ✅ Complete audit trail

**The system is now ready for production use!** 🚀
