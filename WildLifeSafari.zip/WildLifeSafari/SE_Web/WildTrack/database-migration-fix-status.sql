-- Fix for "Data truncated for column 'status'" error
-- Run this in MySQL Workbench to fix the status column length

USE wildtrack_db;

-- Check current column definition
DESCRIBE bookings;

-- Alter the status column to accommodate longer enum values
ALTER TABLE bookings 
MODIFY COLUMN status VARCHAR(50);

-- Verify the change
DESCRIBE bookings;

-- Show current bookings
SELECT id, status, safari_date, created_at FROM bookings;

SELECT 'Status column updated successfully! Can now store PENDING_USER_CONFIRMATION' as message;
