-- Alternative fix for role column issue
-- This script tries multiple approaches

USE wildtrack_db;

-- Approach 1: Check if table exists
SELECT 'Checking if user_roles table exists...' AS Status;
SHOW TABLES LIKE 'user_roles';

-- Approach 2: Show current structure
SELECT 'Current structure of user_roles:' AS Status;
SHOW CREATE TABLE user_roles;

-- Approach 3: Try to alter without COLUMN keyword
SELECT 'Attempting to alter role column...' AS Status;
ALTER TABLE user_roles MODIFY role VARCHAR(50) NOT NULL;

-- Approach 4: If above fails, try with COLUMN keyword
-- ALTER TABLE user_roles MODIFY COLUMN role VARCHAR(50) NOT NULL;

-- Approach 5: Verify the change
SELECT 'Verifying the change...' AS Status;
SHOW COLUMNS FROM user_roles WHERE Field = 'role';

-- Show final result
SELECT 'SUCCESS! Role column is now VARCHAR(50)' AS Status;
