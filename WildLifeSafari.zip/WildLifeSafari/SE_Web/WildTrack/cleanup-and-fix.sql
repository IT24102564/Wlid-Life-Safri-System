-- Cleanup script to fix the Package Builder issue
-- The column is already VARCHAR(50), so we need to check for data issues

USE wildtrack_db;

-- Step 1: Check current roles in the database
SELECT 'Current roles in database:' AS Info;
SELECT user_id, role, LENGTH(role) as role_length FROM user_roles;

-- Step 2: Check if there's a Package Builder user already (might be corrupted)
SELECT 'Checking for existing Package Builder user:' AS Info;
SELECT u.id, u.email, u.full_name, ur.role 
FROM users u 
LEFT JOIN user_roles ur ON u.id = ur.user_id 
WHERE u.email = 'packagebuilder@wildtrack.com';

-- Step 3: Delete the Package Builder user if it exists (to start fresh)
SELECT 'Deleting existing Package Builder user if found...' AS Info;
DELETE FROM user_roles WHERE user_id IN (SELECT id FROM users WHERE email = 'packagebuilder@wildtrack.com');
DELETE FROM users WHERE email = 'packagebuilder@wildtrack.com';

-- Step 4: Verify the column is correct
SELECT 'Verifying role column structure:' AS Info;
SHOW COLUMNS FROM user_roles WHERE Field = 'role';

-- Step 5: Show all current users
SELECT 'All users after cleanup:' AS Info;
SELECT u.id, u.email, u.full_name, GROUP_CONCAT(ur.role) as roles
FROM users u
LEFT JOIN user_roles ur ON u.id = ur.user_id
GROUP BY u.id, u.email, u.full_name;

SELECT 'Cleanup complete! Now restart your Spring Boot application.' AS Status;
