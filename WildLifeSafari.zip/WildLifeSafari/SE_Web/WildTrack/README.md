# WildTrack - Safari Booking Management System

A comprehensive Spring Boot application for managing safari bookings, user authentication, and park operations.

## Features

### User Management & Authentication
- **Tourist Registration** with OTP email verification
- **Role-based Authentication** (Tourist, Admin, Booking Officer, Park Manager, Driver, Guide, IT Support)
- **Profile Management** for all user types
- **Secure Login/Logout** functionality

### Tourist Features
- Browse and book safari packages online
- Real-time jeep and guide availability checking
- Booking confirmations and email notifications
- View, edit, and cancel bookings with approval workflow
- Search safaris using filters (date, price, availability)
- Provide feedback and ratings for safaris, guides, and jeeps

### Staff Features

#### Booking Officer
- Monitor all reservations and schedules
- Approve tourist booking changes and cancellations
- Handle special requests and exceptions
- Receive jeep/guide assignment alerts

#### Park Manager
- Real-time dashboard for trends, revenue, and resource usage
- System configuration and access control management
- Generate financial and operational reports
- Adjust pricing and safari schedules dynamically
- Access tourist feedback analytics

#### Driver & Guide
- Receive assigned trips and itineraries
- Manage personal profiles
- Report jeep maintenance issues (Drivers)
- Get notifications about schedule changes

#### IT Support Officer
- Maintain system uptime and security monitoring
- Manage jeep maintenance tickets and assign mechanics
- Plan for system upgrades and improvements

### Admin Features
- Create, update, and delete safari packages
- Maintain seed packages (1 day full, half-day, 2 days, etc.)
- Manage staff accounts and user roles
- Complete system administration capabilities

## Technology Stack

- **Backend**: Spring Boot 3.5.6
- **Database**: MySQL 8.0
- **Security**: Spring Security with role-based access
- **Email**: Spring Mail with SMTP support
- **Frontend**: Thymeleaf templates with responsive CSS
- **Build Tool**: Maven
- **Java Version**: 21

## Database Configuration

The application uses MySQL database with the following configuration:

```properties
spring.datasource.url=jdbc:mysql://localhost:3306/wildtrack_db?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC&createDatabaseIfNotExist=true
spring.datasource.username=root
spring.datasource.password=nimesh5741
```

## Installation & Setup

1. **Prerequisites**
   - Java 21 or higher
   - MySQL 8.0 or higher
   - Maven 3.6 or higher

2. **Database Setup**
   - Install MySQL and create a user with username `root` and password `nimesh5741`
   - The database `wildtrack_db` will be created automatically

3. **Run the Application**
   ```bash
   mvn spring-boot:run
   ```

4. **Access the Application**
   - Open browser and go to `http://localhost:8080`

## Default Users

The application creates default users on startup:

### Admin User
- **Email**: admin@wildtrack.local
- **Password**: admin123
- **Roles**: ADMIN, PARK_MANAGER

### Booking Officer
- **Email**: bo@wildtrack.local
- **Password**: bo12345
- **Role**: BOOKING_OFFICER

## API Endpoints

### Public Endpoints
- `GET /` - Home page with safari packages
- `GET /register` - Tourist registration page
- `POST /register` - Submit registration
- `GET /login` - Login page
- `POST /verify` - Email verification

### Protected Endpoints
- `GET /dashboard` - Role-based dashboard redirect
- `GET /bookings` - View bookings
- `GET /new-booking` - Create new booking
- `POST /feedback/submit` - Submit feedback

### Admin Endpoints
- `GET /admin/dashboard` - Admin dashboard
- `GET /admin/users` - Manage users
- `POST /admin/staff/create` - Create staff accounts

## Database Schema

### Core Entities
- **User** - System users with roles
- **SafariPackage** - Available safari packages
- **Booking** - Tourist bookings
- **Jeep** - Vehicle management
- **Guide** - Tour guide management
- **Feedback** - Customer feedback
- **MaintenanceTicket** - Vehicle maintenance tracking

### Relationships
- User (1) → (N) Booking
- SafariPackage (1) → (N) Booking
- Jeep (1) → (N) Booking
- Guide (1) → (N) Booking
- Booking (1) → (N) Feedback

## Email Configuration

Configure SMTP settings in `application.properties`:

```properties
spring.mail.host=smtp.gmail.com
spring.mail.port=587
spring.mail.username=your-email@gmail.com
spring.mail.password=your-app-password
```

## Security Features

- **CSRF Protection** disabled for API endpoints
- **Role-based Access Control** for different user types
- **Password Encryption** using BCrypt
- **Email Verification** for new registrations
- **Session Management** with Spring Security

## Future Enhancements

- Mobile app integration hooks
- Payment gateway integration
- Advanced reporting and analytics
- Real-time notifications
- GPS tracking for safari vehicles
- Weather integration
- Multi-language support

## Development

### Project Structure
```
src/
├── main/
│   ├── java/com/safari/WildTrack/
│   │   ├── config/          # Configuration classes
│   │   ├── controller/      # Web controllers
│   │   ├── enums/          # Enumeration types
│   │   ├── model/          # JPA entities
│   │   ├── repository/     # Data repositories
│   │   └── service/        # Business logic
│   └── resources/
│       ├── templates/      # Thymeleaf templates
│       └── application.properties
```

### Running Tests
```bash
mvn test
```

### Building for Production
```bash
mvn clean package
```

## License

This project is developed for educational purposes.

## Support

For issues and questions, please check the application logs or contact the development team.
