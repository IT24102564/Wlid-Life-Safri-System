# 🔐 Gmail App Password Setup for wildtracksafari2024@gmail.com

To send emails from your Gmail account, you need to create an App Password. Follow these steps:

## 📋 Step-by-Step Instructions:

### 1. Enable 2-Factor Authentication
1. Go to: https://myaccount.google.com/
2. Sign in with: **wildtracksafari2024@gmail.com** / **wildtrack2024**
3. Click **Security** in the left sidebar
4. Under "How you sign in to Google", click **2-Step Verification**
5. Follow the steps to enable 2FA (you'll need your phone number)

### 2. Generate App Password
1. After enabling 2FA, go back to **Security** settings
2. Under "How you sign in to Google", click **App passwords**
3. You might need to sign in again
4. Select **Mail** for the app type
5. Select **Other (custom name)** for device
6. Enter: **WildTrack Safari Application**
7. Click **Generate**
8. **COPY THE 16-CHARACTER PASSWORD** (like: `abcd efgh ijkl mnop`)

### 3. Update Application Configuration
Replace the password in `application.properties`:

**Current:**
```properties
spring.mail.password=wildtrack2024
```

**Replace with your App Password:**
```properties
spring.mail.password=YOUR_16_CHAR_APP_PASSWORD
```

**Example:**
```properties
spring.mail.password=abcd efgh ijkl mnop
```

## 🚀 After Setup:

1. **Restart your application**
2. **Test registration** with any Gmail address
3. **Check the recipient's Gmail inbox** for OTP email
4. **Check spam folder** if not in inbox

## 🧪 Quick Test:

Visit: `http://localhost:8080/test-email?email=YOUR_TEST_EMAIL@gmail.com`

## ⚠️ Important Notes:

- **Never use your regular Gmail password** for SMTP
- **App passwords are safer** and required by Gmail
- **Keep the App Password secure** - don't share it
- **The App Password is only for this application**

## 🔍 Troubleshooting:

If emails still don't work:
1. **Double-check** the App Password is correct
2. **Ensure 2FA** is enabled on the Gmail account
3. **Check console logs** for detailed error messages
4. **Try different recipient** email addresses

---

**Complete these steps and your WildTrack application will send real OTP emails!** 🎉
