# 📧 Gmail SMTP Setup Guide for WildTrack

To receive real OTP verification emails, you need to configure Gmail SMTP. Follow these steps:

## 🔧 Step 1: Enable 2-Factor Authentication on Gmail

1. Go to your **Google Account settings**: https://myaccount.google.com/
2. Click **Security** in the left sidebar
3. Under **"How you sign in to Google"**, click **2-Step Verification**
4. Follow the steps to enable 2FA if not already enabled

## 🔑 Step 2: Generate App Password

1. In Google Account Security settings
2. Under **"How you sign in to Google"**, click **App passwords**
3. You might need to sign in again
4. Select **Mail** for the app
5. Select **Other (custom name)** for device
6. Enter: `WildTrack Safari App`
7. Click **Generate**
8. **COPY THE 16-CHARACTER PASSWORD** (like: `abcd efgh ijkl mnop`)

## ⚙️ Step 3: Update application.properties

Replace these lines in `application.properties`:

```properties
spring.mail.username=YOUR_GMAIL_ADDRESS@gmail.com
spring.mail.password=YOUR_APP_PASSWORD
spring.mail.from=YOUR_GMAIL_ADDRESS@gmail.com
```

**Example:**
```properties
spring.mail.username=nimesh.example@gmail.com
spring.mail.password=abcd efgh ijkl mnop
spring.mail.from=nimesh.example@gmail.com
```

## 🚀 Step 4: Test the Setup

1. **Restart your application** after updating the configuration
2. **Register a new account** with your real email address
3. **Check your Gmail inbox** for the OTP verification email
4. **Check spam folder** if you don't see it in inbox

## 🔍 Troubleshooting

### If emails still don't arrive:

1. **Check application console** - OTP will be logged there as backup
2. **Verify Gmail settings** - Make sure 2FA and App Password are correct
3. **Check firewall** - Ensure port 587 is not blocked
4. **Try different email** - Test with another Gmail account

### Console Backup:
Even if email fails, you'll see this in the application console:
```
[DEV] Email sending failed. OTP for user@gmail.com is: 123456
```

## 📝 Security Notes

- **Never commit** your real Gmail credentials to version control
- **Use environment variables** in production:
  ```properties
  spring.mail.username=${GMAIL_USERNAME}
  spring.mail.password=${GMAIL_APP_PASSWORD}
  ```
- **App passwords** are safer than your main Gmail password
- **Revoke app password** when no longer needed

## ✅ Quick Setup Checklist

- [ ] Enable 2FA on Gmail account
- [ ] Generate App Password for WildTrack
- [ ] Update `spring.mail.username` with your Gmail
- [ ] Update `spring.mail.password` with App Password
- [ ] Update `spring.mail.from` with your Gmail
- [ ] Restart the application
- [ ] Test registration with real email
- [ ] Check Gmail inbox/spam for OTP email

---

**Need help?** Check the application console for error messages and OTP backup codes.
