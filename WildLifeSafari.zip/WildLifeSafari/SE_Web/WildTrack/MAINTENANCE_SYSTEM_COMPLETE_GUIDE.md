# 🔧 Maintenance System - Complete Implementation Guide

## ✅ **What's Been Done:**

1. ✅ **TicketSeverity.java** - Created (LOW, MEDIUM, HIGH, CRITICAL)
2. ✅ **TicketStatus.java** - Created (UNASSIGNED, ASSIGNED, IN_PROGRESS, COMPLETED, CANCELLED)
3. ✅ **MaintenanceTicket.java** - Updated with all required fields
4. ✅ **MaintenanceTicketRepository.java** - Updated with query methods
5. ✅ **Role.java** - Added MECHANIC role
6. ✅ **DataInitializer.java** - Added maintenance@wildtrack.com and mechanic1@wildtrack.com

## 🔐 **Login Credentials:**

| Role | Email | Password |
|------|-------|----------|
| Maintenance Officer | maintenance@wildtrack.com | maintenance123 |
| Mechanic | mechanic1@wildtrack.com | mechanic123 |

---

## 📋 **Still Need to Create:**

### **1. Service Layer** (`MaintenanceTicketService.java`)

```java
package com.safari.WildTrack.service;

import com.safari.WildTrack.model.MaintenanceTicket;
import com.safari.WildTrack.model.User;
import com.safari.WildTrack.model.Jeep;
import com.safari.WildTrack.enums.TicketStatus;
import com.safari.WildTrack.enums.TicketSeverity;
import com.safari.WildTrack.repository.MaintenanceTicketRepository;
import com.safari.WildTrack.repository.UserRepository;
import com.safari.WildTrack.repository.JeepRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class MaintenanceTicketService {
    
    private final MaintenanceTicketRepository ticketRepository;
    private final UserRepository userRepository;
    private final JeepRepository jeepRepository;
    
    public MaintenanceTicketService(MaintenanceTicketRepository ticketRepository,
                                   UserRepository userRepository,
                                   JeepRepository jeepRepository) {
        this.ticketRepository = ticketRepository;
        this.userRepository = userRepository;
        this.jeepRepository = jeepRepository;
    }
    
    // Create new ticket
    @Transactional
    public MaintenanceTicket createTicket(Long jeepId, String reporterEmail, 
                                         String issueDescription, TicketSeverity severity) {
        Jeep jeep = jeepRepository.findById(jeepId).orElseThrow();
        User reporter = userRepository.findByEmail(reporterEmail).orElseThrow();
        
        MaintenanceTicket ticket = MaintenanceTicket.builder()
                .jeep(jeep)
                .reportedBy(reporter)
                .issueDescription(issueDescription)
                .severity(severity)
                .status(TicketStatus.UNASSIGNED)
                .createdAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .build();
        
        // Mark jeep as unavailable
        jeep.setAvailable(false);
        jeepRepository.save(jeep);
        
        return ticketRepository.save(ticket);
    }
    
    // Assign ticket to mechanic
    @Transactional
    public MaintenanceTicket assignTicket(Long ticketId, Long mechanicId, String assignerEmail) {
        MaintenanceTicket ticket = ticketRepository.findById(ticketId).orElseThrow();
        User mechanic = userRepository.findById(mechanicId).orElseThrow();
        User assigner = userRepository.findByEmail(assignerEmail).orElseThrow();
        
        ticket.setAssignedMechanic(mechanic);
        ticket.setAssignedBy(assigner);
        ticket.setAssignedAt(LocalDateTime.now());
        ticket.setStatus(TicketStatus.ASSIGNED);
        ticket.setUpdatedAt(LocalDateTime.now());
        
        return ticketRepository.save(ticket);
    }
    
    // Mechanic starts work
    @Transactional
    public MaintenanceTicket startWork(Long ticketId) {
        MaintenanceTicket ticket = ticketRepository.findById(ticketId).orElseThrow();
        ticket.setStatus(TicketStatus.IN_PROGRESS);
        ticket.setUpdatedAt(LocalDateTime.now());
        return ticketRepository.save(ticket);
    }
    
    // Mechanic completes work
    @Transactional
    public MaintenanceTicket completeWork(Long ticketId, String mechanicNotes) {
        MaintenanceTicket ticket = ticketRepository.findById(ticketId).orElseThrow();
        ticket.setStatus(TicketStatus.COMPLETED);
        ticket.setMechanicNotes(mechanicNotes);
        ticket.setCompletedAt(LocalDateTime.now());
        ticket.setUpdatedAt(LocalDateTime.now());
        
        // Mark jeep as available again
        Jeep jeep = ticket.getJeep();
        jeep.setAvailable(true);
        jeepRepository.save(jeep);
        
        return ticketRepository.save(ticket);
    }
    
    // Get all tickets
    public List<MaintenanceTicket> getAllTickets() {
        return ticketRepository.findAllByOrderByCreatedAtDesc();
    }
    
    // Get unassigned tickets
    public List<MaintenanceTicket> getUnassignedTickets() {
        return ticketRepository.findByStatusOrderByCreatedAtDesc(TicketStatus.UNASSIGNED);
    }
    
    // Get tickets for mechanic
    public List<MaintenanceTicket> getTicketsForMechanic(String mechanicEmail) {
        User mechanic = userRepository.findByEmail(mechanicEmail).orElseThrow();
        return ticketRepository.findByAssignedMechanicOrderByCreatedAtDesc(mechanic);
    }
    
    // Get active tickets for mechanic
    public List<MaintenanceTicket> getActiveTicketsForMechanic(String mechanicEmail) {
        User mechanic = userRepository.findByEmail(mechanicEmail).orElseThrow();
        List<MaintenanceTicket> assigned = ticketRepository.findByAssignedMechanicAndStatusOrderByCreatedAtDesc(mechanic, TicketStatus.ASSIGNED);
        List<MaintenanceTicket> inProgress = ticketRepository.findByAssignedMechanicAndStatusOrderByCreatedAtDesc(mechanic, TicketStatus.IN_PROGRESS);
        assigned.addAll(inProgress);
        return assigned;
    }
}
```

### **2. Maintenance Officer Controller** (`MaintenanceOfficerController.java`)

Create file: `src/main/java/com/safari/WildTrack/controller/MaintenanceOfficerController.java`

```java
package com.safari.WildTrack.controller;

import com.safari.WildTrack.service.MaintenanceTicketService;
import com.safari.WildTrack.repository.UserRepository;
import com.safari.WildTrack.repository.JeepRepository;
import com.safari.WildTrack.enums.Role;
import com.safari.WildTrack.enums.TicketSeverity;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/maintenance-officer")
public class MaintenanceOfficerController {
    
    private final MaintenanceTicketService ticketService;
    private final UserRepository userRepository;
    private final JeepRepository jeepRepository;
    
    public MaintenanceOfficerController(MaintenanceTicketService ticketService,
                                       UserRepository userRepository,
                                       JeepRepository jeepRepository) {
        this.ticketService = ticketService;
        this.userRepository = userRepository;
        this.jeepRepository = jeepRepository;
    }
    
    @GetMapping("/dashboard")
    public String dashboard(Authentication auth, Model model) {
        if (auth == null) {
            return "redirect:/login";
        }
        
        var user = userRepository.findByEmail(auth.getName()).orElse(null);
        if (user == null) {
            return "redirect:/login";
        }
        
        // Get all tickets
        var allTickets = ticketService.getAllTickets();
        var unassignedTickets = ticketService.getUnassignedTickets();
        
        // Get all mechanics
        var mechanics = userRepository.findAll().stream()
                .filter(u -> u.getRoles().contains(Role.MECHANIC))
                .toList();
        
        // Get all jeeps
        var jeeps = jeepRepository.findAll();
        
        model.addAttribute("user", user);
        model.addAttribute("allTickets", allTickets);
        model.addAttribute("unassignedTickets", unassignedTickets);
        model.addAttribute("mechanics", mechanics);
        model.addAttribute("jeeps", jeeps);
        
        return "maintenance-officer-dashboard";
    }
    
    @PostMapping("/create-ticket")
    public String createTicket(@RequestParam Long jeepId,
                              @RequestParam String issueDescription,
                              @RequestParam TicketSeverity severity,
                              Authentication auth,
                              RedirectAttributes ra) {
        try {
            ticketService.createTicket(jeepId, auth.getName(), issueDescription, severity);
            ra.addFlashAttribute("success", "✅ Ticket created successfully!");
        } catch (Exception e) {
            ra.addFlashAttribute("error", "❌ Error creating ticket: " + e.getMessage());
        }
        return "redirect:/maintenance-officer/dashboard";
    }
    
    @PostMapping("/assign-ticket/{ticketId}")
    public String assignTicket(@PathVariable Long ticketId,
                              @RequestParam Long mechanicId,
                              Authentication auth,
                              RedirectAttributes ra) {
        try {
            ticketService.assignTicket(ticketId, mechanicId, auth.getName());
            ra.addFlashAttribute("success", "✅ Ticket assigned to mechanic successfully!");
        } catch (Exception e) {
            ra.addFlashAttribute("error", "❌ Error assigning ticket: " + e.getMessage());
        }
        return "redirect:/maintenance-officer/dashboard";
    }
}
```

### **3. Mechanic Controller** (`MechanicController.java`)

Create file: `src/main/java/com/safari/WildTrack/controller/MechanicController.java`

```java
package com.safari.WildTrack.controller;

import com.safari.WildTrack.service.MaintenanceTicketService;
import com.safari.WildTrack.repository.UserRepository;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/mechanic")
public class MechanicController {
    
    private final MaintenanceTicketService ticketService;
    private final UserRepository userRepository;
    
    public MechanicController(MaintenanceTicketService ticketService,
                             UserRepository userRepository) {
        this.ticketService = ticketService;
        this.userRepository = userRepository;
    }
    
    @GetMapping("/dashboard")
    public String dashboard(Authentication auth, Model model) {
        if (auth == null) {
            return "redirect:/login";
        }
        
        var user = userRepository.findByEmail(auth.getName()).orElse(null);
        if (user == null) {
            return "redirect:/login";
        }
        
        // Get tickets assigned to this mechanic
        var myTickets = ticketService.getTicketsForMechanic(auth.getName());
        var activeTickets = ticketService.getActiveTicketsForMechanic(auth.getName());
        
        model.addAttribute("user", user);
        model.addAttribute("myTickets", myTickets);
        model.addAttribute("activeTickets", activeTickets);
        
        return "mechanic-dashboard";
    }
    
    @PostMapping("/start-work/{ticketId}")
    public String startWork(@PathVariable Long ticketId, RedirectAttributes ra) {
        try {
            ticketService.startWork(ticketId);
            ra.addFlashAttribute("success", "✅ Work started on ticket!");
        } catch (Exception e) {
            ra.addFlashAttribute("error", "❌ Error: " + e.getMessage());
        }
        return "redirect:/mechanic/dashboard";
    }
    
    @PostMapping("/complete-work/{ticketId}")
    public String completeWork(@PathVariable Long ticketId,
                              @RequestParam String mechanicNotes,
                              RedirectAttributes ra) {
        try {
            ticketService.completeWork(ticketId, mechanicNotes);
            ra.addFlashAttribute("success", "✅ Work completed! Maintenance Officer has been notified.");
        } catch (Exception e) {
            ra.addFlashAttribute("error", "❌ Error: " + e.getMessage());
        }
        return "redirect:/mechanic/dashboard";
    }
}
```

---

## 🎨 **HTML Templates:**

### **4. Maintenance Officer Dashboard** (`maintenance-officer-dashboard.html`)

Create file: `src/main/resources/templates/maintenance-officer-dashboard.html`

This dashboard should have:
- ✅ Create Ticket Form (Jeep selection, issue description, severity)
- ✅ Unassigned Tickets List
- ✅ Assign Mechanic Panel
- ✅ All Tickets View (with status filtering)
- ❌ NO Safari Booking functions
- ❌ NO View Bookings functions

### **5. Mechanic Dashboard** (`mechanic-dashboard.html`)

Create file: `src/main/resources/templates/mechanic-dashboard.html`

This dashboard should have:
- ✅ Assigned Tickets List
- ✅ Start Work Button
- ✅ Complete Work Form (with notes)
- ✅ Work History
- ❌ NO Safari Booking functions
- ❌ NO View Bookings functions

---

## 🔄 **Complete Workflow:**

```
1. Maintenance Officer creates ticket
   - Selects jeep
   - Describes issue
   - Sets severity
   - Jeep becomes unavailable
   ↓
2. Ticket Status: UNASSIGNED
   ↓
3. Maintenance Officer assigns to mechanic
   - Selects mechanic from list
   - Confirms assignment
   ↓
4. Ticket Status: ASSIGNED
   - Mechanic sees in dashboard
   ↓
5. Mechanic starts work
   - Clicks "Start Work"
   ↓
6. Ticket Status: IN_PROGRESS
   ↓
7. Mechanic completes work
   - Adds notes
   - Clicks "Complete Work"
   ↓
8. Ticket Status: COMPLETED
   - Jeep becomes available
   - Maintenance Officer notified
```

---

## ✅ **Implementation Checklist:**

- [x] TicketSeverity enum
- [x] TicketStatus enum
- [x] MaintenanceTicket model
- [x] MaintenanceTicketRepository
- [x] MECHANIC role added
- [x] Maintenance Officer account
- [x] Mechanic account
- [ ] MaintenanceTicketService
- [ ] MaintenanceOfficerController
- [ ] MechanicController
- [ ] maintenance-officer-dashboard.html
- [ ] mechanic-dashboard.html

---

## 🚀 **Next Steps:**

1. Create `MaintenanceTicketService.java` (copy code above)
2. Create `MaintenanceOfficerController.java` (copy code above)
3. Create `MechanicController.java` (copy code above)
4. Create HTML templates (I can provide these)
5. Restart application
6. Test complete workflow

**Foundation is ready! Just need to create the service, controllers, and views!** 🎉
