package com.safari.WildTrack.controller;

import com.safari.WildTrack.model.*;
import com.safari.WildTrack.enums.BookingStatus;
import com.safari.WildTrack.enums.AllocationStatus;
import com.safari.WildTrack.enums.Role;
import com.safari.WildTrack.repository.*;
import com.safari.WildTrack.repository.GuideRepository;
import com.safari.WildTrack.repository.UserRepository;
import com.safari.WildTrack.repository.ResourceAllocationRepository;
import com.safari.WildTrack.service.BookingService;
import com.safari.WildTrack.service.ResourceAllocationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/booking-officer")
public class BookingOfficerController {

    private static final Logger log = LoggerFactory.getLogger(BookingOfficerController.class);
    
    private final BookingRepository bookingRepository;
    private final JeepRepository jeepRepository;
    private final GuideRepository guideRepository;
    private final UserRepository userRepository;
    private final ResourceAllocationRepository allocationRepository;
    private final BookingService bookingService;
    private final ResourceAllocationService allocationService;

    public BookingOfficerController(BookingRepository bookingRepository,
                                   JeepRepository jeepRepository,
                                   GuideRepository guideRepository,
                                   UserRepository userRepository,
                                   ResourceAllocationRepository allocationRepository,
                                   BookingService bookingService,
                                   ResourceAllocationService allocationService) {
        this.bookingRepository = bookingRepository;
        this.jeepRepository = jeepRepository;
        this.guideRepository = guideRepository;
        this.userRepository = userRepository;
        this.allocationRepository = allocationRepository;
        this.bookingService = bookingService;
        this.allocationService = allocationService;
    }

    @GetMapping("/dashboard")
    public String dashboard(Authentication auth, Model model) {
        log.info("📊 Loading Booking Officer Dashboard");
        
        if (auth == null) {
            log.warn("❌ Unauthorized access attempt - no authentication");
            return "redirect:/login";
        }
        
        // Verify user has BOOKING_OFFICER role
        boolean hasRole = auth.getAuthorities().stream()
                .anyMatch(a -> a.getAuthority().equals("ROLE_BOOKING_OFFICER"));
        
        if (!hasRole) {
            log.warn("❌ Access denied for user: {} - Not a Booking Officer", auth.getName());
            return "redirect:/safe-dashboard";
        }
        
        log.info("✅ Booking Officer authenticated: {}", auth.getName());

        try {
            // Get all bookings
            var allBookings = bookingRepository.findAll();
            
            // Calculate statistics
            long totalBookings = allBookings.size();
            long pendingBookings = allBookings.stream()
                    .filter(b -> b.getStatus() == BookingStatus.PENDING)
                    .count();
            long confirmedBookings = allBookings.stream()
                    .filter(b -> b.getStatus() == BookingStatus.CONFIRMED)
                    .count();
            long allocatedBookings = allBookings.stream()
                    .filter(b -> b.getStatus() == BookingStatus.ALLOCATED)
                    .count();
            long todayBookings = allBookings.stream()
                    .filter(b -> b.getSafariDate().equals(LocalDate.now()))
                    .count();
            
            // Get pending bookings for approval (exclude cancelled)
            var pendingBookingsList = allBookings.stream()
                    .filter(b -> b.getStatus() == BookingStatus.PENDING)
                    .filter(b -> b.getStatus() != BookingStatus.CANCELLED)
                    .sorted((b1, b2) -> b1.getCreatedAt().compareTo(b2.getCreatedAt()))
                    .collect(Collectors.toList());
            
            // Get bookings awaiting user confirmation (modified by TCM)
            var awaitingUserConfirmation = allBookings.stream()
                    .filter(b -> b.getStatus() == BookingStatus.PENDING_USER_CONFIRMATION)
                    .sorted((b1, b2) -> b2.getUpdatedAt().compareTo(b1.getUpdatedAt()))
                    .collect(Collectors.toList());
            
            // Get confirmed bookings (ready for allocation request)
            var confirmedBookingsList = allBookings.stream()
                    .filter(b -> b.getStatus() == BookingStatus.CONFIRMED)
                    .filter(b -> !allocationRepository.existsByBooking(b))  // No allocation request yet
                    .sorted((b1, b2) -> b1.getSafariDate().compareTo(b2.getSafariDate()))
                    .collect(Collectors.toList());
            
            // Get today's bookings
            var todayBookingsList = allBookings.stream()
                    .filter(b -> b.getSafariDate().equals(LocalDate.now()))
                    .collect(Collectors.toList());
            
            // Get upcoming bookings (next 7 days)
            LocalDate today = LocalDate.now();
            LocalDate nextWeek = today.plusDays(7);
            var upcomingBookings = allBookings.stream()
                    .filter(b -> b.getSafariDate().isAfter(today) && b.getSafariDate().isBefore(nextWeek))
                    .sorted((b1, b2) -> b1.getSafariDate().compareTo(b2.getSafariDate()))
                    .collect(Collectors.toList());
            
            // Get allocated bookings (resources assigned by Tour Crew Manager)
            var allocatedBookingsList = allBookings.stream()
                    .filter(b -> b.getStatus() == BookingStatus.ALLOCATED)
                    .sorted((b1, b2) -> b2.getUpdatedAt().compareTo(b1.getUpdatedAt()))
                    .collect(Collectors.toList());
            
            // Get allocation requests and their statuses
            var allAllocations = allocationRepository.findAll();
            var pendingAllocations = allocationRepository.findByStatusOrderByRequestedAtDesc(AllocationStatus.PENDING_APPROVAL);
            var approvedAllocations = allocationRepository.findByStatus(AllocationStatus.APPROVED);
            var rejectedAllocations = allocationRepository.findByStatus(AllocationStatus.REJECTED);
            var modifiedAllocations = allocationRepository.findByStatus(AllocationStatus.MODIFIED);
            
            // Get all drivers
            var allDrivers = userRepository.findAll().stream()
                    .filter(u -> u.getRoles().contains(Role.DRIVER))
                    .collect(Collectors.toList());
            
            // Get resource statistics
            var allJeeps = jeepRepository.findAll();
            var allGuides = guideRepository.findAll();
            
            long availableJeeps = allJeeps.stream().filter(Jeep::isAvailable).count();
            long availableGuides = allGuides.stream().filter(Guide::isAvailable).count();
            long jeepsInMaintenance = allJeeps.size() - availableJeeps;
            
            // Get resource assignment alerts (bookings without jeep or guide)
            var unassignedBookings = allBookings.stream()
                    .filter(b -> b.getStatus() == BookingStatus.CONFIRMED)
                    .filter(b -> b.getJeep() == null || b.getGuide() == null)
                    .collect(Collectors.toList());
            
            // Add all data to model
            model.addAttribute("totalBookings", totalBookings);
            model.addAttribute("pendingBookings", pendingBookings);
            model.addAttribute("confirmedBookings", confirmedBookings);
            model.addAttribute("allocatedBookings", allocatedBookings);
            model.addAttribute("todayBookings", todayBookings);
            model.addAttribute("upcomingCount", upcomingBookings.size());
            
            model.addAttribute("pendingBookingsList", pendingBookingsList);
            model.addAttribute("awaitingUserConfirmation", awaitingUserConfirmation);
            model.addAttribute("confirmedBookingsList", confirmedBookingsList);
            model.addAttribute("todayBookingsList", todayBookingsList);
            model.addAttribute("upcomingBookingsList", upcomingBookings);
            model.addAttribute("allocatedBookingsList", allocatedBookingsList);
            model.addAttribute("unassignedBookings", unassignedBookings);
            
            model.addAttribute("totalJeeps", allJeeps.size());
            model.addAttribute("availableJeeps", availableJeeps);
            model.addAttribute("jeepsInMaintenance", jeepsInMaintenance);
            model.addAttribute("totalGuides", allGuides.size());
            model.addAttribute("availableGuides", availableGuides);
            
            model.addAttribute("allJeeps", allJeeps);
            model.addAttribute("allGuides", allGuides);
            model.addAttribute("allDrivers", allDrivers);
            
            // Add allocation requests
            model.addAttribute("pendingAllocations", pendingAllocations);
            model.addAttribute("approvedAllocations", approvedAllocations);
            model.addAttribute("rejectedAllocations", rejectedAllocations);
            model.addAttribute("modifiedAllocations", modifiedAllocations);
            
            log.info("✅ Dashboard loaded - Total: {}, Pending: {}, Confirmed: {}", 
                totalBookings, pendingBookings, confirmedBookings);
            
            return "booking-officer-dashboard";
            
        } catch (Exception e) {
            log.error("❌ Error loading dashboard: {}", e.getMessage(), e);
            model.addAttribute("error", "Error loading dashboard: " + e.getMessage());
            return "booking-officer-dashboard";
        }
    }

    @PostMapping("/approve-booking/{id}")
    public String approveBooking(@PathVariable Long id, RedirectAttributes ra) {
        log.info("✅ Approving booking ID: {}", id);
        
        try {
            Booking booking = bookingRepository.findById(id)
                    .orElseThrow(() -> new IllegalArgumentException("Booking not found"));
            
            // Check if allocation has been approved by Tour Crew Manager
            var allocation = allocationRepository.findByBooking(booking);
            if (allocation.isEmpty()) {
                ra.addFlashAttribute("error", "⚠️ Cannot approve! Tour Crew Manager must confirm resource availability first. Please send allocation request.");
                return "redirect:/booking-officer/dashboard";
            }
            
            AllocationStatus allocStatus = allocation.get().getStatus();
            
            // If Tour Crew Manager rejected, cannot approve
            if (allocStatus == AllocationStatus.REJECTED) {
                ra.addFlashAttribute("error", "❌ Cannot approve! Tour Crew Manager rejected this allocation request. Please create a new request with different resources.");
                return "redirect:/booking-officer/dashboard";
            }
            
            // If Tour Crew Manager modified, check if user confirmed
            if (allocStatus == AllocationStatus.MODIFIED && booking.getStatus() == BookingStatus.PENDING_USER_CONFIRMATION) {
                ra.addFlashAttribute("error", "⏳ Cannot approve yet! User must confirm the modified resources first. Check user's profile.");
                return "redirect:/booking-officer/dashboard";
            }
            
            // Must be APPROVED or MODIFIED (and user confirmed)
            if (allocStatus != AllocationStatus.APPROVED && allocStatus != AllocationStatus.MODIFIED) {
                ra.addFlashAttribute("error", "⚠️ Cannot approve! Tour Crew Manager must confirm resource availability first.");
                return "redirect:/booking-officer/dashboard";
            }
            
            // All checks passed - approve the booking
            booking.setStatus(BookingStatus.CONFIRMED);
            booking.setUpdatedAt(java.time.LocalDateTime.now());
            bookingRepository.save(booking);
            
            ra.addFlashAttribute("success", "✅ Booking #" + id + " has been confirmed successfully! User can now view it in their profile.");
            log.info("✅ Booking {} confirmed by Booking Officer", id);
        } catch (Exception e) {
            log.error("❌ Error approving booking {}: {}", id, e.getMessage(), e);
            ra.addFlashAttribute("error", "Error approving booking: " + e.getMessage());
        }
        
        return "redirect:/booking-officer/dashboard";
    }

    @PostMapping("/cancel-booking/{id}")
    public String cancelBooking(@PathVariable Long id, RedirectAttributes ra) {
        log.info("❌ Cancelling booking ID: {}", id);
        
        try {
            bookingService.cancelBooking(id);
            ra.addFlashAttribute("success", "Booking #" + id + " has been cancelled.");
            log.info("✅ Booking {} cancelled successfully", id);
        } catch (Exception e) {
            log.error("❌ Error cancelling booking {}: {}", id, e.getMessage(), e);
            ra.addFlashAttribute("error", "Error cancelling booking: " + e.getMessage());
        }
        
        return "redirect:/booking-officer/dashboard";
    }
    
    // Final confirmation to user after resources are allocated
    @PostMapping("/final-confirm/{bookingId}")
    public String finalConfirmBooking(@PathVariable Long bookingId, RedirectAttributes ra) {
        log.info("🎉 Final confirmation for booking {}", bookingId);
        
        try {
            Booking booking = bookingRepository.findById(bookingId)
                    .orElseThrow(() -> new IllegalArgumentException("Booking not found"));
            
            if (booking.getStatus() != BookingStatus.ALLOCATED) {
                ra.addFlashAttribute("error", "Booking must be ALLOCATED before final confirmation!");
                return "redirect:/booking-officer/dashboard";
            }
            
            // Update status to COMPLETED (or you can create a new status like CONFIRMED_TO_USER)
            booking.setStatus(BookingStatus.COMPLETED);
            booking.setUpdatedAt(java.time.LocalDateTime.now());
            bookingRepository.save(booking);
            
            ra.addFlashAttribute("success", "✅ Booking #" + bookingId + " confirmed to user! Tourist can now view details.");
            log.info("✅ Booking {} finally confirmed to user", bookingId);
            
        } catch (Exception e) {
            log.error("❌ Error confirming booking: {}", e.getMessage(), e);
            ra.addFlashAttribute("error", "Error confirming booking: " + e.getMessage());
        }
        
        return "redirect:/booking-officer/dashboard";
    }

    @GetMapping("/all-bookings")
    public String allBookings(Model model) {
        log.info("📋 Loading all bookings");
        
        var allBookings = bookingRepository.findAll();
        model.addAttribute("bookings", allBookings);
        
        return "booking-officer-all-bookings";
    }

    @GetMapping("/resources")
    public String resources(Model model) {
        log.info("🚙 Loading resources page");
        
        var allJeeps = jeepRepository.findAll();
        var allGuides = guideRepository.findAll();
        
        model.addAttribute("jeeps", allJeeps);
        model.addAttribute("guides", allGuides);
        
        // Get resource utilization
        var allBookings = bookingRepository.findAll();
        LocalDate today = LocalDate.now();
        
        for (Jeep jeep : allJeeps) {
            long bookingsCount = allBookings.stream()
                    .filter(b -> b.getJeep() != null && b.getJeep().getId().equals(jeep.getId()))
                    .filter(b -> b.getSafariDate().equals(today))
                    .count();
            model.addAttribute("jeep_" + jeep.getId() + "_bookings", bookingsCount);
        }
        
        for (Guide guide : allGuides) {
            long bookingsCount = allBookings.stream()
                    .filter(b -> b.getGuide() != null && b.getGuide().getId().equals(guide.getId()))
                    .filter(b -> b.getSafariDate().equals(today))
                    .count();
            model.addAttribute("guide_" + guide.getId() + "_bookings", bookingsCount);
        }
        
        return "booking-officer-resources";
    }

    @PostMapping("/toggle-jeep-availability/{id}")
    public String toggleJeepAvailability(@PathVariable Long id, RedirectAttributes ra) {
        log.info("🔧 Toggling jeep availability: {}", id);
        
        try {
            Jeep jeep = jeepRepository.findById(id)
                    .orElseThrow(() -> new IllegalArgumentException("Jeep not found"));
            
            jeep.setAvailable(!jeep.isAvailable());
            jeepRepository.save(jeep);
            
            String status = jeep.isAvailable() ? "available" : "in maintenance";
            ra.addFlashAttribute("success", "Jeep " + jeep.getRegistrationNumber() + " is now " + status);
            log.info("✅ Jeep {} status changed to: {}", jeep.getRegistrationNumber(), status);
            
        } catch (Exception e) {
            log.error("❌ Error toggling jeep availability: {}", e.getMessage(), e);
            ra.addFlashAttribute("error", "Error updating jeep status: " + e.getMessage());
        }
        
        return "redirect:/booking-officer/resources";
    }

    @PostMapping("/toggle-guide-availability/{id}")
    public String toggleGuideAvailability(@PathVariable Long id, RedirectAttributes ra) {
        log.info("🔧 Toggling guide availability: {}", id);
        
        try {
            Guide guide = guideRepository.findById(id)
                    .orElseThrow(() -> new IllegalArgumentException("Guide not found"));
            
            guide.setAvailable(!guide.isAvailable());
            guideRepository.save(guide);
            
            String status = guide.isAvailable() ? "available" : "unavailable";
            ra.addFlashAttribute("success", "Guide " + guide.getName() + " is now " + status);
            log.info("✅ Guide {} status changed to: {}", guide.getName(), status);
            
        } catch (Exception e) {
            log.error("❌ Error toggling guide availability: {}", e.getMessage(), e);
            ra.addFlashAttribute("error", "Error updating guide status: " + e.getMessage());
        }
        
        return "redirect:/booking-officer/resources";
    }

    // NEW: Booking Officer creates allocation request (Check function)
    @PostMapping("/check-allocation/{bookingId}")
    public String checkAllocation(@PathVariable Long bookingId,
                                  @RequestParam Long driverId,
                                  @RequestParam Long guideId,
                                  @RequestParam Long jeepId,
                                  @RequestParam(required = false) String notes,
                                  Authentication auth,
                                  RedirectAttributes ra) {
        log.info("📋 Creating allocation request for booking {}", bookingId);
        
        try {
            allocationService.createAllocationRequest(bookingId, driverId, guideId, jeepId, 
                                                     auth.getName(), notes);
            ra.addFlashAttribute("success", "✅ Allocation request sent to Tour Crew Manager!");
            log.info("✅ Allocation request created for booking {}", bookingId);
        } catch (Exception e) {
            log.error("❌ Error creating allocation request: {}", e.getMessage(), e);
            ra.addFlashAttribute("error", "Error creating allocation request: " + e.getMessage());
        }
        
        return "redirect:/booking-officer/dashboard";
    }

    @PostMapping("/assign-resources/{bookingId}")
    public String assignResources(@PathVariable Long bookingId,
                                  @RequestParam(required = false) Long jeepId,
                                  @RequestParam(required = false) Long guideId,
                                  RedirectAttributes ra) {
        log.info("📌 Assigning resources to booking {}: Jeep={}, Guide={}", bookingId, jeepId, guideId);
        
        try {
            Booking booking = bookingRepository.findById(bookingId)
                    .orElseThrow(() -> new IllegalArgumentException("Booking not found"));
            
            if (jeepId != null) {
                Jeep jeep = jeepRepository.findById(jeepId)
                        .orElseThrow(() -> new IllegalArgumentException("Jeep not found"));
                booking.setJeep(jeep);
            }
            
            if (guideId != null) {
                Guide guide = guideRepository.findById(guideId)
                        .orElseThrow(() -> new IllegalArgumentException("Guide not found"));
                booking.setGuide(guide);
            }
            
            bookingRepository.save(booking);
            ra.addFlashAttribute("success", "Resources assigned successfully to booking #" + bookingId);
            log.info("✅ Resources assigned to booking {}", bookingId);
            
        } catch (Exception e) {
            log.error("❌ Error assigning resources: {}", e.getMessage(), e);
            ra.addFlashAttribute("error", "Error assigning resources: " + e.getMessage());
        }
        
        return "redirect:/booking-officer/dashboard";
    }
}
