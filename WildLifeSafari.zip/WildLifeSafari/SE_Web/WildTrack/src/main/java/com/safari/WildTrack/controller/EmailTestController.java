package com.safari.WildTrack.controller;

import com.safari.WildTrack.service.EmailService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class EmailTestController {

    private final EmailService emailService;

    public EmailTestController(EmailService emailService) {
        this.emailService = emailService;
    }

    @GetMapping("/test-email")
    public String testEmail(@RequestParam String email) {
        try {
            emailService.sendOtp(email, "123456");
            return "✅ Test email sent to: " + email + ". Check your inbox and console logs!";
        } catch (Exception e) {
            return "❌ Failed to send email: " + e.getMessage();
        }
    }
}
