package com.safari.WildTrack.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Entity
@Table(name = "feedbacks")
public class Feedback {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(optional = false, fetch = FetchType.EAGER)
    @JoinColumn(name = "user_id")
    private User user;

    @ManyToOne(optional = false, fetch = FetchType.EAGER)
    @JoinColumn(name = "booking_id")
    private Booking booking;

    private int overallRating; // 1-5 stars
    private int serviceRating; // 1-5 stars for service quality
    private int guideRating; // 1-5 stars for guide performance
    private int vehicleRating; // 1-5 stars for vehicle condition
    private int experienceRating; // 1-5 stars for overall experience

    @Column(length = 2000)
    private String comment;

    @Column(length = 500)
    private String serviceComment;

    @Column(length = 500)
    private String guideComment;

    @Column(length = 500)
    private String vehicleComment;

    private boolean wouldRecommend;

    private LocalDateTime createdAt;
}


