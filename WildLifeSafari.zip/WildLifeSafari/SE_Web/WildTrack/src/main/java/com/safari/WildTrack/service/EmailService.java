package com.safari.WildTrack.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class EmailService {

    private static final Logger log = LoggerFactory.getLogger(EmailService.class);

    private final JavaMailSender mailSender;
    private final String fromAddress;

    public EmailService(JavaMailSender mailSender,
                        @Value("${spring.mail.from:}") String fromAddress) {
        this.mailSender = mailSender;
        this.fromAddress = fromAddress;
    }

    public void sendOtp(String to, String otp) {
        // ALWAYS show OTP in console for backup
        log.info("==========================================");
        log.info("🔐 OTP VERIFICATION CODE GENERATED");
        log.info("📧 Sending to Email: {}", to);
        log.info("🔢 OTP Code: {}", otp);
        log.info("⏰ Valid for: 10 minutes");
        log.info("==========================================");
        
        try {
            log.info("🚀 Attempting to send real email to: {}", to);
            
            SimpleMailMessage message = new SimpleMailMessage();
            message.setFrom("wildtracksafari2024@gmail.com");
            message.setTo(to);
            message.setSubject("WildTrack Safari - Email Verification Code");
            
            String emailBody = "Dear Safari Adventurer,\n\n" +
                    "Welcome to WildTrack Safari Adventures!\n\n" +
                    "Your email verification code is: " + otp + "\n\n" +
                    "Please enter this code on the verification page to complete your registration.\n\n" +
                    "This code will expire in 10 minutes for security reasons.\n\n" +
                    "If you didn't request this verification, please ignore this email.\n\n" +
                    "Best regards,\n" +
                    "The WildTrack Safari Team\n" +
                    "🦁 Experience the Wild!";
            
            message.setText(emailBody);
            
            log.info("📤 Sending email via Gmail SMTP to: {}", to);
            mailSender.send(message);
            log.info("✅ SUCCESS! OTP email sent to your Gmail: {}", to);
            log.info("📬 Please check your inbox (and spam folder) for the verification code");
            
        } catch (Exception ex) {
            log.error("❌ FAILED to send email to {}: {}", to, ex.getMessage());
            log.error("📋 Full error details:", ex);
            
            if (ex.getMessage().contains("Authentication failed") || ex.getMessage().contains("Username and Password not accepted")) {
                log.error("🔐 AUTHENTICATION ERROR: Gmail requires App Password, not regular password!");
                log.error("📖 Please follow the setup guide: GMAIL_APP_PASSWORD_SETUP.md");
                log.error("🔧 Steps: Enable 2FA → Generate App Password → Update application.properties");
            } else if (ex.getMessage().contains("Connection timed out")) {
                log.error("🌐 CONNECTION ERROR: Check internet connection and firewall settings");
            } else {
                log.error("🔧 Email configuration might need adjustment");
            }
            
            log.info("📧 BACKUP: Use this OTP code from console: {}", otp);
            log.info("💡 Copy this code: {}", otp);
        }
    }

    public void sendBookingConfirmation(String to, String bookingDetails) {
        try {
            SimpleMailMessage message = new SimpleMailMessage();
            if (fromAddress != null && !fromAddress.isBlank()) {
                message.setFrom(fromAddress);
            }
            message.setTo(to);
            message.setSubject("WildTrack Booking Confirmation");
            message.setText("Your booking has been confirmed: " + bookingDetails);
            mailSender.send(message);
        } catch (Exception ex) {
            log.info("[DEV] Email sending skipped or failed. Booking confirmation for {} is {}", to, bookingDetails);
        }
    }
}


