package com.safari.WildTrack.service;

import com.safari.WildTrack.model.User;
import com.safari.WildTrack.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.stream.Collectors;

@Service
public class CustomUserDetailsService implements UserDetailsService {

    private static final Logger log = LoggerFactory.getLogger(CustomUserDetailsService.class);
    private final UserRepository userRepository;

    public CustomUserDetailsService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        log.info("🔐 Login attempt for email: {}", email);
        
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> {
                    log.error("❌ User not found: {}", email);
                    return new UsernameNotFoundException("User not found: " + email);
                });

        log.info("✅ User found: {} (ID: {})", user.getFullName(), user.getId());
        log.info("📧 Email verified: {}", user.isEmailVerified());
        log.info("👤 Roles: {}", user.getRoles());

        if (!user.isEmailVerified()) {
            log.error("❌ Email not verified for user: {}", email);
            throw new UsernameNotFoundException("Email not verified for user: " + email);
        }

        Collection<GrantedAuthority> authorities = user.getRoles().stream()
                .map(role -> new SimpleGrantedAuthority("ROLE_" + role.name()))
                .collect(Collectors.toList());

        log.info("🔑 Authorities granted: {}", authorities);
        log.info("✅ Login successful for: {}", email);

        return org.springframework.security.core.userdetails.User.builder()
                .username(user.getEmail())
                .password(user.getPasswordHash())
                .authorities(authorities)
                .build();
    }
}
