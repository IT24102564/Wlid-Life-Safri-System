package com.safari.WildTrack.controller;

import com.safari.WildTrack.model.User;
import com.safari.WildTrack.model.Booking;
import com.safari.WildTrack.enums.BookingStatus;
import com.safari.WildTrack.repository.UserRepository;
import com.safari.WildTrack.repository.BookingRepository;
import com.safari.WildTrack.service.BookingService;
import com.safari.WildTrack.service.FeedbackService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/profile")
public class UserProfileController {

    private static final Logger log = LoggerFactory.getLogger(UserProfileController.class);
    private final UserRepository userRepository;
    private final BookingRepository bookingRepository;
    private final BookingService bookingService;
    private final FeedbackService feedbackService;

    public UserProfileController(UserRepository userRepository,
                                 BookingRepository bookingRepository,
                                 BookingService bookingService, 
                                 FeedbackService feedbackService) {
        this.userRepository = userRepository;
        this.bookingRepository = bookingRepository;
        this.bookingService = bookingService;
        this.feedbackService = feedbackService;
    }

    @GetMapping("/bookings")
    public String myBookings(Authentication auth, Model model) {
        log.info("📅 Loading user bookings");
        
        if (auth == null) {
            return "redirect:/login";
        }
        
        String email = auth.getName();
        User user = userRepository.findByEmail(email).orElse(null);
        
        if (user == null) {
            return "redirect:/login";
        }
        
        model.addAttribute("user", user);
        try {
            var bookings = bookingService.getBookingsByUser(email);
            model.addAttribute("bookings", bookings);
            log.info("✅ Loaded {} bookings for user: {}", bookings.size(), email);
            
            // Calculate booking statistics
            int totalBookings = bookings.size();
            int confirmedBookings = 0;
            int pendingBookings = 0;
            int upcomingBookings = 0;
            
            java.time.LocalDate today = java.time.LocalDate.now();
            
            for (var booking : bookings) {
                if (booking.getStatus().name().equals("CONFIRMED")) {
                    confirmedBookings++;
                    if (booking.getSafariDate().isAfter(today) || booking.getSafariDate().isEqual(today)) {
                        upcomingBookings++;
                    }
                } else if (booking.getStatus().name().equals("PENDING")) {
                    pendingBookings++;
                }
            }
            
            // Add statistics to model
            model.addAttribute("totalBookings", totalBookings);
            model.addAttribute("confirmedBookings", confirmedBookings);
            model.addAttribute("pendingBookings", pendingBookings);
            model.addAttribute("upcomingBookings", upcomingBookings);
            
            // Debug: Log each booking ID to check for duplicates
            for (int i = 0; i < bookings.size(); i++) {
                var booking = bookings.get(i);
                log.info("📋 Booking {}: ID={}, Package={}, Date={}, Status={}", 
                    i + 1, booking.getId(), booking.getSafariPackage().getName(), 
                    booking.getSafariDate(), booking.getStatus());
            }
            
            log.info("📊 Booking Stats - Total: {}, Confirmed: {}, Pending: {}, Upcoming: {}", 
                totalBookings, confirmedBookings, pendingBookings, upcomingBookings);
                
        } catch (Exception e) {
            log.error("❌ Failed to load bookings for user {}: {}", email, e.getMessage(), e);
            model.addAttribute("bookings", java.util.Collections.emptyList());
            model.addAttribute("totalBookings", 0);
            model.addAttribute("confirmedBookings", 0);
            model.addAttribute("pendingBookings", 0);
            model.addAttribute("upcomingBookings", 0);
            model.addAttribute("error", "Unable to load bookings at this time. Error: " + e.getMessage());
        }
        return "user-bookings";
    }

    @GetMapping("/feedback")
    public String myFeedback(Authentication auth, Model model) {
        if (auth == null) {
            return "redirect:/login";
        }
        
        String email = auth.getName();
        User user = userRepository.findByEmail(email).orElse(null);
        
        if (user == null) {
            return "redirect:/login";
        }
        
        model.addAttribute("user", user);
        model.addAttribute("feedbacks", feedbackService.getAllFeedback());
        return "user-feedback";
    }

    @GetMapping("/edit")
    public String editProfile(Authentication auth, Model model) {
        log.info("👤 Loading edit profile page");
        
        if (auth == null) {
            return "redirect:/login";
        }
        
        String email = auth.getName();
        User user = userRepository.findByEmail(email).orElse(null);
        
        if (user == null) {
            return "redirect:/login";
        }
        
        model.addAttribute("user", user);
        log.info("✅ Edit profile page loaded for: {}", email);
        return "edit-profile";
    }

    @PostMapping("/update")
    public String updateProfile(Authentication auth,
                               @RequestParam String fullName,
                               @RequestParam(required = false) String phone,
                               @RequestParam(required = false) String address,
                               RedirectAttributes ra) {
        log.info("💾 Updating user profile");
        
        if (auth == null) {
            return "redirect:/login";
        }
        
        try {
            String email = auth.getName();
            User user = userRepository.findByEmail(email).orElse(null);
            
            if (user == null) {
                return "redirect:/login";
            }
            
            user.setFullName(fullName);
            if (phone != null && !phone.trim().isEmpty()) {
                user.setPhone(phone.trim());
            }
            if (address != null && !address.trim().isEmpty()) {
                user.setAddress(address.trim());
            }
            
            userRepository.save(user);
            
            log.info("✅ Profile updated successfully for: {}", email);
            ra.addFlashAttribute("success", "Profile updated successfully!");
            return "redirect:/profile/edit";
            
        } catch (Exception e) {
            log.error("❌ Failed to update profile: {}", e.getMessage(), e);
            ra.addFlashAttribute("error", "Failed to update profile. Please try again.");
            return "redirect:/profile/edit";
        }
    }

    // User confirms modified booking
    @PostMapping("/confirm-booking/{bookingId}")
    public String confirmModifiedBooking(@PathVariable Long bookingId, 
                                         Authentication auth,
                                         RedirectAttributes ra) {
        log.info("✅ User confirming modified booking: {}", bookingId);
        
        if (auth == null) {
            return "redirect:/login";
        }
        
        try {
            String email = auth.getName();
            User user = userRepository.findByEmail(email).orElseThrow();
            
            Booking booking = bookingRepository.findById(bookingId)
                    .orElseThrow(() -> new IllegalArgumentException("Booking not found"));
            
            // Verify booking belongs to this user
            if (!booking.getUser().getId().equals(user.getId())) {
                ra.addFlashAttribute("error", "❌ Unauthorized access!");
                return "redirect:/profile/bookings";
            }
            
            // Check if booking is in PENDING_USER_CONFIRMATION status
            if (booking.getStatus() != BookingStatus.PENDING_USER_CONFIRMATION) {
                ra.addFlashAttribute("error", "⚠️ This booking is not awaiting your confirmation!");
                return "redirect:/profile/bookings";
            }
            
            // User confirmed - change status back to PENDING so Booking Officer can approve
            booking.setStatus(BookingStatus.PENDING);
            booking.setUpdatedAt(java.time.LocalDateTime.now());
            bookingRepository.save(booking);
            
            ra.addFlashAttribute("success", "✅ You have confirmed the modified booking! Waiting for Booking Officer final approval.");
            log.info("✅ User {} confirmed booking {}", email, bookingId);
            
        } catch (Exception e) {
            log.error("❌ Error confirming booking: {}", e.getMessage(), e);
            ra.addFlashAttribute("error", "❌ Error confirming booking: " + e.getMessage());
        }
        
        return "redirect:/profile/bookings";
    }

    // User cancels modified booking
    @PostMapping("/cancel-booking/{bookingId}")
    public String cancelModifiedBooking(@PathVariable Long bookingId,
                                        Authentication auth,
                                        RedirectAttributes ra) {
        log.info("❌ User canceling modified booking: {}", bookingId);
        
        if (auth == null) {
            return "redirect:/login";
        }
        
        try {
            String email = auth.getName();
            User user = userRepository.findByEmail(email).orElseThrow();
            
            Booking booking = bookingRepository.findById(bookingId)
                    .orElseThrow(() -> new IllegalArgumentException("Booking not found"));
            
            // Verify booking belongs to this user
            if (!booking.getUser().getId().equals(user.getId())) {
                ra.addFlashAttribute("error", "❌ Unauthorized access!");
                return "redirect:/profile/bookings";
            }
            
            // Check if booking is in PENDING_USER_CONFIRMATION status
            if (booking.getStatus() != BookingStatus.PENDING_USER_CONFIRMATION) {
                ra.addFlashAttribute("error", "⚠️ This booking is not awaiting your confirmation!");
                return "redirect:/profile/bookings";
            }
            
            // User rejected the modified booking - cancel it
            booking.setStatus(BookingStatus.CANCELLED);
            booking.setUpdatedAt(java.time.LocalDateTime.now());
            bookingRepository.save(booking);
            
            ra.addFlashAttribute("success", "✅ Booking cancelled successfully. You can create a new booking if needed.");
            log.info("✅ User {} cancelled booking {}", email, bookingId);
            
        } catch (Exception e) {
            log.error("❌ Error cancelling booking: {}", e.getMessage(), e);
            ra.addFlashAttribute("error", "❌ Error cancelling booking: " + e.getMessage());
        }
        
        return "redirect:/profile/bookings";
    }
}
