package com.safari.WildTrack.enums;

public enum Role {
    TOURIST,
    BOOKING_OFFICER,
    PACKAGE_BUILDER,
    MAINTENANCE_OFFICER,
    MECHANIC,
    TOUR_MANAGER,
    CREW_MANAGER,
    PARK_MANAGER,
    DRIVER,
    GUIDE,
    IT_SUPPORT,
    ADMIN
}


