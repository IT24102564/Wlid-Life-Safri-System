package com.safari.WildTrack.controller;

import com.safari.WildTrack.model.SafariPackage;
import com.safari.WildTrack.repository.SafariPackageRepository;
import com.safari.WildTrack.repository.BookingRepository;
import com.safari.WildTrack.enums.SafariType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/search")
public class SearchController {

    private static final Logger log = LoggerFactory.getLogger(SearchController.class);
    private final SafariPackageRepository packageRepository;
    private final BookingRepository bookingRepository;

    public SearchController(SafariPackageRepository packageRepository,
                           BookingRepository bookingRepository) {
        this.packageRepository = packageRepository;
        this.bookingRepository = bookingRepository;
    }

    @GetMapping("")
    public String searchPage(Model model) {
        log.info("🔍 Loading safari search page");
        
        // Load all packages for initial display
        var allPackages = packageRepository.findAll();
        model.addAttribute("packages", allPackages);
        model.addAttribute("safariTypes", SafariType.values());
        
        // Add filter options
        model.addAttribute("minPrice", getMinPrice());
        model.addAttribute("maxPrice", getMaxPrice());
        
        log.info("✅ Loaded {} packages for search", allPackages.size());
        return "safari-search";
    }

    @GetMapping("/filter")
    public String searchWithFilters(@RequestParam(required = false) String date,
                                   @RequestParam(required = false) BigDecimal minPrice,
                                   @RequestParam(required = false) BigDecimal maxPrice,
                                   @RequestParam(required = false) SafariType type,
                                   @RequestParam(required = false) Integer minGuests,
                                   @RequestParam(required = false) Boolean available,
                                   Model model) {
        
        log.info("🔍 Searching safaris with filters - Date: {}, Price: {}-{}, Type: {}, MinGuests: {}, Available: {}", 
            date, minPrice, maxPrice, type, minGuests, available);

        List<SafariPackage> filteredPackages = packageRepository.findAll().stream()
                .filter(pkg -> {
                    // Price filter
                    if (minPrice != null && pkg.getPrice().compareTo(minPrice) < 0) {
                        return false;
                    }
                    if (maxPrice != null && pkg.getPrice().compareTo(maxPrice) > 0) {
                        return false;
                    }
                    
                    // Type filter
                    if (type != null && !pkg.getType().equals(type)) {
                        return false;
                    }
                    
                    // Guest capacity filter
                    if (minGuests != null && pkg.getMaxGuests() < minGuests) {
                        return false;
                    }
                    
                    // Availability filter (check if there are available slots for the date)
                    if (available != null && available && date != null) {
                        try {
                            LocalDate searchDate = LocalDate.parse(date);
                            long bookingsOnDate = bookingRepository.findBySafariDate(searchDate).stream()
                                    .filter(booking -> booking.getSafariPackage().getId().equals(pkg.getId()))
                                    .count();
                            // Assume max 5 bookings per package per day
                            return bookingsOnDate < 5;
                        } catch (Exception e) {
                            log.warn("Error parsing date or checking availability: {}", e.getMessage());
                        }
                    }
                    
                    return true;
                })
                .collect(Collectors.toList());

        model.addAttribute("packages", filteredPackages);
        model.addAttribute("safariTypes", SafariType.values());
        model.addAttribute("minPrice", getMinPrice());
        model.addAttribute("maxPrice", getMaxPrice());
        
        // Keep filter values in form
        model.addAttribute("selectedDate", date);
        model.addAttribute("selectedMinPrice", minPrice);
        model.addAttribute("selectedMaxPrice", maxPrice);
        model.addAttribute("selectedType", type);
        model.addAttribute("selectedMinGuests", minGuests);
        model.addAttribute("selectedAvailable", available);
        
        model.addAttribute("searchPerformed", true);
        model.addAttribute("resultCount", filteredPackages.size());

        log.info("✅ Found {} packages matching filters", filteredPackages.size());
        return "safari-search";
    }

    private BigDecimal getMinPrice() {
        return packageRepository.findAll().stream()
                .map(SafariPackage::getPrice)
                .min(BigDecimal::compareTo)
                .orElse(BigDecimal.ZERO);
    }

    private BigDecimal getMaxPrice() {
        return packageRepository.findAll().stream()
                .map(SafariPackage::getPrice)
                .max(BigDecimal::compareTo)
                .orElse(BigDecimal.valueOf(1000));
    }
}
