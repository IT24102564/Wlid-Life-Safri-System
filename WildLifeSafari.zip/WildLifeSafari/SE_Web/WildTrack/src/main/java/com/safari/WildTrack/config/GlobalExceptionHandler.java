package com.safari.WildTrack.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.servlet.ModelAndView;

@ControllerAdvice
public class GlobalExceptionHandler {

    private static final Logger log = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    @ExceptionHandler(Exception.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ModelAndView handleGenericException(Exception e) {
        log.error("🚨 Unhandled exception occurred: {}", e.getMessage(), e);
        
        ModelAndView mav = new ModelAndView("error");
        mav.addObject("statusCode", 500);
        mav.addObject("errorTitle", "Internal Server Error");
        mav.addObject("errorDescription", "Something went wrong. Our team has been notified.");
        mav.addObject("errorMessage", e.getMessage());
        mav.addObject("requestUri", "Unknown");
        
        return mav;
    }

    @ExceptionHandler(RuntimeException.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ModelAndView handleRuntimeException(RuntimeException e) {
        log.error("🚨 Runtime exception occurred: {}", e.getMessage(), e);
        
        ModelAndView mav = new ModelAndView("error");
        mav.addObject("statusCode", 500);
        mav.addObject("errorTitle", "Application Error");
        mav.addObject("errorDescription", "A runtime error occurred. Please try again.");
        mav.addObject("errorMessage", e.getMessage());
        mav.addObject("requestUri", "Unknown");
        
        return mav;
    }

    @ExceptionHandler(IllegalArgumentException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ModelAndView handleIllegalArgumentException(IllegalArgumentException e) {
        log.warn("⚠️ Invalid argument: {}", e.getMessage());
        
        ModelAndView mav = new ModelAndView("error");
        mav.addObject("statusCode", 400);
        mav.addObject("errorTitle", "Invalid Request");
        mav.addObject("errorDescription", "The request contains invalid data.");
        mav.addObject("errorMessage", e.getMessage());
        mav.addObject("requestUri", "Unknown");
        
        return mav;
    }
}
