package com.safari.WildTrack.repository;

import com.safari.WildTrack.model.ResourceAllocation;
import com.safari.WildTrack.model.Booking;
import com.safari.WildTrack.enums.AllocationStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface ResourceAllocationRepository extends JpaRepository<ResourceAllocation, Long> {
    Optional<ResourceAllocation> findByBooking(Booking booking);
    boolean existsByBooking(Booking booking);
    List<ResourceAllocation> findByStatus(AllocationStatus status);
    List<ResourceAllocation> findByStatusOrderByRequestedAtDesc(AllocationStatus status);
}
