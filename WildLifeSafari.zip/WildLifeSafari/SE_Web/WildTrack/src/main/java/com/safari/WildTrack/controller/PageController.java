package com.safari.WildTrack.controller;

import com.safari.WildTrack.model.SafariPackage;
import com.safari.WildTrack.repository.BookingRepository;
import com.safari.WildTrack.repository.SafariPackageRepository;
import com.safari.WildTrack.repository.JeepRepository;
import com.safari.WildTrack.repository.GuideRepository;
import com.safari.WildTrack.service.BookingService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDate;
@Controller
@RequestMapping("/")
public class PageController {

    private static final Logger log = LoggerFactory.getLogger(PageController.class);
    private final SafariPackageRepository packageRepository;
    private final BookingRepository bookingRepository;
    private final BookingService bookingService;
    private final JeepRepository jeepRepository;
    private final GuideRepository guideRepository;

    public PageController(SafariPackageRepository packageRepository,
                          BookingRepository bookingRepository,
                          BookingService bookingService,
                          JeepRepository jeepRepository,
                          GuideRepository guideRepository) {
        this.packageRepository = packageRepository;
        this.bookingRepository = bookingRepository;
        this.bookingService = bookingService;
        this.jeepRepository = jeepRepository;
        this.guideRepository = guideRepository;
    }

    @GetMapping("/")
    public String home(Model model) {
        model.addAttribute("packages", packageRepository.findAll());
        return "home";
    }

    @GetMapping("login")
    public String loginPage() {
        return "login";
    }

    @GetMapping("packages")
    public String packages(Model model) {
        log.info("🦁 Loading safari packages page");
        try {
            var packages = packageRepository.findAll();
            model.addAttribute("packages", packages);
            log.info("✅ Loaded {} safari packages", packages.size());
            return "packages";
        } catch (Exception e) {
            log.error("❌ Failed to load safari packages: {}", e.getMessage(), e);
            model.addAttribute("error", "Unable to load safari packages at this time.");
            model.addAttribute("packages", java.util.Collections.emptyList());
            return "packages";
        }
    }


    @GetMapping("bookings")
    public String bookings(@RequestParam(required = false) String date, Model model) {
        if (date != null && !date.isEmpty()) {
            model.addAttribute("bookings", bookingRepository.findBySafariDate(LocalDate.parse(date)));
        } else {
            model.addAttribute("bookings", bookingRepository.findAll());
        }
        return "bookings";
    }

    @GetMapping("package/{id}")
    public String packageDetails(@PathVariable Long id, Model model) {
        SafariPackage pkg = packageRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Package not found"));
        model.addAttribute("package", pkg);
        return "package-details";
    }

    @GetMapping("new-booking")
    public String newBooking(Model model) {
        log.info("🎯 Loading new booking page with jeeps and guides");
        try {
            var packages = packageRepository.findAll();
            var availableJeeps = jeepRepository.findByAvailableTrue();
            var availableGuides = guideRepository.findByAvailableTrue();
            
            model.addAttribute("packages", packages);
            model.addAttribute("jeeps", availableJeeps);
            model.addAttribute("guides", availableGuides);
            
            log.info("✅ Loaded {} packages, {} jeeps, {} guides", 
                packages.size(), availableJeeps.size(), availableGuides.size());
            
            return "new-booking";
        } catch (Exception e) {
            log.error("❌ Failed to load booking data: {}", e.getMessage(), e);
            model.addAttribute("error", "Unable to load booking options at this time.");
            model.addAttribute("packages", java.util.Collections.emptyList());
            model.addAttribute("jeeps", java.util.Collections.emptyList());
            model.addAttribute("guides", java.util.Collections.emptyList());
            return "new-booking";
        }
    }

    @PostMapping("create-booking")
    public String createBooking(@RequestParam Long packageId,
                                @RequestParam String safariDate,
                                @RequestParam int numGuests,
                                @RequestParam(required = false) Long jeepId,
                                @RequestParam(required = false) Long guideId,
                                Authentication auth,
                                RedirectAttributes ra) {
        log.info("📅 Creating new booking - Package: {}, Date: {}, Guests: {}, Jeep: {}, Guide: {}", 
            packageId, safariDate, numGuests, jeepId, guideId);
        
        try {
            // Check if user is logged in
            if (auth == null) {
                log.warn("❌ User not logged in, redirecting to login");
                ra.addFlashAttribute("error", "Please login to create a booking.");
                return "redirect:/login";
            }
            
            String userEmail = auth.getName();
            log.info("👤 Creating booking for user: {}", userEmail);
            
            // Create the booking using BookingService with selected jeep and guide
            var booking = bookingService.createBooking(userEmail, packageId, LocalDate.parse(safariDate), numGuests, jeepId, guideId);
            
            log.info("✅ Booking created successfully for user: {} - Booking ID: {}", userEmail, booking.getId());
            ra.addFlashAttribute("success", "Booking created successfully! Booking ID: #" + booking.getId() + ". You can view it in your bookings.");
            return "redirect:/profile/bookings";
            
        } catch (Exception e) {
            log.error("❌ Failed to create booking: {}", e.getMessage(), e);
            ra.addFlashAttribute("error", "Error creating booking: " + e.getMessage());
            return "redirect:/new-booking";
        }
    }
}


