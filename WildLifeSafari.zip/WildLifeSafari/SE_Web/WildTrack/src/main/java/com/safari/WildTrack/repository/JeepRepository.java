package com.safari.WildTrack.repository;

import com.safari.WildTrack.model.Jeep;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface JeepRepository extends JpaRepository<Jeep, Long> {
    List<Jeep> findByAvailableTrue();
    Optional<Jeep> findFirstByAvailableTrue();
}


