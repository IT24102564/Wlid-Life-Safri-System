package com.safari.WildTrack.service;

import com.safari.WildTrack.model.*;
import com.safari.WildTrack.enums.BookingStatus;
import com.safari.WildTrack.enums.AllocationStatus;
import com.safari.WildTrack.repository.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Service
public class ResourceAllocationService {
    
    private static final Logger log = LoggerFactory.getLogger(ResourceAllocationService.class);
    
    private final ResourceAllocationRepository allocationRepository;
    private final BookingRepository bookingRepository;
    private final UserRepository userRepository;
    private final GuideRepository guideRepository;
    private final JeepRepository jeepRepository;
    
    public ResourceAllocationService(ResourceAllocationRepository allocationRepository,
                                    BookingRepository bookingRepository,
                                    UserRepository userRepository,
                                    GuideRepository guideRepository,
                                    JeepRepository jeepRepository) {
        this.allocationRepository = allocationRepository;
        this.bookingRepository = bookingRepository;
        this.userRepository = userRepository;
        this.guideRepository = guideRepository;
        this.jeepRepository = jeepRepository;
    }
    
    // Booking Officer creates allocation request
    @Transactional
    public ResourceAllocation createAllocationRequest(Long bookingId, Long driverId, Long guideId, 
                                                     Long jeepId, String officerEmail, String notes) {
        log.info("📋 Creating allocation request for booking {}", bookingId);
        
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new IllegalArgumentException("Booking not found"));
        
        if (booking.getStatus() != BookingStatus.CONFIRMED && booking.getStatus() != BookingStatus.PENDING) {
            throw new IllegalStateException("Booking must be PENDING or CONFIRMED before requesting allocation");
        }
        
        if (allocationRepository.existsByBooking(booking)) {
            throw new IllegalStateException("Allocation request already exists for this booking");
        }
        
        User driver = userRepository.findById(driverId)
                .orElseThrow(() -> new IllegalArgumentException("Driver not found"));
        Guide guide = guideRepository.findById(guideId)
                .orElseThrow(() -> new IllegalArgumentException("Guide not found"));
        Jeep jeep = jeepRepository.findById(jeepId)
                .orElseThrow(() -> new IllegalArgumentException("Jeep not found"));
        User officer = userRepository.findByEmail(officerEmail)
                .orElseThrow(() -> new IllegalArgumentException("Booking Officer not found"));
        
        ResourceAllocation allocation = ResourceAllocation.builder()
                .booking(booking)
                .requestedDriver(driver)
                .requestedGuide(guide)
                .requestedJeep(jeep)
                .requestedBy(officer)
                .requestedAt(LocalDateTime.now())
                .status(AllocationStatus.PENDING_APPROVAL)
                .officerNotes(notes)
                .build();
        
        ResourceAllocation saved = allocationRepository.save(allocation);
        log.info("✅ Allocation request created for booking {}", bookingId);
        
        return saved;
    }
    
    // Tour Crew Manager approves allocation
    @Transactional
    public ResourceAllocation approveAllocation(Long allocationId, String managerEmail, String notes) {
        log.info("✅ Approving allocation {}", allocationId);
        
        ResourceAllocation allocation = allocationRepository.findById(allocationId)
                .orElseThrow(() -> new IllegalArgumentException("Allocation not found"));
        
        if (allocation.getStatus() != AllocationStatus.PENDING_APPROVAL) {
            throw new IllegalStateException("Allocation is not pending approval");
        }
        
        User manager = userRepository.findByEmail(managerEmail)
                .orElseThrow(() -> new IllegalArgumentException("Tour Crew Manager not found"));
        
        // Approve with requested resources
        allocation.setApprovedDriver(allocation.getRequestedDriver());
        allocation.setApprovedGuide(allocation.getRequestedGuide());
        allocation.setApprovedJeep(allocation.getRequestedJeep());
        allocation.setReviewedBy(manager);
        allocation.setReviewedAt(LocalDateTime.now());
        allocation.setStatus(AllocationStatus.APPROVED);
        allocation.setManagerNotes(notes);
        
        // Update booking with allocated resources (but keep status PENDING)
        // Booking Officer must still approve before it becomes CONFIRMED
        Booking booking = allocation.getBooking();
        booking.setDriver(allocation.getApprovedDriver());
        booking.setGuide(allocation.getApprovedGuide());
        booking.setJeep(allocation.getApprovedJeep());
        // Status stays PENDING - Booking Officer must approve
        booking.setUpdatedAt(LocalDateTime.now());
        bookingRepository.save(booking);
        
        ResourceAllocation saved = allocationRepository.save(allocation);
        log.info("✅ Allocation approved for booking {} - Awaiting Booking Officer confirmation", booking.getId());
        
        return saved;
    }
    
    // Tour Crew Manager modifies and approves allocation
    @Transactional
    public ResourceAllocation modifyAndApproveAllocation(Long allocationId, Long driverId, Long guideId, 
                                                        Long jeepId, String managerEmail, String notes) {
        log.info("✏️ Modifying allocation {}", allocationId);
        
        ResourceAllocation allocation = allocationRepository.findById(allocationId)
                .orElseThrow(() -> new IllegalArgumentException("Allocation not found"));
        
        if (allocation.getStatus() != AllocationStatus.PENDING_APPROVAL) {
            throw new IllegalStateException("Allocation is not pending approval");
        }
        
        User driver = userRepository.findById(driverId)
                .orElseThrow(() -> new IllegalArgumentException("Driver not found"));
        Guide guide = guideRepository.findById(guideId)
                .orElseThrow(() -> new IllegalArgumentException("Guide not found"));
        Jeep jeep = jeepRepository.findById(jeepId)
                .orElseThrow(() -> new IllegalArgumentException("Jeep not found"));
        User manager = userRepository.findByEmail(managerEmail)
                .orElseThrow(() -> new IllegalArgumentException("Tour Crew Manager not found"));
        
        // Set modified resources
        allocation.setApprovedDriver(driver);
        allocation.setApprovedGuide(guide);
        allocation.setApprovedJeep(jeep);
        allocation.setReviewedBy(manager);
        allocation.setReviewedAt(LocalDateTime.now());
        allocation.setStatus(AllocationStatus.MODIFIED);
        allocation.setManagerNotes(notes);
        
        // Update booking with modified resources
        // Status changes to PENDING_USER_CONFIRMATION so user can see and confirm/cancel
        Booking booking = allocation.getBooking();
        booking.setDriver(allocation.getApprovedDriver());
        booking.setGuide(allocation.getApprovedGuide());
        booking.setJeep(allocation.getApprovedJeep());
        booking.setStatus(BookingStatus.PENDING_USER_CONFIRMATION);
        booking.setUpdatedAt(LocalDateTime.now());
        bookingRepository.save(booking);
        
        ResourceAllocation saved = allocationRepository.save(allocation);
        log.info("✅ Allocation modified - Awaiting user confirmation for booking {}", booking.getId());
        
        return saved;
    }
    
    // Tour Crew Manager rejects allocation
    @Transactional
    public ResourceAllocation rejectAllocation(Long allocationId, String managerEmail, String reason) {
        log.info("❌ Rejecting allocation {}", allocationId);
        
        ResourceAllocation allocation = allocationRepository.findById(allocationId)
                .orElseThrow(() -> new IllegalArgumentException("Allocation not found"));
        
        if (allocation.getStatus() != AllocationStatus.PENDING_APPROVAL) {
            throw new IllegalStateException("Allocation is not pending approval");
        }
        
        User manager = userRepository.findByEmail(managerEmail)
                .orElseThrow(() -> new IllegalArgumentException("Tour Crew Manager not found"));
        
        allocation.setReviewedBy(manager);
        allocation.setReviewedAt(LocalDateTime.now());
        allocation.setStatus(AllocationStatus.REJECTED);
        allocation.setRejectionReason(reason);
        
        ResourceAllocation saved = allocationRepository.save(allocation);
        log.info("❌ Allocation rejected for booking {}", allocation.getBooking().getId());
        
        return saved;
    }
}
