package com.safari.WildTrack.repository;

// Split into separate files per repository to satisfy Java's public type rule.


