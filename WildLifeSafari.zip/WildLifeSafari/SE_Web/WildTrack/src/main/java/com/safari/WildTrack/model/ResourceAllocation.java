package com.safari.WildTrack.model;

import com.safari.WildTrack.enums.AllocationStatus;
import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "resource_allocations")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ResourceAllocation {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @OneToOne
    @JoinColumn(name = "booking_id", nullable = false, unique = true)
    private Booking booking;
    
    @ManyToOne
    @JoinColumn(name = "requested_driver_id")
    private User requestedDriver;
    
    @ManyToOne
    @JoinColumn(name = "requested_guide_id")
    private Guide requestedGuide;
    
    @ManyToOne
    @JoinColumn(name = "requested_jeep_id")
    private Jeep requestedJeep;
    
    @ManyToOne
    @JoinColumn(name = "approved_driver_id")
    private User approvedDriver;
    
    @ManyToOne
    @JoinColumn(name = "approved_guide_id")
    private Guide approvedGuide;
    
    @ManyToOne
    @JoinColumn(name = "approved_jeep_id")
    private Jeep approvedJeep;
    
    @ManyToOne
    @JoinColumn(name = "requested_by")
    private User requestedBy;  // Booking Officer who requested
    
    @ManyToOne
    @JoinColumn(name = "reviewed_by")
    private User reviewedBy;  // Tour Crew Manager who reviewed
    
    @Column(name = "requested_at")
    private LocalDateTime requestedAt;
    
    @Column(name = "reviewed_at")
    private LocalDateTime reviewedAt;
    
    @Enumerated(EnumType.STRING)
    @Column(name = "status")
    private AllocationStatus status;
    
    @Column(name = "officer_notes")
    private String officerNotes;  // Notes from Booking Officer
    
    @Column(name = "manager_notes")
    private String managerNotes;  // Notes from Tour Crew Manager
    
    @Column(name = "rejection_reason")
    private String rejectionReason;  // Reason if rejected
}
