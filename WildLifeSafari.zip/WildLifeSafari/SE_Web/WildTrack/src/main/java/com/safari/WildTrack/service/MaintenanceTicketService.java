package com.safari.WildTrack.service;

import com.safari.WildTrack.model.MaintenanceTicket;
import com.safari.WildTrack.model.User;
import com.safari.WildTrack.model.Jeep;
import com.safari.WildTrack.enums.TicketStatus;
import com.safari.WildTrack.enums.TicketSeverity;
import com.safari.WildTrack.repository.MaintenanceTicketRepository;
import com.safari.WildTrack.repository.UserRepository;
import com.safari.WildTrack.repository.JeepRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.ArrayList;

@Service
public class MaintenanceTicketService {
    
    private static final Logger log = LoggerFactory.getLogger(MaintenanceTicketService.class);
    
    private final MaintenanceTicketRepository ticketRepository;
    private final UserRepository userRepository;
    private final JeepRepository jeepRepository;
    
    public MaintenanceTicketService(MaintenanceTicketRepository ticketRepository,
                                   UserRepository userRepository,
                                   JeepRepository jeepRepository) {
        this.ticketRepository = ticketRepository;
        this.userRepository = userRepository;
        this.jeepRepository = jeepRepository;
    }
    
    // Create new ticket
    @Transactional
    public MaintenanceTicket createTicket(Long jeepId, String reporterEmail, 
                                         String issueDescription, TicketSeverity severity) {
        log.info("🔧 Creating maintenance ticket for jeep ID: {}", jeepId);
        
        Jeep jeep = jeepRepository.findById(jeepId)
                .orElseThrow(() -> new IllegalArgumentException("Jeep not found"));
        User reporter = userRepository.findByEmail(reporterEmail)
                .orElseThrow(() -> new IllegalArgumentException("Reporter not found"));
        
        MaintenanceTicket ticket = MaintenanceTicket.builder()
                .jeep(jeep)
                .reportedBy(reporter)
                .issueDescription(issueDescription)
                .severity(severity)
                .status(TicketStatus.UNASSIGNED)
                .createdAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .build();
        
        // Mark jeep as unavailable
        jeep.setAvailable(false);
        jeepRepository.save(jeep);
        
        MaintenanceTicket saved = ticketRepository.save(ticket);
        log.info("✅ Ticket created successfully: ID {}", saved.getId());
        
        return saved;
    }
    
    // Assign ticket to mechanic
    @Transactional
    public MaintenanceTicket assignTicket(Long ticketId, Long mechanicId, String assignerEmail) {
        log.info("👨‍🔧 Assigning ticket {} to mechanic {}", ticketId, mechanicId);
        
        MaintenanceTicket ticket = ticketRepository.findById(ticketId)
                .orElseThrow(() -> new IllegalArgumentException("Ticket not found"));
        User mechanic = userRepository.findById(mechanicId)
                .orElseThrow(() -> new IllegalArgumentException("Mechanic not found"));
        User assigner = userRepository.findByEmail(assignerEmail)
                .orElseThrow(() -> new IllegalArgumentException("Assigner not found"));
        
        ticket.setAssignedMechanic(mechanic);
        ticket.setAssignedBy(assigner);
        ticket.setAssignedAt(LocalDateTime.now());
        ticket.setStatus(TicketStatus.ASSIGNED);
        ticket.setUpdatedAt(LocalDateTime.now());
        
        MaintenanceTicket saved = ticketRepository.save(ticket);
        log.info("✅ Ticket {} assigned to mechanic {}", ticketId, mechanic.getFullName());
        
        return saved;
    }
    
    // Mechanic starts work
    @Transactional
    public MaintenanceTicket startWork(Long ticketId) {
        log.info("🔨 Starting work on ticket {}", ticketId);
        
        MaintenanceTicket ticket = ticketRepository.findById(ticketId)
                .orElseThrow(() -> new IllegalArgumentException("Ticket not found"));
        
        ticket.setStatus(TicketStatus.IN_PROGRESS);
        ticket.setUpdatedAt(LocalDateTime.now());
        
        MaintenanceTicket saved = ticketRepository.save(ticket);
        log.info("✅ Work started on ticket {}", ticketId);
        
        return saved;
    }
    
    // Mechanic completes work
    @Transactional
    public MaintenanceTicket completeWork(Long ticketId, String mechanicNotes) {
        log.info("✅ Completing work on ticket {}", ticketId);
        
        MaintenanceTicket ticket = ticketRepository.findById(ticketId)
                .orElseThrow(() -> new IllegalArgumentException("Ticket not found"));
        
        ticket.setStatus(TicketStatus.COMPLETED);
        ticket.setMechanicNotes(mechanicNotes);
        ticket.setCompletedAt(LocalDateTime.now());
        ticket.setUpdatedAt(LocalDateTime.now());
        
        // Mark jeep as available again
        Jeep jeep = ticket.getJeep();
        jeep.setAvailable(true);
        jeepRepository.save(jeep);
        
        MaintenanceTicket saved = ticketRepository.save(ticket);
        log.info("✅ Ticket {} completed. Jeep {} is now available", ticketId, jeep.getRegistrationNumber());
        
        return saved;
    }
    
    // Get all tickets
    public List<MaintenanceTicket> getAllTickets() {
        return ticketRepository.findAllByOrderByCreatedAtDesc();
    }
    
    // Get unassigned tickets
    public List<MaintenanceTicket> getUnassignedTickets() {
        return ticketRepository.findByStatusOrderByCreatedAtDesc(TicketStatus.UNASSIGNED);
    }
    
    // Get tickets for mechanic
    public List<MaintenanceTicket> getTicketsForMechanic(String mechanicEmail) {
        User mechanic = userRepository.findByEmail(mechanicEmail)
                .orElseThrow(() -> new IllegalArgumentException("Mechanic not found"));
        return ticketRepository.findByAssignedMechanicOrderByCreatedAtDesc(mechanic);
    }
    
    // Get active tickets for mechanic (ASSIGNED or IN_PROGRESS)
    public List<MaintenanceTicket> getActiveTicketsForMechanic(String mechanicEmail) {
        User mechanic = userRepository.findByEmail(mechanicEmail)
                .orElseThrow(() -> new IllegalArgumentException("Mechanic not found"));
        
        List<MaintenanceTicket> activeTickets = new ArrayList<>();
        activeTickets.addAll(ticketRepository.findByAssignedMechanicAndStatusOrderByCreatedAtDesc(mechanic, TicketStatus.ASSIGNED));
        activeTickets.addAll(ticketRepository.findByAssignedMechanicAndStatusOrderByCreatedAtDesc(mechanic, TicketStatus.IN_PROGRESS));
        
        return activeTickets;
    }
    
    // Get ticket statistics
    public long countByStatus(TicketStatus status) {
        return ticketRepository.countByStatus(status);
    }
}
