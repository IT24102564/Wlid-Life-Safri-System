package com.safari.WildTrack.controller;

import com.safari.WildTrack.model.*;
import com.safari.WildTrack.enums.BookingStatus;
import com.safari.WildTrack.enums.AllocationStatus;
import com.safari.WildTrack.enums.Role;
import com.safari.WildTrack.repository.*;
import com.safari.WildTrack.service.ResourceAllocationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/tour-crew-manager")
public class TourCrewManagerController {

    private static final Logger log = LoggerFactory.getLogger(TourCrewManagerController.class);
    
    private final BookingRepository bookingRepository;
    private final UserRepository userRepository;
    private final GuideRepository guideRepository;
    private final JeepRepository jeepRepository;
    private final ResourceAllocationRepository allocationRepository;
    private final ResourceAllocationService allocationService;

    public TourCrewManagerController(BookingRepository bookingRepository,
                                    UserRepository userRepository,
                                    GuideRepository guideRepository,
                                    JeepRepository jeepRepository,
                                    ResourceAllocationRepository allocationRepository,
                                    ResourceAllocationService allocationService) {
        this.bookingRepository = bookingRepository;
        this.userRepository = userRepository;
        this.guideRepository = guideRepository;
        this.jeepRepository = jeepRepository;
        this.allocationRepository = allocationRepository;
        this.allocationService = allocationService;
    }

    @GetMapping("/dashboard")
    public String dashboard(Authentication auth, Model model) {
        log.info("🚗 Loading Tour Crew Manager Dashboard");
        
        if (auth == null) {
            log.warn("❌ Unauthorized access attempt");
            return "redirect:/login";
        }
        
        // Verify user has TOUR_MANAGER role
        boolean hasRole = auth.getAuthorities().stream()
                .anyMatch(a -> a.getAuthority().equals("ROLE_TOUR_MANAGER"));
        
        if (!hasRole) {
            log.warn("❌ Access denied for user: {} - Not a Tour Manager", auth.getName());
            return "redirect:/safe-dashboard";
        }
        
        log.info("✅ Tour Manager authenticated: {}", auth.getName());

        try {
            // Get all bookings
            var allBookings = bookingRepository.findAll();
            
            // Get pending allocation requests from Booking Officer
            var pendingAllocations = allocationRepository.findByStatusOrderByRequestedAtDesc(AllocationStatus.PENDING_APPROVAL);
            
            // Get CONFIRMED bookings (waiting for allocation)
            var confirmedBookings = allBookings.stream()
                    .filter(b -> b.getStatus() == BookingStatus.CONFIRMED)
                    .sorted((b1, b2) -> b1.getSafariDate().compareTo(b2.getSafariDate()))
                    .collect(Collectors.toList());
            
            // Get ALLOCATED bookings
            var allocatedBookings = allBookings.stream()
                    .filter(b -> b.getStatus() == BookingStatus.ALLOCATED)
                    .sorted((b1, b2) -> b2.getUpdatedAt().compareTo(b1.getUpdatedAt()))
                    .collect(Collectors.toList());
            
            // Get today's allocations
            LocalDate today = LocalDate.now();
            var todayAllocations = allocatedBookings.stream()
                    .filter(b -> b.getSafariDate().equals(today))
                    .collect(Collectors.toList());
            
            // Get all drivers (users with DRIVER role)
            var allDrivers = userRepository.findAll().stream()
                    .filter(u -> u.getRoles().contains(Role.DRIVER))
                    .collect(Collectors.toList());
            
            // Get all guides
            var allGuides = guideRepository.findAll();
            
            // Get all jeeps
            var allJeeps = jeepRepository.findAll();
            
            // Calculate statistics
            long totalConfirmed = confirmedBookings.size();
            long totalAllocated = allocatedBookings.size();
            long todayCount = todayAllocations.size();
            long availableDrivers = allDrivers.size();
            long availableGuides = allGuides.stream().filter(Guide::isAvailable).count();
            long availableJeeps = allJeeps.stream().filter(Jeep::isAvailable).count();
            
            // Add to model
            model.addAttribute("pendingAllocations", pendingAllocations);
            model.addAttribute("confirmedBookings", confirmedBookings);
            model.addAttribute("allocatedBookings", allocatedBookings);
            model.addAttribute("todayAllocations", todayAllocations);
            
            model.addAttribute("drivers", allDrivers);
            model.addAttribute("guides", allGuides);
            model.addAttribute("jeeps", allJeeps);
            
            model.addAttribute("totalPendingRequests", pendingAllocations.size());
            model.addAttribute("totalConfirmed", totalConfirmed);
            model.addAttribute("totalAllocated", totalAllocated);
            model.addAttribute("todayCount", todayCount);
            model.addAttribute("availableDrivers", availableDrivers);
            model.addAttribute("availableGuides", availableGuides);
            model.addAttribute("availableJeeps", availableJeeps);
            
            log.info("✅ Dashboard loaded - Confirmed: {}, Allocated: {}", totalConfirmed, totalAllocated);
            
            return "tour-crew-manager-dashboard";
            
        } catch (Exception e) {
            log.error("❌ Error loading dashboard: {}", e.getMessage(), e);
            model.addAttribute("error", "Error loading dashboard: " + e.getMessage());
            return "tour-crew-manager-dashboard";
        }
    }

    // Approve allocation request as-is
    @PostMapping("/approve-allocation/{allocationId}")
    public String approveAllocation(@PathVariable Long allocationId,
                                   @RequestParam(required = false) String notes,
                                   Authentication auth,
                                   RedirectAttributes ra) {
        log.info("✅ Approving allocation {}", allocationId);
        
        try {
            allocationService.approveAllocation(allocationId, auth.getName(), notes);
            ra.addFlashAttribute("success", "✅ Allocation approved! Booking Officer has been notified.");
            log.info("✅ Allocation {} approved", allocationId);
        } catch (Exception e) {
            log.error("❌ Error approving allocation: {}", e.getMessage(), e);
            ra.addFlashAttribute("error", "Error approving allocation: " + e.getMessage());
        }
        
        return "redirect:/tour-crew-manager/dashboard";
    }
    
    // Modify and approve allocation
    @PostMapping("/modify-allocation/{allocationId}")
    public String modifyAllocation(@PathVariable Long allocationId,
                                  @RequestParam Long driverId,
                                  @RequestParam Long guideId,
                                  @RequestParam Long jeepId,
                                  @RequestParam String notes,
                                  Authentication auth,
                                  RedirectAttributes ra) {
        log.info("✏️ Modifying allocation {} with driver={}, guide={}, jeep={}", allocationId, driverId, guideId, jeepId);
        
        try {
            allocationService.modifyAndApproveAllocation(allocationId, driverId, guideId, jeepId,
                                                        auth.getName(), notes);
            ra.addFlashAttribute("success", "✅ Allocation modified! User must confirm the changes before Booking Officer can approve.");
            log.info("✅ Allocation {} modified successfully", allocationId);
        } catch (Exception e) {
            log.error("❌ Error modifying allocation: {}", e.getMessage(), e);
            ra.addFlashAttribute("error", "❌ Error: " + e.getMessage());
        }
        
        return "redirect:/tour-crew-manager/dashboard";
    }
    
    // Reject allocation request
    @PostMapping("/reject-allocation/{allocationId}")
    public String rejectAllocation(@PathVariable Long allocationId,
                                  @RequestParam String reason,
                                  Authentication auth,
                                  RedirectAttributes ra) {
        log.info("❌ Rejecting allocation {}", allocationId);
        
        try {
            allocationService.rejectAllocation(allocationId, auth.getName(), reason);
            ra.addFlashAttribute("success", "❌ Allocation rejected. Booking Officer has been notified.");
            log.info("❌ Allocation {} rejected", allocationId);
        } catch (Exception e) {
            log.error("❌ Error rejecting allocation: {}", e.getMessage(), e);
            ra.addFlashAttribute("error", "Error rejecting allocation: " + e.getMessage());
        }
        
        return "redirect:/tour-crew-manager/dashboard";
    }

    @GetMapping("/allocation-details/{bookingId}")
    @ResponseBody
    public ResourceAllocation getAllocationDetails(@PathVariable Long bookingId) {
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new IllegalArgumentException("Booking not found"));
        
        return allocationRepository.findByBooking(booking)
                .orElse(null);
    }

    // ============= RESOURCE MANAGEMENT =============
    
    @GetMapping("/resources")
    public String manageResources(Authentication auth, Model model) {
        log.info("🔧 Loading Resource Management");
        
        if (!hasRole(auth, "ROLE_TOUR_MANAGER")) {
            return "redirect:/safe-dashboard";
        }
        
        // Get all resources
        var allDrivers = userRepository.findAll().stream()
                .filter(u -> u.getRoles().contains(Role.DRIVER))
                .collect(Collectors.toList());
        var allGuides = guideRepository.findAll();
        var allJeeps = jeepRepository.findAll();
        
        model.addAttribute("drivers", allDrivers);
        model.addAttribute("guides", allGuides);
        model.addAttribute("jeeps", allJeeps);
        
        return "tour-crew-resources";
    }
    
    // ============= DRIVER MANAGEMENT =============
    
    @PostMapping("/driver/create")
    public String createDriver(@RequestParam String fullName,
                              @RequestParam String email,
                              @RequestParam String phone,
                              @RequestParam String licenseNumber,
                              Authentication auth,
                              RedirectAttributes ra) {
        try {
            // Check if email exists
            if (userRepository.findByEmail(email).isPresent()) {
                ra.addFlashAttribute("error", "Email already exists!");
                return "redirect:/tour-crew-manager/resources";
            }
            
            User driver = User.builder()
                    .fullName(fullName)
                    .email(email)
                    .phone(phone)
                    .passwordHash("$2a$10$defaultPasswordHash123456789012345678901234567890123456")
                    .emailVerified(true)
                    .build();
            driver.getRoles().add(Role.DRIVER);
            userRepository.save(driver);
            
            ra.addFlashAttribute("success", "✅ Driver created successfully!");
            log.info("✅ Created driver: {}", email);
            
        } catch (Exception e) {
            log.error("❌ Error creating driver: {}", e.getMessage());
            ra.addFlashAttribute("error", "Error creating driver: " + e.getMessage());
        }
        
        return "redirect:/tour-crew-manager/resources";
    }
    
    @PostMapping("/driver/delete/{id}")
    public String deleteDriver(@PathVariable Long id, RedirectAttributes ra) {
        try {
            userRepository.deleteById(id);
            ra.addFlashAttribute("success", "✅ Driver deleted successfully!");
            log.info("✅ Deleted driver ID: {}", id);
        } catch (Exception e) {
            log.error("❌ Error deleting driver: {}", e.getMessage());
            ra.addFlashAttribute("error", "Error deleting driver: " + e.getMessage());
        }
        return "redirect:/tour-crew-manager/resources";
    }
    
    // ============= GUIDE MANAGEMENT =============
    
    @PostMapping("/guide/create")
    public String createGuide(@RequestParam String name,
                             @RequestParam String phone,
                             @RequestParam String experience,
                             @RequestParam(defaultValue = "true") boolean available,
                             RedirectAttributes ra) {
        try {
            Guide guide = Guide.builder()
                    .name(name)
                    .phone(phone)
                    .experience(experience)
                    .available(available)
                    .build();
            guideRepository.save(guide);
            
            ra.addFlashAttribute("success", "✅ Guide created successfully!");
            log.info("✅ Created guide: {}", name);
            
        } catch (Exception e) {
            log.error("❌ Error creating guide: {}", e.getMessage());
            ra.addFlashAttribute("error", "Error creating guide: " + e.getMessage());
        }
        
        return "redirect:/tour-crew-manager/resources";
    }
    
    @PostMapping("/guide/update/{id}")
    public String updateGuide(@PathVariable Long id,
                             @RequestParam String name,
                             @RequestParam String phone,
                             @RequestParam String experience,
                             @RequestParam(defaultValue = "false") boolean available,
                             RedirectAttributes ra) {
        try {
            Guide guide = guideRepository.findById(id)
                    .orElseThrow(() -> new IllegalArgumentException("Guide not found"));
            
            guide.setName(name);
            guide.setPhone(phone);
            guide.setExperience(experience);
            guide.setAvailable(available);
            guideRepository.save(guide);
            
            ra.addFlashAttribute("success", "✅ Guide updated successfully!");
            log.info("✅ Updated guide ID: {}", id);
            
        } catch (Exception e) {
            log.error("❌ Error updating guide: {}", e.getMessage());
            ra.addFlashAttribute("error", "Error updating guide: " + e.getMessage());
        }
        
        return "redirect:/tour-crew-manager/resources";
    }
    
    @PostMapping("/guide/toggle-availability/{id}")
    public String toggleGuideAvailability(@PathVariable Long id, RedirectAttributes ra) {
        try {
            Guide guide = guideRepository.findById(id)
                    .orElseThrow(() -> new IllegalArgumentException("Guide not found"));
            
            guide.setAvailable(!guide.isAvailable());
            guideRepository.save(guide);
            
            String status = guide.isAvailable() ? "Available" : "Unavailable";
            ra.addFlashAttribute("success", "✅ Guide marked as " + status);
            log.info("✅ Toggled guide availability: {} - {}", guide.getName(), status);
            
        } catch (Exception e) {
            log.error("❌ Error toggling guide availability: {}", e.getMessage());
            ra.addFlashAttribute("error", "Error updating guide: " + e.getMessage());
        }
        
        return "redirect:/tour-crew-manager/resources";
    }
    
    @PostMapping("/guide/delete/{id}")
    public String deleteGuide(@PathVariable Long id, RedirectAttributes ra) {
        try {
            guideRepository.deleteById(id);
            ra.addFlashAttribute("success", "✅ Guide deleted successfully!");
            log.info("✅ Deleted guide ID: {}", id);
        } catch (Exception e) {
            log.error("❌ Error deleting guide: {}", e.getMessage());
            ra.addFlashAttribute("error", "Error deleting guide: " + e.getMessage());
        }
        return "redirect:/tour-crew-manager/resources";
    }
    
    // ============= JEEP MANAGEMENT =============
    
    @PostMapping("/jeep/create")
    public String createJeep(@RequestParam String registrationNumber,
                            @RequestParam String model,
                            @RequestParam int capacity,
                            @RequestParam(defaultValue = "true") boolean available,
                            RedirectAttributes ra) {
        try {
            Jeep jeep = Jeep.builder()
                    .registrationNumber(registrationNumber)
                    .model(model)
                    .capacity(capacity)
                    .available(available)
                    .build();
            jeepRepository.save(jeep);
            
            ra.addFlashAttribute("success", "✅ Jeep created successfully!");
            log.info("✅ Created jeep: {}", registrationNumber);
            
        } catch (Exception e) {
            log.error("❌ Error creating jeep: {}", e.getMessage());
            ra.addFlashAttribute("error", "Error creating jeep: " + e.getMessage());
        }
        
        return "redirect:/tour-crew-manager/resources";
    }
    
    @PostMapping("/jeep/update/{id}")
    public String updateJeep(@PathVariable Long id,
                            @RequestParam String registrationNumber,
                            @RequestParam String model,
                            @RequestParam int capacity,
                            @RequestParam(defaultValue = "false") boolean available,
                            RedirectAttributes ra) {
        try {
            Jeep jeep = jeepRepository.findById(id)
                    .orElseThrow(() -> new IllegalArgumentException("Jeep not found"));
            
            jeep.setRegistrationNumber(registrationNumber);
            jeep.setModel(model);
            jeep.setCapacity(capacity);
            jeep.setAvailable(available);
            jeepRepository.save(jeep);
            
            ra.addFlashAttribute("success", "✅ Jeep updated successfully!");
            log.info("✅ Updated jeep ID: {}", id);
            
        } catch (Exception e) {
            log.error("❌ Error updating jeep: {}", e.getMessage());
            ra.addFlashAttribute("error", "Error updating jeep: " + e.getMessage());
        }
        
        return "redirect:/tour-crew-manager/resources";
    }
    
    @PostMapping("/jeep/toggle-availability/{id}")
    public String toggleJeepAvailability(@PathVariable Long id, RedirectAttributes ra) {
        try {
            Jeep jeep = jeepRepository.findById(id)
                    .orElseThrow(() -> new IllegalArgumentException("Jeep not found"));
            
            jeep.setAvailable(!jeep.isAvailable());
            jeepRepository.save(jeep);
            
            String status = jeep.isAvailable() ? "Available" : "Unavailable";
            ra.addFlashAttribute("success", "✅ Jeep marked as " + status);
            log.info("✅ Toggled jeep availability: {} - {}", jeep.getRegistrationNumber(), status);
            
        } catch (Exception e) {
            log.error("❌ Error toggling jeep availability: {}", e.getMessage());
            ra.addFlashAttribute("error", "Error updating jeep: " + e.getMessage());
        }
        
        return "redirect:/tour-crew-manager/resources";
    }
    
    @PostMapping("/jeep/delete/{id}")
    public String deleteJeep(@PathVariable Long id, RedirectAttributes ra) {
        try {
            jeepRepository.deleteById(id);
            ra.addFlashAttribute("success", "✅ Jeep deleted successfully!");
            log.info("✅ Deleted jeep ID: {}", id);
        } catch (Exception e) {
            log.error("❌ Error deleting jeep: {}", e.getMessage());
            ra.addFlashAttribute("error", "Error deleting jeep: " + e.getMessage());
        }
        return "redirect:/tour-crew-manager/resources";
    }
    
    // ============= HELPER METHODS =============
    
    private boolean hasRole(Authentication auth, String role) {
        if (auth == null) return false;
        return auth.getAuthorities().stream()
                .anyMatch(a -> a.getAuthority().equals(role));
    }
}
