package com.safari.WildTrack.service;

import com.safari.WildTrack.model.Booking;
import com.safari.WildTrack.model.Feedback;
import com.safari.WildTrack.model.User;
import com.safari.WildTrack.repository.BookingRepository;
import com.safari.WildTrack.repository.FeedbackRepository;
import com.safari.WildTrack.repository.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class FeedbackService {

    private final FeedbackRepository feedbackRepository;
    private final UserRepository userRepository;
    private final BookingRepository bookingRepository;

    public FeedbackService(FeedbackRepository feedbackRepository,
                           UserRepository userRepository,
                           BookingRepository bookingRepository) {
        this.feedbackRepository = feedbackRepository;
        this.userRepository = userRepository;
        this.bookingRepository = bookingRepository;
    }

    @Transactional
    public void createFeedback(String userEmail, Long bookingId, 
                              int overallRating, int serviceRating, int guideRating, 
                              int vehicleRating, int experienceRating,
                              String comment, String serviceComment, 
                              String guideComment, String vehicleComment,
                              boolean wouldRecommend) {
        User user = userRepository.findByEmail(userEmail)
                .orElseThrow(() -> new IllegalArgumentException("User not found"));
        
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new IllegalArgumentException("Booking not found"));

        // Check if feedback already exists for this booking
        if (!feedbackRepository.findByBooking(booking).isEmpty()) {
            throw new IllegalArgumentException("Feedback already exists for this booking");
        }

        Feedback feedback = Feedback.builder()
                .user(user)
                .booking(booking)
                .overallRating(overallRating)
                .serviceRating(serviceRating)
                .guideRating(guideRating)
                .vehicleRating(vehicleRating)
                .experienceRating(experienceRating)
                .comment(comment)
                .serviceComment(serviceComment)
                .guideComment(guideComment)
                .vehicleComment(vehicleComment)
                .wouldRecommend(wouldRecommend)
                .createdAt(LocalDateTime.now())
                .build();

        feedbackRepository.save(feedback);
    }

    // Backward compatibility method
    public void createFeedback(String userEmail, Long bookingId, int rating, String comment) {
        createFeedback(userEmail, bookingId, rating, rating, rating, rating, rating, 
                      comment, "", "", "", true);
    }

    public List<Feedback> getAllFeedback() {
        return feedbackRepository.findAll();
    }
    public List<Feedback> getFeedbackByBooking(Long bookingId) {
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new IllegalArgumentException("Booking not found"));
        return feedbackRepository.findAll().stream()
                .filter(feedback -> feedback.getBooking().getId().equals(bookingId))
                .toList();
    }
}
