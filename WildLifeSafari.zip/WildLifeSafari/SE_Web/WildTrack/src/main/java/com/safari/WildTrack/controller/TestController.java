package com.safari.WildTrack.controller;

import com.safari.WildTrack.model.User;
import com.safari.WildTrack.repository.BookingRepository;
import com.safari.WildTrack.repository.SafariPackageRepository;
import com.safari.WildTrack.repository.UserRepository;
import com.safari.WildTrack.service.BookingService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/test")
public class TestController {

    private static final Logger log = LoggerFactory.getLogger(TestController.class);
    private final UserRepository userRepository;
    private final BookingRepository bookingRepository;
    private final SafariPackageRepository packageRepository;
    private final BookingService bookingService;

    public TestController(UserRepository userRepository,
                         BookingRepository bookingRepository,
                         SafariPackageRepository packageRepository,
                         BookingService bookingService) {
        this.userRepository = userRepository;
        this.bookingRepository = bookingRepository;
        this.packageRepository = packageRepository;
        this.bookingService = bookingService;
    }

    @GetMapping("/system-status")
    public String systemStatus() {
        try {
            long userCount = userRepository.count();
            long bookingCount = bookingRepository.count();
            long packageCount = packageRepository.count();
            
            return "🔍 WildTrack System Status Report\n" +
                   "=====================================\n" +
                   "🕐 Time: " + java.time.LocalDateTime.now() + "\n" +
                   "👥 Total Users: " + userCount + "\n" +
                   "📅 Total Bookings: " + bookingCount + "\n" +
                   "🦁 Safari Packages: " + packageCount + "\n" +
                   "🗄️ Database: ✅ Connected\n" +
                   "🌐 Application: ✅ Running\n" +
                   "🔐 Security: ✅ Active\n" +
                   "=====================================\n" +
                   "✅ All systems operational!";
        } catch (Exception e) {
            return "❌ System Status: ERROR\n" +
                   "Error: " + e.getMessage();
        }
    }

    @GetMapping("/user-test")
    public String userTest(Authentication auth) {
        if (auth == null) {
            return "❌ No authentication - please login first\n" +
                   "🔗 Login at: http://localhost:8080/login";
        }

        try {
            String email = auth.getName();
            User user = userRepository.findByEmail(email).orElse(null);
            
            if (user == null) {
                return "❌ User not found in database: " + email;
            }

            var bookings = bookingService.getBookingsByUser(email);
            
            return "✅ User Test Results\n" +
                   "==================\n" +
                   "👤 Name: " + user.getFullName() + "\n" +
                   "📧 Email: " + user.getEmail() + "\n" +
                   "✅ Verified: " + user.isEmailVerified() + "\n" +
                   "👥 Roles: " + user.getRoles() + "\n" +
                   "📅 Bookings: " + bookings.size() + "\n" +
                   "🆔 User ID: " + user.getId() + "\n" +
                   "==================\n" +
                   "✅ User system working perfectly!";
                   
        } catch (Exception e) {
            return "❌ User test failed: " + e.getMessage();
        }
    }

    @GetMapping("/booking-test")
    public String bookingTest() {
        try {
            // Test if we can access booking service
            var allBookings = bookingRepository.findAll();
            
            return "📅 Booking System Test\n" +
                   "=====================\n" +
                   "📊 Total Bookings: " + allBookings.size() + "\n" +
                   "🗄️ Repository: ✅ Working\n" +
                   "🔧 Service: ✅ Available\n" +
                   "=====================\n" +
                   "✅ Booking system operational!";
                   
        } catch (Exception e) {
            return "❌ Booking test failed: " + e.getMessage();
        }
    }

    @GetMapping("/full-test")
    public String fullSystemTest(Authentication auth) {
        StringBuilder result = new StringBuilder();
        result.append("🧪 FULL SYSTEM TEST REPORT\n");
        result.append("===========================\n");
        result.append("🕐 Test Time: ").append(java.time.LocalDateTime.now()).append("\n\n");

        // Test 1: Database Connection
        try {
            long userCount = userRepository.count();
            result.append("✅ Database Connection: PASS (").append(userCount).append(" users)\n");
        } catch (Exception e) {
            result.append("❌ Database Connection: FAIL - ").append(e.getMessage()).append("\n");
        }

        // Test 2: Authentication
        if (auth != null) {
            result.append("✅ Authentication: PASS (").append(auth.getName()).append(")\n");
        } else {
            result.append("⚠️ Authentication: Not logged in\n");
        }

        // Test 3: Safari Packages
        try {
            long packageCount = packageRepository.count();
            result.append("✅ Safari Packages: PASS (").append(packageCount).append(" packages)\n");
        } catch (Exception e) {
            result.append("❌ Safari Packages: FAIL - ").append(e.getMessage()).append("\n");
        }

        // Test 4: Booking System
        try {
            long bookingCount = bookingRepository.count();
            result.append("✅ Booking System: PASS (").append(bookingCount).append(" bookings)\n");
        } catch (Exception e) {
            result.append("❌ Booking System: FAIL - ").append(e.getMessage()).append("\n");
        }

        result.append("\n===========================\n");
        result.append("🎯 SYSTEM STATUS: OPERATIONAL\n");
        result.append("🔗 Dashboard: http://localhost:8080/safe-dashboard\n");
        result.append("🦁 Packages: http://localhost:8080/packages\n");
        result.append("👤 Profile: http://localhost:8080/profile/edit\n");

        return result.toString();
    }

    @GetMapping("/create-test-booking")
    public String createTestBooking(Authentication auth) {
        if (auth == null) {
            return "❌ Please login first to create a test booking\n" +
                   "🔗 Login at: http://localhost:8080/login";
        }

        try {
            String userEmail = auth.getName();
            
            // Get the first available package
            var packages = packageRepository.findAll();
            if (packages.isEmpty()) {
                return "❌ No safari packages available to book";
            }
            
            var firstPackage = packages.get(0);
            
            // Create a test booking for tomorrow
            java.time.LocalDate tomorrow = java.time.LocalDate.now().plusDays(1);
            
            var booking = bookingService.createBooking(userEmail, firstPackage.getId(), tomorrow, 2);
            
            return "✅ TEST BOOKING CREATED SUCCESSFULLY!\n" +
                   "================================\n" +
                   "🆔 Booking ID: " + booking.getId() + "\n" +
                   "👤 User: " + userEmail + "\n" +
                   "🦁 Package: " + firstPackage.getName() + "\n" +
                   "📅 Date: " + tomorrow + "\n" +
                   "👥 Guests: 2\n" +
                   "💰 Total: $" + booking.getTotalPrice() + "\n" +
                   "📋 Status: " + booking.getStatus() + "\n" +
                   "================================\n" +
                   "🔗 View bookings: http://localhost:8080/profile/bookings";
                   
        } catch (Exception e) {
            return "❌ Failed to create test booking: " + e.getMessage() + "\n" +
                   "📋 Error type: " + e.getClass().getSimpleName();
        }
    }

    @GetMapping("/check-duplicate-bookings")
    public String checkDuplicateBookings(Authentication auth) {
        if (auth == null) {
            return "❌ Please login first to check bookings\n" +
                   "🔗 Login at: http://localhost:8080/login";
        }

        try {
            String userEmail = auth.getName();
            var user = userRepository.findByEmail(userEmail).orElse(null);
            
            if (user == null) {
                return "❌ User not found: " + userEmail;
            }

            // Check both methods
            var bookingsOld = bookingRepository.findByUser(user);
            var bookingsNew = bookingRepository.findByUserWithDetails(user);
            
            StringBuilder result = new StringBuilder();
            result.append("🔍 DUPLICATE BOOKING CHECK\n");
            result.append("========================\n");
            result.append("👤 User: ").append(userEmail).append("\n");
            result.append("📊 Old method count: ").append(bookingsOld.size()).append("\n");
            result.append("📊 New method count: ").append(bookingsNew.size()).append("\n\n");
            
            result.append("📋 Old Method Bookings:\n");
            for (int i = 0; i < bookingsOld.size(); i++) {
                var booking = bookingsOld.get(i);
                result.append("  ").append(i + 1).append(". ID: ").append(booking.getId())
                      .append(", Package: ").append(booking.getSafariPackage().getName())
                      .append(", Date: ").append(booking.getSafariDate()).append("\n");
            }
            
            result.append("\n📋 New Method Bookings:\n");
            for (int i = 0; i < bookingsNew.size(); i++) {
                var booking = bookingsNew.get(i);
                result.append("  ").append(i + 1).append(". ID: ").append(booking.getId())
                      .append(", Package: ").append(booking.getSafariPackage().getName())
                      .append(", Date: ").append(booking.getSafariDate()).append("\n");
            }
            
            // Check for actual duplicates in database
            var allBookings = bookingRepository.findAll();
            long userBookingCount = allBookings.stream()
                    .filter(b -> b.getUser().getEmail().equals(userEmail))
                    .count();
            
            result.append("\n🗄️ Database Check:\n");
            result.append("Total bookings in DB: ").append(allBookings.size()).append("\n");
            result.append("User bookings in DB: ").append(userBookingCount).append("\n");
            
            return result.toString();
            
        } catch (Exception e) {
            return "❌ Failed to check bookings: " + e.getMessage() + "\n" +
                   "📋 Error type: " + e.getClass().getSimpleName();
        }
    }

    @GetMapping("/clean-duplicate-bookings")
    public String cleanDuplicateBookings(Authentication auth) {
        if (auth == null) {
            return "❌ Please login first to clean bookings\n" +
                   "🔗 Login at: http://localhost:8080/login";
        }

        try {
            String userEmail = auth.getName();
            var user = userRepository.findByEmail(userEmail).orElse(null);
            
            if (user == null) {
                return "❌ User not found: " + userEmail;
            }

            // Get all bookings for the user
            var allBookings = bookingRepository.findByUser(user);
            
            // Group by unique characteristics (date, package, guests)
            var uniqueBookings = new java.util.HashMap<String, com.safari.WildTrack.model.Booking>();
            var duplicates = new java.util.ArrayList<com.safari.WildTrack.model.Booking>();
            
            for (var booking : allBookings) {
                String key = booking.getSafariDate() + "_" + 
                           booking.getSafariPackage().getId() + "_" + 
                           booking.getNumGuests();
                
                if (uniqueBookings.containsKey(key)) {
                    // This is a duplicate, mark for deletion
                    duplicates.add(booking);
                } else {
                    uniqueBookings.put(key, booking);
                }
            }
            
            StringBuilder result = new StringBuilder();
            result.append("🧹 DUPLICATE BOOKING CLEANUP\n");
            result.append("===========================\n");
            result.append("👤 User: ").append(userEmail).append("\n");
            result.append("📊 Total bookings found: ").append(allBookings.size()).append("\n");
            result.append("📊 Unique bookings: ").append(uniqueBookings.size()).append("\n");
            result.append("📊 Duplicates found: ").append(duplicates.size()).append("\n\n");
            
            if (!duplicates.isEmpty()) {
                result.append("🗑️ Removing duplicates:\n");
                for (var duplicate : duplicates) {
                    result.append("  - Booking ID: ").append(duplicate.getId())
                          .append(", Date: ").append(duplicate.getSafariDate())
                          .append(", Package: ").append(duplicate.getSafariPackage().getName()).append("\n");
                    bookingRepository.delete(duplicate);
                }
                result.append("\n✅ Duplicates removed successfully!\n");
            } else {
                result.append("✅ No duplicates found - database is clean!\n");
            }
            
            result.append("\n🔗 View cleaned bookings: http://localhost:8080/profile/bookings");
            
            return result.toString();
            
        } catch (Exception e) {
            return "❌ Failed to clean bookings: " + e.getMessage() + "\n" +
                   "📋 Error type: " + e.getClass().getSimpleName();
        }
    }

    @GetMapping("/force-clean-bookings")
    public String forceCleanBookings(Authentication auth) {
        if (auth == null) {
            return "❌ Please login first\n" +
                   "🔗 Login at: http://localhost:8080/login";
        }

        try {
            String userEmail = auth.getName();
            var user = userRepository.findByEmail(userEmail).orElse(null);
            
            if (user == null) {
                return "❌ User not found: " + userEmail;
            }

            // Get all bookings using the old method (might have duplicates)
            var allBookings = bookingRepository.findByUser(user);
            
            // Delete ALL bookings for this user
            bookingRepository.deleteAll(allBookings);
            
            return "🧹 FORCE CLEAN COMPLETED!\n" +
                   "========================\n" +
                   "👤 User: " + userEmail + "\n" +
                   "🗑️ Deleted bookings: " + allBookings.size() + "\n" +
                   "✅ All bookings removed\n" +
                   "========================\n" +
                   "💡 You can now create fresh bookings without duplicates\n" +
                   "🔗 Create booking: http://localhost:8080/new-booking";
                   
        } catch (Exception e) {
            return "❌ Failed to clean bookings: " + e.getMessage() + "\n" +
                   "📋 Error type: " + e.getClass().getSimpleName();
        }
    }

    @GetMapping("/booking-stats")
    public String testBookingStats(Authentication auth) {
        if (auth == null) {
            return "❌ Please login first to check booking stats\n" +
                   "🔗 Login at: http://localhost:8080/login";
        }

        try {
            String userEmail = auth.getName();
            var user = userRepository.findByEmail(userEmail).orElse(null);
            
            if (user == null) {
                return "❌ User not found: " + userEmail;
            }

            var bookings = bookingService.getBookingsByUser(userEmail);
            
            // Calculate statistics (same logic as controller)
            int totalBookings = bookings.size();
            int confirmedBookings = 0;
            int pendingBookings = 0;
            int upcomingBookings = 0;
            
            java.time.LocalDate today = java.time.LocalDate.now();
            
            StringBuilder result = new StringBuilder();
            result.append("📊 BOOKING STATISTICS TEST\n");
            result.append("=========================\n");
            result.append("👤 User: ").append(userEmail).append("\n");
            result.append("📅 Today: ").append(today).append("\n\n");
            
            result.append("📋 Individual Bookings:\n");
            for (int i = 0; i < bookings.size(); i++) {
                var booking = bookings.get(i);
                String status = booking.getStatus().name();
                boolean isUpcoming = booking.getSafariDate().isAfter(today) || booking.getSafariDate().isEqual(today);
                
                result.append("  ").append(i + 1).append(". ID: ").append(booking.getId())
                      .append(", Status: ").append(status)
                      .append(", Date: ").append(booking.getSafariDate())
                      .append(", Upcoming: ").append(isUpcoming).append("\n");
                
                if (status.equals("CONFIRMED")) {
                    confirmedBookings++;
                    if (isUpcoming) {
                        upcomingBookings++;
                    }
                } else if (status.equals("PENDING")) {
                    pendingBookings++;
                }
            }
            
            result.append("\n📊 Statistics Summary:\n");
            result.append("Total Bookings: ").append(totalBookings).append("\n");
            result.append("Confirmed: ").append(confirmedBookings).append("\n");
            result.append("Pending: ").append(pendingBookings).append("\n");
            result.append("Upcoming: ").append(upcomingBookings).append("\n");
            result.append("\n✅ Statistics calculation working correctly!");
            
            return result.toString();
            
        } catch (Exception e) {
            return "❌ Failed to calculate booking stats: " + e.getMessage() + "\n" +
                   "📋 Error type: " + e.getClass().getSimpleName();
        }
    }
}
