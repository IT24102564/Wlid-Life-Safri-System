package com.safari.WildTrack.enums;

public enum TicketStatus {
    UNASSIGNED,     // Created but not assigned to mechanic
    ASSIGNED,       // Assigned to mechanic
    IN_PROGRESS,    // Mechanic is working on it
    COMPLETED,      // Repair completed
    CANCELLED       // Ticket cancelled
}
