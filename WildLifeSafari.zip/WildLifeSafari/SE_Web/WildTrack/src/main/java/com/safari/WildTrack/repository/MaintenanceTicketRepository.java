package com.safari.WildTrack.repository;

import com.safari.WildTrack.model.MaintenanceTicket;
import com.safari.WildTrack.model.User;
import com.safari.WildTrack.enums.TicketStatus;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface MaintenanceTicketRepository extends JpaRepository<MaintenanceTicket, Long> {
    
    List<MaintenanceTicket> findByStatusOrderByCreatedAtDesc(TicketStatus status);
    
    List<MaintenanceTicket> findByAssignedMechanicOrderByCreatedAtDesc(User mechanic);
    
    List<MaintenanceTicket> findByAssignedMechanicAndStatusOrderByCreatedAtDesc(User mechanic, TicketStatus status);
    
    List<MaintenanceTicket> findAllByOrderByCreatedAtDesc();
    
    long countByStatus(TicketStatus status);
    
    long countByAssignedMechanicAndStatus(User mechanic, TicketStatus status);
}


