package com.safari.WildTrack.controller;

import com.safari.WildTrack.service.MaintenanceTicketService;
import com.safari.WildTrack.repository.UserRepository;
import com.safari.WildTrack.enums.TicketStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/mechanic")
public class MechanicController {
    
    private static final Logger log = LoggerFactory.getLogger(MechanicController.class);
    
    private final MaintenanceTicketService ticketService;
    private final UserRepository userRepository;
    
    public MechanicController(MaintenanceTicketService ticketService,
                             UserRepository userRepository) {
        this.ticketService = ticketService;
        this.userRepository = userRepository;
    }
    
    @GetMapping("/dashboard")
    public String dashboard(Authentication auth, Model model) {
        log.info("🔨 Loading Mechanic Dashboard");
        
        if (auth == null) {
            return "redirect:/login";
        }
        
        var user = userRepository.findByEmail(auth.getName()).orElse(null);
        if (user == null) {
            return "redirect:/login";
        }
        
        try {
            // Get tickets assigned to this mechanic
            var myTickets = ticketService.getTicketsForMechanic(auth.getName());
            var activeTickets = ticketService.getActiveTicketsForMechanic(auth.getName());
            
            // Statistics
            long totalAssigned = myTickets.size();
            long activeCount = activeTickets.size();
            long completedCount = myTickets.stream()
                    .filter(t -> t.getStatus() == TicketStatus.COMPLETED)
                    .count();
            
            model.addAttribute("user", user);
            model.addAttribute("myTickets", myTickets);
            model.addAttribute("activeTickets", activeTickets);
            model.addAttribute("totalAssigned", totalAssigned);
            model.addAttribute("activeCount", activeCount);
            model.addAttribute("completedCount", completedCount);
            
            log.info("✅ Dashboard loaded - Total assigned: {}, Active: {}", totalAssigned, activeCount);
            
        } catch (Exception e) {
            log.error("❌ Error loading dashboard: {}", e.getMessage(), e);
            model.addAttribute("error", "Error loading dashboard: " + e.getMessage());
        }
        
        return "mechanic-dashboard";
    }
    
    @PostMapping("/start-work/{ticketId}")
    public String startWork(@PathVariable Long ticketId, RedirectAttributes ra) {
        log.info("🔨 Starting work on ticket {}", ticketId);
        
        try {
            ticketService.startWork(ticketId);
            ra.addFlashAttribute("success", "✅ Work started on ticket! Status updated to IN PROGRESS.");
            log.info("✅ Work started successfully");
        } catch (Exception e) {
            log.error("❌ Error starting work: {}", e.getMessage(), e);
            ra.addFlashAttribute("error", "❌ Error: " + e.getMessage());
        }
        
        return "redirect:/mechanic/dashboard";
    }
    
    @PostMapping("/complete-work/{ticketId}")
    public String completeWork(@PathVariable Long ticketId,
                              @RequestParam String mechanicNotes,
                              RedirectAttributes ra) {
        log.info("✅ Completing work on ticket {}", ticketId);
        
        try {
            ticketService.completeWork(ticketId, mechanicNotes);
            ra.addFlashAttribute("success", "✅ Work completed! Maintenance Officer has been notified. Jeep is now available.");
            log.info("✅ Work completed successfully");
        } catch (Exception e) {
            log.error("❌ Error completing work: {}", e.getMessage(), e);
            ra.addFlashAttribute("error", "❌ Error: " + e.getMessage());
        }
        
        return "redirect:/mechanic/dashboard";
    }
}
