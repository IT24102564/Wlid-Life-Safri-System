package com.safari.WildTrack.enums;

public enum SafariType {
    HALF_DAY,
    FULL_DAY,
    TWO_DAYS
}


