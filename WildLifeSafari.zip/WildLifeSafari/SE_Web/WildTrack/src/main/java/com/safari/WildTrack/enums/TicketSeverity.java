package com.safari.WildTrack.enums;

public enum TicketSeverity {
    LOW,        // Minor issues, can wait
    MEDIUM,     // Moderate issues, needs attention soon
    HIGH,       // Serious issues, needs quick attention
    CRITICAL    // Urgent issues, immediate attention required
}
