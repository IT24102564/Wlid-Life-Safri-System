package com.safari.WildTrack.model;

import com.safari.WildTrack.enums.TicketSeverity;
import com.safari.WildTrack.enums.TicketStatus;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Entity
@Table(name = "maintenance_tickets")
public class MaintenanceTicket {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(optional = false, fetch = FetchType.EAGER)
    @JoinColumn(name = "jeep_id")
    private Jeep jeep;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "reported_by_user_id")
    private User reportedBy; // Driver who reported the issue

    @Column(length = 1000)
    private String issueDescription;

    @Enumerated(EnumType.STRING)
    @Column(length = 20)
    private TicketSeverity severity;

    @Enumerated(EnumType.STRING)
    @Column(length = 30)
    private TicketStatus status;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "assigned_mechanic_id")
    private User assignedMechanic;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "assigned_by_id")
    private User assignedBy; // Maintenance Officer who assigned

    private LocalDateTime assignedAt;

    private LocalDateTime createdAt;

    private LocalDateTime updatedAt;

    private LocalDateTime completedAt;

    @Column(length = 500)
    private String mechanicNotes; // Notes from mechanic after completion
}


