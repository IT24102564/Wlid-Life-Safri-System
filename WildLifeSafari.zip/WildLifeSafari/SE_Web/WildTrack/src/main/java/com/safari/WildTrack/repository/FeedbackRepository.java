package com.safari.WildTrack.repository;

import com.safari.WildTrack.model.Booking;
import com.safari.WildTrack.model.Feedback;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface FeedbackRepository extends JpaRepository<Feedback, Long> {
    List<Feedback> findByBooking(Booking booking);
}


