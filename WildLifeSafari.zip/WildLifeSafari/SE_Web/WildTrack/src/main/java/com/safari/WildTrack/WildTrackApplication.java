package com.safari.WildTrack;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WildTrackApplication {

	public static void main(String[] args) {
		SpringApplication.run(WildTrackApplication.class, args);
	}

}
