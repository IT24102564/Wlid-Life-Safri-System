package com.safari.WildTrack.controller;

import com.safari.WildTrack.model.SafariPackage;
import com.safari.WildTrack.enums.SafariType;
import com.safari.WildTrack.repository.SafariPackageRepository;
import com.safari.WildTrack.repository.BookingRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.math.BigDecimal;
import java.util.List;

@Controller
@RequestMapping("/package-builder")
public class PackageBuilderController {

    private static final Logger log = LoggerFactory.getLogger(PackageBuilderController.class);
    
    private final SafariPackageRepository packageRepository;
    private final BookingRepository bookingRepository;

    public PackageBuilderController(SafariPackageRepository packageRepository,
                                   BookingRepository bookingRepository) {
        this.packageRepository = packageRepository;
        this.bookingRepository = bookingRepository;
    }

    @GetMapping("/dashboard")
    public String dashboard(Authentication auth, Model model) {
        log.info("📦 Loading Package Builder Dashboard");
        
        if (auth == null) {
            log.warn("❌ Unauthorized access attempt - no authentication");
            return "redirect:/login";
        }
        
        // Verify user has PACKAGE_BUILDER role
        boolean hasRole = auth.getAuthorities().stream()
                .anyMatch(a -> a.getAuthority().equals("ROLE_PACKAGE_BUILDER"));
        
        if (!hasRole) {
            log.warn("❌ Access denied for user: {} - Not a Package Builder", auth.getName());
            return "redirect:/safe-dashboard";
        }
        
        log.info("✅ Package Builder authenticated: {}", auth.getName());

        try {
            // Get all packages
            var allPackages = packageRepository.findAll();
            
            // Calculate statistics
            long totalPackages = allPackages.size();
            long activePackages = allPackages.size(); // All are active by default
            long totalBookings = bookingRepository.count();
            
            // Get package type distribution
            long halfDayCount = allPackages.stream()
                    .filter(p -> p.getType() == SafariType.HALF_DAY)
                    .count();
            long fullDayCount = allPackages.stream()
                    .filter(p -> p.getType() == SafariType.FULL_DAY)
                    .count();
            long twoDaysCount = allPackages.stream()
                    .filter(p -> p.getType() == SafariType.TWO_DAYS)
                    .count();
            
            // Add all data to model
            model.addAttribute("totalPackages", totalPackages);
            model.addAttribute("activePackages", activePackages);
            model.addAttribute("totalBookings", totalBookings);
            model.addAttribute("halfDayCount", halfDayCount);
            model.addAttribute("fullDayCount", fullDayCount);
            model.addAttribute("twoDaysCount", twoDaysCount);
            
            model.addAttribute("packages", allPackages);
            model.addAttribute("safariTypes", SafariType.values());
            
            log.info("✅ Dashboard loaded - Total Packages: {}", totalPackages);
            
            return "package-builder-dashboard";
            
        } catch (Exception e) {
            log.error("❌ Error loading dashboard: {}", e.getMessage(), e);
            model.addAttribute("error", "Error loading dashboard: " + e.getMessage());
            return "package-builder-dashboard";
        }
    }

    @PostMapping("/create")
    public String createPackage(@RequestParam String name,
                               @RequestParam SafariType type,
                               @RequestParam BigDecimal price,
                               @RequestParam int maxGuests,
                               @RequestParam String description,
                               RedirectAttributes ra) {
        log.info("📦 Creating new package: {}", name);
        
        try {
            SafariPackage pkg = SafariPackage.builder()
                    .name(name)
                    .type(type)
                    .price(price)
                    .maxGuests(maxGuests)
                    .description(description)
                    .build();
            
            SafariPackage saved = packageRepository.save(pkg);
            ra.addFlashAttribute("success", "Package '" + name + "' created successfully! ID: " + saved.getId());
            log.info("✅ Package created: {} (ID: {})", name, saved.getId());
            
        } catch (Exception e) {
            log.error("❌ Error creating package: {}", e.getMessage(), e);
            ra.addFlashAttribute("error", "Error creating package: " + e.getMessage());
        }
        
        return "redirect:/package-builder/dashboard";
    }

    @PostMapping("/update/{id}")
    public String updatePackage(@PathVariable Long id,
                               @RequestParam String name,
                               @RequestParam SafariType type,
                               @RequestParam BigDecimal price,
                               @RequestParam int maxGuests,
                               @RequestParam String description,
                               RedirectAttributes ra) {
        log.info("📝 Updating package ID: {}", id);
        
        try {
            SafariPackage pkg = packageRepository.findById(id)
                    .orElseThrow(() -> new IllegalArgumentException("Package not found"));
            
            pkg.setName(name);
            pkg.setType(type);
            pkg.setPrice(price);
            pkg.setMaxGuests(maxGuests);
            pkg.setDescription(description);
            
            packageRepository.save(pkg);
            ra.addFlashAttribute("success", "Package '" + name + "' updated successfully!");
            log.info("✅ Package updated: {} (ID: {})", name, id);
            
        } catch (Exception e) {
            log.error("❌ Error updating package: {}", e.getMessage(), e);
            ra.addFlashAttribute("error", "Error updating package: " + e.getMessage());
        }
        
        return "redirect:/package-builder/dashboard";
    }

    @PostMapping("/delete/{id}")
    public String deletePackage(@PathVariable Long id, RedirectAttributes ra) {
        log.info("🗑️ Deleting package ID: {}", id);
        
        try {
            SafariPackage pkg = packageRepository.findById(id)
                    .orElseThrow(() -> new IllegalArgumentException("Package not found"));
            
            // Check if package has bookings
            long bookingCount = bookingRepository.findAll().stream()
                    .filter(b -> b.getSafariPackage().getId().equals(id))
                    .count();
            
            if (bookingCount > 0) {
                ra.addFlashAttribute("error", "Cannot delete package '" + pkg.getName() + 
                        "' - it has " + bookingCount + " booking(s). Please cancel bookings first.");
                log.warn("⚠️ Cannot delete package {} - has {} bookings", id, bookingCount);
                return "redirect:/package-builder/dashboard";
            }
            
            String packageName = pkg.getName();
            packageRepository.delete(pkg);
            ra.addFlashAttribute("success", "Package '" + packageName + "' deleted successfully!");
            log.info("✅ Package deleted: {} (ID: {})", packageName, id);
            
        } catch (Exception e) {
            log.error("❌ Error deleting package: {}", e.getMessage(), e);
            ra.addFlashAttribute("error", "Error deleting package: " + e.getMessage());
        }
        
        return "redirect:/package-builder/dashboard";
    }

    @GetMapping("/search")
    public String searchPackages(@RequestParam(required = false) String query,
                                 @RequestParam(required = false) Long id,
                                 Model model) {
        log.info("🔍 Searching packages - Query: {}, ID: {}", query, id);
        
        try {
            List<SafariPackage> results;
            
            if (id != null) {
                // Search by ID
                results = packageRepository.findById(id)
                        .map(List::of)
                        .orElse(List.of());
                model.addAttribute("searchType", "ID: " + id);
            } else if (query != null && !query.trim().isEmpty()) {
                // Search by name (case-insensitive)
                String searchQuery = query.toLowerCase();
                results = packageRepository.findAll().stream()
                        .filter(p -> p.getName().toLowerCase().contains(searchQuery))
                        .toList();
                model.addAttribute("searchType", "Name: " + query);
            } else {
                // No search criteria, show all
                results = packageRepository.findAll();
                model.addAttribute("searchType", "All Packages");
            }
            
            model.addAttribute("packages", results);
            model.addAttribute("resultCount", results.size());
            model.addAttribute("safariTypes", SafariType.values());
            
            // Add statistics
            model.addAttribute("totalPackages", packageRepository.count());
            model.addAttribute("activePackages", packageRepository.count());
            model.addAttribute("totalBookings", bookingRepository.count());
            
            log.info("✅ Search completed - Found {} packages", results.size());
            
            return "package-builder-dashboard";
            
        } catch (Exception e) {
            log.error("❌ Error searching packages: {}", e.getMessage(), e);
            model.addAttribute("error", "Error searching packages: " + e.getMessage());
            return "package-builder-dashboard";
        }
    }
}
