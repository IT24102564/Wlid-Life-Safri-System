package com.safari.WildTrack.controller;

import com.safari.WildTrack.service.FeedbackService;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class FeedbackController {

    private final FeedbackService feedbackService;

    public FeedbackController(FeedbackService feedbackService) {
        this.feedbackService = feedbackService;
    }

    @GetMapping("/feedback/{bookingId}")
    public String feedbackForm(@PathVariable Long bookingId, Model model) {
        model.addAttribute("bookingId", bookingId);
        return "feedback-form";
    }

    @PostMapping("/feedback/submit")
    public String submitFeedback(@RequestParam Long bookingId,
                                 @RequestParam int overallRating,
                                 @RequestParam int serviceRating,
                                 @RequestParam int guideRating,
                                 @RequestParam int vehicleRating,
                                 @RequestParam int experienceRating,
                                 @RequestParam(required = false) String comment,
                                 @RequestParam(required = false) String serviceComment,
                                 @RequestParam(required = false) String guideComment,
                                 @RequestParam(required = false) String vehicleComment,
                                 @RequestParam(required = false) boolean wouldRecommend,
                                 Authentication auth,
                                 RedirectAttributes ra) {
        try {
            feedbackService.createFeedback(auth.getName(), bookingId, 
                overallRating, serviceRating, guideRating, vehicleRating, experienceRating,
                comment != null ? comment : "",
                serviceComment != null ? serviceComment : "",
                guideComment != null ? guideComment : "",
                vehicleComment != null ? vehicleComment : "",
                wouldRecommend);
            ra.addFlashAttribute("success", "Thank you for your detailed feedback! It helps us improve our services.");
        } catch (Exception e) {
            ra.addFlashAttribute("error", "Error submitting feedback: " + e.getMessage());
        }
        return "redirect:/profile/bookings";
    }

    @GetMapping("/feedback")
    public String feedbackPage(Model model) {
        model.addAttribute("message", "Use the feedback form to rate your safari experience!");
        return "feedback-form";
    }
}
