package com.safari.WildTrack.controller;

import com.safari.WildTrack.enums.Role;
import com.safari.WildTrack.model.User;
import com.safari.WildTrack.repository.UserRepository;
import com.safari.WildTrack.service.BookingService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.Collection;

@Controller
public class DashboardController {

    private static final Logger log = LoggerFactory.getLogger(DashboardController.class);
    private final UserRepository userRepository;
    private final BookingService bookingService;

    public DashboardController(UserRepository userRepository, BookingService bookingService) {
        this.userRepository = userRepository;
        this.bookingService = bookingService;
    }

    @GetMapping("/dashboard")
    public String dashboard(Authentication auth, Model model) {
        log.info("🏠 Dashboard access attempt");
        
        if (auth == null) {
            log.warn("❌ No authentication found, redirecting to login");
            return "redirect:/login";
        }

        String email = auth.getName();
        log.info("👤 Dashboard access for user: {}", email);
        
        User user = userRepository.findByEmail(email).orElse(null);
        
        if (user == null) {
            log.error("❌ User not found in database: {}", email);
            return "redirect:/login";
        }

        log.info("✅ User found: {} with roles: {}", user.getFullName(), user.getRoles());
        model.addAttribute("user", user);
        
        Collection<? extends GrantedAuthority> authorities = auth.getAuthorities();
        log.info("🔑 User authorities: {}", authorities);
        
        // Check roles and redirect to appropriate dashboard
        if (authorities.stream().anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"))) {
            return "redirect:/admin/dashboard";
        } else if (authorities.stream().anyMatch(a -> a.getAuthority().equals("ROLE_PARK_MANAGER"))) {
            return "redirect:/park-manager/dashboard";
        } else if (authorities.stream().anyMatch(a -> a.getAuthority().equals("ROLE_BOOKING_OFFICER"))) {
            return "redirect:/booking-officer/dashboard";
        } else if (authorities.stream().anyMatch(a -> a.getAuthority().equals("ROLE_DRIVER"))) {
            return "redirect:/driver/dashboard";
        } else if (authorities.stream().anyMatch(a -> a.getAuthority().equals("ROLE_GUIDE"))) {
            return "redirect:/guide/dashboard";
        } else if (authorities.stream().anyMatch(a -> a.getAuthority().equals("ROLE_IT_SUPPORT"))) {
            return "redirect:/it-support/dashboard";
        } else {
            // Tourist dashboard
            log.info("🎯 Loading tourist dashboard for: {}", email);
            try {
                var bookings = bookingService.getBookingsByUser(email);
                model.addAttribute("bookings", bookings);
                model.addAttribute("totalBookings", bookings.size());
                log.info("✅ Loaded {} bookings for user", bookings.size());
            } catch (Exception e) {
                log.error("❌ Failed to load bookings for user {}: {}", email, e.getMessage(), e);
                // If booking service fails, provide empty list
                model.addAttribute("bookings", java.util.Collections.emptyList());
                model.addAttribute("totalBookings", 0);
                model.addAttribute("error", "Unable to load bookings at this time.");
            }
            
            // Add additional data for tourist dashboard
            model.addAttribute("userName", user.getFullName());
            model.addAttribute("userEmail", email);
            
            log.info("🎯 Returning tourist-dashboard template");
            return "tourist-dashboard";
        }
    }

    @GetMapping("/test-dashboard")
    public String testDashboard(Authentication auth, Model model) {
        log.info("🧪 Test dashboard access");
        
        if (auth == null) {
            return "redirect:/login";
        }

        String email = auth.getName();
        User user = userRepository.findByEmail(email).orElse(null);
        
        if (user == null) {
            return "redirect:/login";
        }

        model.addAttribute("user", user);
        model.addAttribute("message", "✅ Login Successful! Welcome to WildTrack Safari!");
        model.addAttribute("email", email);
        model.addAttribute("roles", user.getRoles());
        
        log.info("✅ Test dashboard loaded successfully for: {}", email);
        return "test-dashboard";
    }

    @GetMapping("/safe-dashboard")
    public String safeDashboard(Authentication auth, Model model) {
        log.info("🛡️ Safe dashboard access");
        
        if (auth == null) {
            log.warn("❌ No authentication found");
            return "redirect:/login";
        }

        String email = auth.getName();
        log.info("👤 Safe dashboard access for user: {}", email);
        
        User user = userRepository.findByEmail(email).orElse(null);
        if (user == null) {
            log.error("❌ User not found in database: {}", email);
            return "redirect:/login";
        }

        log.info("✅ User found: {} with roles: {}", user.getFullName(), user.getRoles());
        
        // Add basic user info without complex services
        model.addAttribute("user", user);
        model.addAttribute("userName", user.getFullName());
        model.addAttribute("userEmail", email);
        model.addAttribute("userRoles", user.getRoles());
        model.addAttribute("totalBookings", 0); // Safe default
        model.addAttribute("bookings", java.util.Collections.emptyList()); // Safe default
        
        log.info("✅ Safe dashboard loaded successfully for: {}", email);
        return "safe-dashboard";
    }

    @GetMapping("/admin/dashboard")
    public String adminDashboard(Model model) {
        return "admin-dashboard";
    }

    @GetMapping("/park-manager/dashboard")
    public String parkManagerDashboard(Model model) {
        return "park-manager-dashboard";
    }

    // Booking Officer dashboard moved to BookingOfficerController
    // @GetMapping("/booking-officer/dashboard") - removed to avoid duplicate mapping

    @GetMapping("/driver/dashboard")
    public String driverDashboard(Model model) {
        return "driver-dashboard";
    }

    @GetMapping("/guide/dashboard")
    public String guideDashboard(Model model) {
        return "guide-dashboard";
    }

    @GetMapping("/it-support/dashboard")
    public String itSupportDashboard(Model model) {
        return "it-support-dashboard";
    }
}
