package com.safari.WildTrack.controller;

import com.safari.WildTrack.service.MaintenanceTicketService;
import com.safari.WildTrack.repository.UserRepository;
import com.safari.WildTrack.repository.JeepRepository;
import com.safari.WildTrack.enums.Role;
import com.safari.WildTrack.enums.TicketSeverity;
import com.safari.WildTrack.enums.TicketStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/maintenance-officer")
public class MaintenanceOfficerController {
    
    private static final Logger log = LoggerFactory.getLogger(MaintenanceOfficerController.class);
    
    private final MaintenanceTicketService ticketService;
    private final UserRepository userRepository;
    private final JeepRepository jeepRepository;
    
    public MaintenanceOfficerController(MaintenanceTicketService ticketService,
                                       UserRepository userRepository,
                                       JeepRepository jeepRepository) {
        this.ticketService = ticketService;
        this.userRepository = userRepository;
        this.jeepRepository = jeepRepository;
    }
    
    @GetMapping("/dashboard")
    public String dashboard(Authentication auth, Model model) {
        log.info("🔧 Loading Maintenance Officer Dashboard");
        
        if (auth == null) {
            return "redirect:/login";
        }
        
        var user = userRepository.findByEmail(auth.getName()).orElse(null);
        if (user == null) {
            return "redirect:/login";
        }
        
        try {
            // Get all tickets
            var allTickets = ticketService.getAllTickets();
            var unassignedTickets = ticketService.getUnassignedTickets();
            
            // Get all mechanics
            var mechanics = userRepository.findAll().stream()
                    .filter(u -> u.getRoles().contains(Role.MECHANIC))
                    .toList();
            
            // Get all jeeps
            var jeeps = jeepRepository.findAll();
            
            // Statistics
            long totalTickets = allTickets.size();
            long unassignedCount = ticketService.countByStatus(TicketStatus.UNASSIGNED);
            long assignedCount = ticketService.countByStatus(TicketStatus.ASSIGNED);
            long inProgressCount = ticketService.countByStatus(TicketStatus.IN_PROGRESS);
            long completedCount = ticketService.countByStatus(TicketStatus.COMPLETED);
            
            model.addAttribute("user", user);
            model.addAttribute("allTickets", allTickets);
            model.addAttribute("unassignedTickets", unassignedTickets);
            model.addAttribute("mechanics", mechanics);
            model.addAttribute("jeeps", jeeps);
            model.addAttribute("totalTickets", totalTickets);
            model.addAttribute("unassignedCount", unassignedCount);
            model.addAttribute("assignedCount", assignedCount);
            model.addAttribute("inProgressCount", inProgressCount);
            model.addAttribute("completedCount", completedCount);
            
            log.info("✅ Dashboard loaded - Total tickets: {}, Unassigned: {}", totalTickets, unassignedCount);
            
        } catch (Exception e) {
            log.error("❌ Error loading dashboard: {}", e.getMessage(), e);
            model.addAttribute("error", "Error loading dashboard: " + e.getMessage());
        }
        
        return "maintenance-officer-dashboard";
    }
    
    @PostMapping("/create-ticket")
    public String createTicket(@RequestParam Long jeepId,
                              @RequestParam String issueDescription,
                              @RequestParam TicketSeverity severity,
                              Authentication auth,
                              RedirectAttributes ra) {
        log.info("🔧 Creating ticket for jeep ID: {}", jeepId);
        
        try {
            ticketService.createTicket(jeepId, auth.getName(), issueDescription, severity);
            ra.addFlashAttribute("success", "✅ Ticket created successfully! Jeep marked as unavailable.");
            log.info("✅ Ticket created successfully");
        } catch (Exception e) {
            log.error("❌ Error creating ticket: {}", e.getMessage(), e);
            ra.addFlashAttribute("error", "❌ Error creating ticket: " + e.getMessage());
        }
        
        return "redirect:/maintenance-officer/dashboard";
    }
    
    @PostMapping("/assign-ticket/{ticketId}")
    public String assignTicket(@PathVariable Long ticketId,
                              @RequestParam Long mechanicId,
                              Authentication auth,
                              RedirectAttributes ra) {
        log.info("👨‍🔧 Assigning ticket {} to mechanic {}", ticketId, mechanicId);
        
        try {
            ticketService.assignTicket(ticketId, mechanicId, auth.getName());
            ra.addFlashAttribute("success", "✅ Ticket assigned to mechanic successfully! Mechanic has been notified.");
            log.info("✅ Ticket assigned successfully");
        } catch (Exception e) {
            log.error("❌ Error assigning ticket: {}", e.getMessage(), e);
            ra.addFlashAttribute("error", "❌ Error assigning ticket: " + e.getMessage());
        }
        
        return "redirect:/maintenance-officer/dashboard";
    }
}
