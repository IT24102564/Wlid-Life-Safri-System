package com.safari.WildTrack.service;

import com.safari.WildTrack.enums.BookingStatus;
import com.safari.WildTrack.model.*;
import com.safari.WildTrack.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class BookingService {

    private final BookingRepository bookingRepository;
    private final UserRepository userRepository;
    private final SafariPackageRepository packageRepository;
    private final JeepRepository jeepRepository;
    private final GuideRepository guideRepository;
    private final EmailService emailService;

    public BookingService(BookingRepository bookingRepository,
                          UserRepository userRepository,
                          SafariPackageRepository packageRepository,
                          JeepRepository jeepRepository,
                          GuideRepository guideRepository,
                          EmailService emailService) {
        this.bookingRepository = bookingRepository;
        this.userRepository = userRepository;
        this.packageRepository = packageRepository;
        this.jeepRepository = jeepRepository;
        this.guideRepository = guideRepository;
        this.emailService = emailService;
    }

    @Transactional
    public Booking createBooking(String userEmail, Long packageId, LocalDate safariDate, int numGuests, Long jeepId, Long guideId) {
        User user = userRepository.findByEmail(userEmail)
                .orElseThrow(() -> new IllegalArgumentException("User not found"));
        
        SafariPackage pkg = packageRepository.findById(packageId)
                .orElseThrow(() -> new IllegalArgumentException("Package not found"));

        if (numGuests > pkg.getMaxGuests()) {
            throw new IllegalArgumentException("Number of guests exceeds package limit");
        }

        // Check for existing booking with same details (prevent duplicates)
        var duplicateBookings = bookingRepository.findDuplicateBookings(user, packageId, safariDate, numGuests);
        if (!duplicateBookings.isEmpty()) {
            var existing = duplicateBookings.get(0);
            throw new IllegalArgumentException("A booking with the same details already exists. Booking ID: " + existing.getId());
        }

        // Assign jeep and guide based on user selection or find available ones
        Jeep jeep = null;
        Guide guide = null;
        
        if (jeepId != null) {
            jeep = jeepRepository.findById(jeepId)
                    .filter(j -> j.isAvailable())
                    .orElseThrow(() -> new IllegalArgumentException("Selected jeep is not available"));
        } else {
            jeep = jeepRepository.findFirstByAvailableTrue().orElse(null);
        }
        
        if (guideId != null) {
            guide = guideRepository.findById(guideId)
                    .filter(g -> g.isAvailable())
                    .orElseThrow(() -> new IllegalArgumentException("Selected guide is not available"));
        } else {
            guide = guideRepository.findFirstByAvailableTrue().orElse(null);
        }

        BigDecimal totalPrice = pkg.getPrice().multiply(BigDecimal.valueOf(numGuests));

        Booking booking = Booking.builder()
                .user(user)
                .safariPackage(pkg)
                .jeep(jeep)
                .guide(guide)
                .safariDate(safariDate)
                .numGuests(numGuests)
                .totalPrice(totalPrice)
                .status(BookingStatus.PENDING)
                .createdAt(LocalDateTime.now())
                .build();

        Booking saved = bookingRepository.save(booking);
        
        // Try to send email confirmation, but don't fail if it doesn't work
        try {
            emailService.sendBookingConfirmation(user.getEmail(), saved.getId().toString());
        } catch (Exception e) {
            // Log the error but don't fail the booking
            System.err.println("Failed to send booking confirmation email: " + e.getMessage());
        }
        
        return saved;
    }

    // Overloaded method for backward compatibility
    @Transactional
    public Booking createBooking(String userEmail, Long packageId, LocalDate safariDate, int numGuests) {
        return createBooking(userEmail, packageId, safariDate, numGuests, null, null);
    }

    @Transactional
    public void approveBooking(Long bookingId) {
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new IllegalArgumentException("Booking not found"));
        booking.setStatus(BookingStatus.CONFIRMED);
        bookingRepository.save(booking);
        emailService.sendBookingConfirmation(booking.getUser().getEmail(), "Booking #" + bookingId + " confirmed");
    }

    @Transactional
    public void cancelBooking(Long bookingId) {
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new IllegalArgumentException("Booking not found"));
        booking.setStatus(BookingStatus.CANCELLED);
        bookingRepository.save(booking);
    }

    public List<Booking> getBookingsByUser(String email) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new IllegalArgumentException("User not found"));
        return bookingRepository.findByUserWithDetails(user);
    }

    public List<Booking> getAllBookings() {
        return bookingRepository.findAll();
    }

    public List<Booking> getBookingsByDate(LocalDate date) {
        return bookingRepository.findBySafariDate(date);
    }
}
