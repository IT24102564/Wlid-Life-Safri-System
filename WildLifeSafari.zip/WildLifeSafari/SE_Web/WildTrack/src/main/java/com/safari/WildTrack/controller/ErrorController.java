package com.safari.WildTrack.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.http.HttpServletRequest;

@Controller
public class ErrorController implements org.springframework.boot.web.servlet.error.ErrorController {

    private static final Logger log = LoggerFactory.getLogger(ErrorController.class);

    @RequestMapping("/error")
    public String handleError(HttpServletRequest request, Model model) {
        Object status = request.getAttribute(RequestDispatcher.ERROR_STATUS_CODE);
        Object errorMessage = request.getAttribute(RequestDispatcher.ERROR_MESSAGE);
        Object requestUri = request.getAttribute(RequestDispatcher.ERROR_REQUEST_URI);
        
        log.error("🚨 Error occurred - Status: {}, URI: {}, Message: {}", status, requestUri, errorMessage);
        
        if (status != null) {
            Integer statusCode = Integer.valueOf(status.toString());
            
            model.addAttribute("statusCode", statusCode);
            model.addAttribute("errorMessage", errorMessage != null ? errorMessage.toString() : "Unknown error");
            model.addAttribute("requestUri", requestUri != null ? requestUri.toString() : "Unknown");
            
            if (statusCode == HttpStatus.NOT_FOUND.value()) {
                log.error("❌ 404 Error - Page not found: {}", requestUri);
                model.addAttribute("errorTitle", "Page Not Found");
                model.addAttribute("errorDescription", "The page you're looking for doesn't exist.");
            } else if (statusCode == HttpStatus.INTERNAL_SERVER_ERROR.value()) {
                log.error("❌ 500 Error - Internal server error: {}", errorMessage);
                model.addAttribute("errorTitle", "Internal Server Error");
                model.addAttribute("errorDescription", "Something went wrong on our end. Please try again.");
            } else {
                model.addAttribute("errorTitle", "Error " + statusCode);
                model.addAttribute("errorDescription", "An unexpected error occurred.");
            }
        }
        
        return "error";
    }
}
