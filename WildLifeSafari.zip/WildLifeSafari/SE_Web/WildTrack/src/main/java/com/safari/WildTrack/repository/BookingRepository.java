package com.safari.WildTrack.repository;

import com.safari.WildTrack.model.Booking;
import com.safari.WildTrack.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.util.List;

public interface BookingRepository extends JpaRepository<Booking, Long> {
    List<Booking> findBySafariDate(LocalDate date);
    
    @Query("SELECT DISTINCT b FROM Booking b LEFT JOIN FETCH b.safariPackage LEFT JOIN FETCH b.jeep LEFT JOIN FETCH b.guide WHERE b.user = :user ORDER BY b.createdAt DESC")
    List<Booking> findByUserWithDetails(@Param("user") User user);
    
    @Query("SELECT b FROM Booking b WHERE b.user = :user AND b.safariPackage.id = :packageId AND b.safariDate = :safariDate AND b.numGuests = :numGuests")
    List<Booking> findDuplicateBookings(@Param("user") User user, @Param("packageId") Long packageId, @Param("safariDate") LocalDate safariDate, @Param("numGuests") int numGuests);
    
    List<Booking> findByUser(User user);
}


