package com.safari.WildTrack.config;

import com.safari.WildTrack.enums.Role;
import com.safari.WildTrack.enums.SafariType;
import com.safari.WildTrack.model.User;
import com.safari.WildTrack.model.Jeep;
import com.safari.WildTrack.model.Guide;
import com.safari.WildTrack.repository.UserRepository;
import com.safari.WildTrack.repository.JeepRepository;
import com.safari.WildTrack.repository.GuideRepository;
import com.safari.WildTrack.repository.SafariPackageRepository;
import com.safari.WildTrack.model.SafariPackage;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.math.BigDecimal;
@Configuration
public class DataInitializer {

    @Bean
    CommandLineRunner seedData(UserRepository users,
                               SafariPackageRepository packages,
                               JeepRepository jeeps,
                               GuideRepository guides,
                               PasswordEncoder encoder) {
        return args -> {
            // Always create test user regardless of user count
            createTestUserIfNotExists(users, encoder);
            
            // Always create booking officer if doesn't exist
            createBookingOfficerIfNotExists(users, encoder);
            
            // Always create package builder if doesn't exist
            createPackageBuilderIfNotExists(users, encoder);
            
            // Always create tour crew manager if doesn't exist
            createTourCrewManagerIfNotExists(users, encoder);
            
            // Always create maintenance officer if doesn't exist
            createMaintenanceOfficerIfNotExists(users, encoder);
            
            // Always create mechanic if doesn't exist
            createMechanicIfNotExists(users, encoder);
            
            if (users.count() == 2) { // Only test user and booking officer exist, create others
                User admin = User.builder()
                        .fullName("Admin User")
                        .email("admin@wildtrack.local")
                        .passwordHash(encoder.encode("admin123"))
                        .emailVerified(true)
                        .build();
                admin.getRoles().add(Role.ADMIN);
                admin.getRoles().add(Role.PARK_MANAGER);
                users.save(admin);
            }

            if (packages.count() == 0) {
                packages.save(SafariPackage.builder().name("Half Day").type(SafariType.HALF_DAY).price(new BigDecimal("50.00")).maxGuests(6).description("Half-day safari").build());
                packages.save(SafariPackage.builder().name("Full Day").type(SafariType.FULL_DAY).price(new BigDecimal("90.00")).maxGuests(6).description("Full-day safari").build());
                packages.save(SafariPackage.builder().name("Two Days").type(SafariType.TWO_DAYS).price(new BigDecimal("160.00")).maxGuests(6).description("Two-day safari").build());
            }

            if (jeeps.count() == 0) {
                jeeps.save(Jeep.builder().registrationNumber("JEEP-001").capacity(6).available(true).build());
                jeeps.save(Jeep.builder().registrationNumber("JEEP-002").capacity(6).available(true).build());
                jeeps.save(Jeep.builder().registrationNumber("JEEP-003").capacity(8).available(true).build());
                jeeps.save(Jeep.builder().registrationNumber("JEEP-004").capacity(4).available(true).build());
                jeeps.save(Jeep.builder().registrationNumber("JEEP-005").capacity(6).available(false).build()); // One unavailable for testing
                System.out.println("✅ Created 5 jeeps (4 available, 1 unavailable)");
            }

            if (guides.count() == 0) {
                guides.save(Guide.builder().name("John Safari").phone("+1-555-0001").available(true).build());
                guides.save(Guide.builder().name("Jane Wildlife").phone("+1-555-0002").available(true).build());
                guides.save(Guide.builder().name("Mike Explorer").phone("+1-555-0003").available(true).build());
                guides.save(Guide.builder().name("Sarah Nature").phone("+1-555-0004").available(true).build());
                guides.save(Guide.builder().name("David Adventure").phone("+1-555-0005").available(false).build()); // One unavailable for testing
                System.out.println("✅ Created 5 guides (4 available, 1 unavailable)");
            }
        };
    }

    private void createTestUserIfNotExists(UserRepository users, PasswordEncoder encoder) {
        // Always ensure test user exists
        if (users.findByEmail("user123@gmail.com").isEmpty()) {
            System.out.println("🔧 Creating test user: user123@gmail.com");
            
            User testUser = User.builder()
                    .fullName("Test User")
                    .email("user123@gmail.com")
                    .passwordHash(encoder.encode("user123"))
                    .emailVerified(true)  // Pre-verified, no OTP needed
                    .build();
            testUser.getRoles().add(Role.TOURIST);
            User saved = users.save(testUser);
            
            System.out.println("✅ Test user created successfully!");
            System.out.println("🔑 Email: " + saved.getEmail());
            System.out.println("🔑 Password: user123");
            System.out.println("✅ Email Verified: " + saved.isEmailVerified());
            System.out.println("👤 Roles: " + saved.getRoles());
            System.out.println("🆔 ID: " + saved.getId());
        } else {
            System.out.println("✅ Test user user123@gmail.com already exists");
        }
    }

    private void createBookingOfficerIfNotExists(UserRepository users, PasswordEncoder encoder) {
        // Always ensure booking officer exists
        if (users.findByEmail("bookingofficer@wildtrack.com").isEmpty()) {
            System.out.println("🔧 Creating Booking Officer: bookingofficer@wildtrack.com");
            
            User officer = User.builder()
                    .fullName("Booking Officer")
                    .email("bookingofficer@wildtrack.com")
                    .passwordHash(encoder.encode("booking123"))
                    .emailVerified(true)
                    .phone("+1-555-1000")
                    .build();
            officer.getRoles().add(Role.BOOKING_OFFICER);
            User saved = users.save(officer);
            
            System.out.println("✅ Booking Officer Account Created Successfully!");
            System.out.println("📧 Email: " + saved.getEmail());
            System.out.println("🔑 Password: booking123");
            System.out.println("✅ Email Verified: " + saved.isEmailVerified());
            System.out.println("👤 Roles: " + saved.getRoles());
            System.out.println("🆔 ID: " + saved.getId());
            System.out.println("🔒 Access: /booking-officer/dashboard");
        } else {
            System.out.println("✅ Booking Officer bookingofficer@wildtrack.com already exists");
        }
    }

    private void createPackageBuilderIfNotExists(UserRepository users, PasswordEncoder encoder) {
        // Always ensure package builder exists
        if (users.findByEmail("packagebuilder@wildtrack.com").isEmpty()) {
            System.out.println("🔧 Creating Package Builder: packagebuilder@wildtrack.com");
            
            User builder = User.builder()
                    .fullName("Package Builder")
                    .email("packagebuilder@wildtrack.com")
                    .passwordHash(encoder.encode("package123"))
                    .emailVerified(true)
                    .phone("+1-555-2000")
                    .build();
            builder.getRoles().add(Role.PACKAGE_BUILDER);
            User saved = users.save(builder);
            
            System.out.println("✅ Package Builder Account Created Successfully!");
            System.out.println("📧 Email: " + saved.getEmail());
            System.out.println("🔑 Password: package123");
            System.out.println("✅ Email Verified: " + saved.isEmailVerified());
            System.out.println("👤 Roles: " + saved.getRoles());
            System.out.println("🆔 ID: " + saved.getId());
            System.out.println("🔒 Access: /package-builder/dashboard");
        } else {
            System.out.println("✅ Package Builder packagebuilder@wildtrack.com already exists");
        }
    }

    private void createTourCrewManagerIfNotExists(UserRepository users, PasswordEncoder encoder) {
        // Always ensure tour crew manager exists
        if (users.findByEmail("tourmanager@wildtrack.com").isEmpty()) {
            System.out.println("🔧 Creating Tour Crew Manager: tourmanager@wildtrack.com");
            
            User manager = User.builder()
                    .fullName("Tour Crew Manager")
                    .email("tourmanager@wildtrack.com")
                    .passwordHash(encoder.encode("tour123"))
                    .emailVerified(true)
                    .phone("+1-555-3000")
                    .build();
            manager.getRoles().add(Role.TOUR_MANAGER);
            User saved = users.save(manager);
            
            System.out.println("✅ Tour Crew Manager Account Created Successfully!");
            System.out.println("📧 Email: " + saved.getEmail());
            System.out.println("🔑 Password: tour123");
            System.out.println("✅ Email Verified: " + saved.isEmailVerified());
            System.out.println("👤 Roles: " + saved.getRoles());
            System.out.println("🆔 ID: " + saved.getId());
            System.out.println("🔒 Access: /tour-crew-manager/dashboard");
        } else {
            System.out.println("✅ Tour Crew Manager tourmanager@wildtrack.com already exists");
        }
    }

    private void createMaintenanceOfficerIfNotExists(UserRepository users, PasswordEncoder encoder) {
        // Always ensure maintenance officer exists
        if (users.findByEmail("maintenance@wildtrack.com").isEmpty()) {
            System.out.println("🔧 Creating Maintenance Officer: maintenance@wildtrack.com");
            
            User maintenanceOfficer = User.builder()
                    .fullName("Maintenance Officer")
                    .email("maintenance@wildtrack.com")
                    .passwordHash(encoder.encode("maintenance123"))
                    .emailVerified(true)
                    .phone("+1-555-4000")
                    .build();
            maintenanceOfficer.getRoles().add(Role.MAINTENANCE_OFFICER);
            User saved = users.save(maintenanceOfficer);
            
            System.out.println("✅ Maintenance Officer Account Created Successfully!");
            System.out.println("📧 Email: " + saved.getEmail());
            System.out.println("🔑 Password: maintenance123");
            System.out.println("✅ Email Verified: " + saved.isEmailVerified());
            System.out.println("👤 Roles: " + saved.getRoles());
            System.out.println("🆔 ID: " + saved.getId());
            System.out.println("🔒 Access: /maintenance-officer/dashboard");
        } else {
            System.out.println("✅ Maintenance Officer maintenance@wildtrack.com already exists");
        }
    }

    private void createMechanicIfNotExists(UserRepository users, PasswordEncoder encoder) {
        // Always ensure mechanic exists
        if (users.findByEmail("mechanic1@wildtrack.com").isEmpty()) {
            System.out.println("🔧 Creating Mechanic: mechanic1@wildtrack.com");
            
            User mechanic = User.builder()
                    .fullName("John Mechanic")
                    .email("mechanic1@wildtrack.com")
                    .passwordHash(encoder.encode("mechanic123"))
                    .emailVerified(true)
                    .phone("+1-555-5000")
                    .build();
            mechanic.getRoles().add(Role.MECHANIC);
            User saved = users.save(mechanic);
            
            System.out.println("✅ Mechanic Account Created Successfully!");
            System.out.println("📧 Email: " + saved.getEmail());
            System.out.println("🔑 Password: mechanic123");
            System.out.println("✅ Email Verified: " + saved.isEmailVerified());
            System.out.println("👤 Roles: " + saved.getRoles());
            System.out.println("🆔 ID: " + saved.getId());
            System.out.println("🔒 Access: /mechanic/dashboard");
        } else {
            System.out.println("✅ Mechanic mechanic1@wildtrack.com already exists");
        }
    }
}


