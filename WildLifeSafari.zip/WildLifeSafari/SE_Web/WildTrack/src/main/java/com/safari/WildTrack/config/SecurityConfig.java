package com.safari.WildTrack.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    private final CustomAuthenticationSuccessHandler successHandler;

    public SecurityConfig(CustomAuthenticationSuccessHandler successHandler) {
        this.successHandler = successHandler;
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
                .csrf(csrf -> csrf.disable())
                .authorizeHttpRequests(auth -> auth
                        .requestMatchers("/api/auth/**").permitAll()
                        .requestMatchers("/actuator/**").permitAll()
                        .requestMatchers("/login", "/register", "/verify", "/verify-otp", "/", "/home", "/packages", "/package/**", "/new-booking", "/create-booking", "/bookings", "/search/**", "/debug/**", "/test/**", "/quick-fix-user", "/create-booking-officer", "/simple-success", "/safe-dashboard", "/feedback", "/health-check", "/status", "/login-info", "/access-denied", "/test-error", "/test-404", "/error", "/static/**", "/css/**", "/js/**").permitAll()
                        .requestMatchers("/profile/**").authenticated()
                        .requestMatchers("/admin/**").hasRole("ADMIN")
                        .requestMatchers("/park-manager/**").hasRole("PARK_MANAGER")
                        .requestMatchers("/booking-officer/**").hasRole("BOOKING_OFFICER")
                        .requestMatchers("/package-builder/**").hasRole("PACKAGE_BUILDER")
                        .requestMatchers("/tour-crew-manager/**").hasRole("TOUR_MANAGER")
                        .requestMatchers("/maintenance-officer/**").hasRole("MAINTENANCE_OFFICER")
                        .requestMatchers("/mechanic/**").hasRole("MECHANIC")
                        .requestMatchers("/driver/**").hasRole("DRIVER")
                        .requestMatchers("/guide/**").hasRole("GUIDE")
                        .anyRequest().permitAll()
                )
                .formLogin(form -> form
                        .loginPage("/login")
                        .loginProcessingUrl("/perform-login")
                        .successHandler(successHandler)
                        .failureUrl("/login?error=true")
                        .permitAll()
                )
                .logout(logout -> logout
                        .logoutUrl("/logout")
                        .logoutSuccessUrl("/login?logout=true")
                        .permitAll()
                );
        return http.build();
    }
}


