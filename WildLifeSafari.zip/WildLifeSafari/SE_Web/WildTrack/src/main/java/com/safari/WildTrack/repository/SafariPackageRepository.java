package com.safari.WildTrack.repository;

import com.safari.WildTrack.model.SafariPackage;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SafariPackageRepository extends JpaRepository<SafariPackage, Long> { }


