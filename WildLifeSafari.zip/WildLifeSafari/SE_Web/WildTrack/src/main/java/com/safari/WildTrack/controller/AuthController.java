package com.safari.WildTrack.controller;

import com.safari.WildTrack.service.AuthService;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/auth")
@Validated
public class AuthController {

    private final AuthService authService;

    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody Map<String, String> body) {
        String fullName = body.getOrDefault("fullName", "");
        String email = body.getOrDefault("email", "");
        String password = body.getOrDefault("password", "");
        authService.registerTourist(fullName, email, password);
        return ResponseEntity.ok(Map.of("message", "Registration successful. Check email for OTP."));
    }

    @PostMapping("/verify")
    public ResponseEntity<?> verify(@RequestBody Map<String, String> body) {
        String email = body.get("email");
        String otp = body.get("otp");
        boolean ok = authService.verifyEmail(email, otp);
        if (ok) return ResponseEntity.ok(Map.of("message", "Email verified."));
        return ResponseEntity.badRequest().body(Map.of("message", "Invalid or expired OTP"));
    }
}


