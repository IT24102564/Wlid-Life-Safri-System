package com.safari.WildTrack.service;

import com.safari.WildTrack.enums.Role;
import com.safari.WildTrack.model.User;
import com.safari.WildTrack.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Random;

@Service
public class AuthService {

    private static final Logger log = LoggerFactory.getLogger(AuthService.class);

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final EmailService emailService;

    public AuthService(UserRepository userRepository,
                       PasswordEncoder passwordEncoder,
                       EmailService emailService) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.emailService = emailService;
    }

    @Transactional
    public void registerTourist(String fullName, String email, String rawPassword) {
        log.info("🚀 Starting tourist registration for: {}", email);
        
        if (userRepository.existsByEmail(email)) {
            log.warn("❌ Registration failed - Email already exists: {}", email);
            throw new IllegalArgumentException("Email already registered");
        }
        
        String otp = generateOtp();
        log.info("✅ Generated OTP for {}: {}", email, otp);
        
        User user = User.builder()
                .fullName(fullName)
                .email(email)
                .passwordHash(passwordEncoder.encode(rawPassword))
                .emailVerified(false)
                .otpCode(otp)
                .otpExpiry(LocalDateTime.now().plusMinutes(10))
                .build();
        user.getRoles().add(Role.TOURIST);
        
        User savedUser = userRepository.save(user);
        log.info("✅ User saved to database with ID: {}", savedUser.getId());
        
        log.info("📧 Sending OTP email to: {}", email);
        emailService.sendOtp(email, otp);
        log.info("🎉 Registration process completed for: {}", email);
    }

    @Transactional
    public boolean verifyEmail(String email, String otp) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new IllegalArgumentException("User not found"));
        if (user.isEmailVerified()) return true;
        if (user.getOtpCode() == null || user.getOtpExpiry() == null) return false;
        if (user.getOtpExpiry().isBefore(LocalDateTime.now())) return false;
        if (!user.getOtpCode().equals(otp)) return false;
        user.setEmailVerified(true);
        user.setOtpCode(null);
        user.setOtpExpiry(null);
        userRepository.save(user);
        return true;
    }

    private String generateOtp() {
        Random random = new Random();
        int code = 100000 + random.nextInt(900000);
        return String.valueOf(code);
    }
}


