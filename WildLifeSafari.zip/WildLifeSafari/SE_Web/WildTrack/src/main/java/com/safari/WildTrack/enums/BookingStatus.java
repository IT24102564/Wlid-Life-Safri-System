package com.safari.WildTrack.enums;

public enum BookingStatus {
    PENDING,                    // User created booking, waiting for Booking Officer to send to Tour Crew Manager
    PENDING_USER_CONFIRMATION,  // Tour Crew Manager modified resources, waiting for user to confirm/cancel
    CONFIRMED,                  // Booking Officer approved, booking confirmed
    ALLOCATED,                  // Resources allocated (legacy status)
    CANCEL_PENDING,             // Cancellation requested
    CANCELLED,                  // Booking cancelled
    COMPLETED                   // Safari completed
}


