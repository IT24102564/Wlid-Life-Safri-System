package com.safari.WildTrack.enums;

public enum AllocationStatus {
    PENDING_APPROVAL,      // Booking Officer requested, waiting for Tour Crew Manager
    APPROVED,              // Tour Crew Manager approved the allocation
    REJECTED,              // Tour Crew Manager rejected (resources not available)
    MODIFIED               // Tour Crew Manager modified the allocation
}
