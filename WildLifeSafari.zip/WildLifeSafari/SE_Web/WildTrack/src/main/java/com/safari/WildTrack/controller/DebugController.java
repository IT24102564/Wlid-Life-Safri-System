package com.safari.WildTrack.controller;

import com.safari.WildTrack.enums.Role;
import com.safari.WildTrack.model.User;
import com.safari.WildTrack.repository.UserRepository;
import com.safari.WildTrack.service.EmailService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Optional;

@Controller
public class DebugController {

    private final UserRepository userRepository;
    private final EmailService emailService;
    private final PasswordEncoder passwordEncoder;

    public DebugController(UserRepository userRepository, EmailService emailService, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.emailService = emailService;
        this.passwordEncoder = passwordEncoder;
    }

    @GetMapping("/debug/register-page")
    public String debugRegisterPage() {
        return "debug-register";
    }

    @GetMapping("/debug/users")
    @ResponseBody
    public String checkUsers() {
        List<User> users = userRepository.findAll();
        StringBuilder sb = new StringBuilder();
        sb.append("=== REGISTERED USERS ===\n");
        sb.append("Total: ").append(users.size()).append("\n\n");
        
        for (User user : users) {
            sb.append("ID: ").append(user.getId()).append("\n");
            sb.append("Email: ").append(user.getEmail()).append("\n");
            sb.append("Name: ").append(user.getFullName()).append("\n");
            sb.append("Verified: ").append(user.isEmailVerified()).append("\n");
            sb.append("Roles: ").append(user.getRoles()).append("\n");
            sb.append("OTP: ").append(user.getOtpCode()).append("\n");
            sb.append("OTP Expiry: ").append(user.getOtpExpiry()).append("\n");
            sb.append("---\n");
        }
        
        return sb.toString();
    }

    @GetMapping("/debug/test-otp")
    @ResponseBody
    public String testOtp(@RequestParam String email) {
        try {
            emailService.sendOtp(email, "123456");
            return "✅ OTP sent successfully to: " + email;
        } catch (Exception e) {
            return "❌ OTP test failed: " + e.getMessage();
        }
    }

    @GetMapping("/create-booking-officer")
    @ResponseBody
    public String createBookingOfficer() {
        try {
            // Check if booking officer already exists
            Optional<User> existing = userRepository.findByEmail("bookingofficer@wildtrack.com");
            
            if (existing.isPresent()) {
                return "✅ Booking Officer already exists!\n" +
                       "📧 Email: bookingofficer@wildtrack.com\n" +
                       "🔑 Password: booking123\n" +
                       "👤 Name: " + existing.get().getFullName() + "\n" +
                       "🎯 Roles: " + existing.get().getRoles() + "\n" +
                       "✅ Email Verified: " + existing.get().isEmailVerified() + "\n" +
                       "🔗 Login at: http://localhost:8080/login";
            }
            
            // Create new booking officer
            User officer = User.builder()
                    .fullName("Booking Officer")
                    .email("bookingofficer@wildtrack.com")
                    .passwordHash(passwordEncoder.encode("booking123"))
                    .emailVerified(true)
                    .phone("+1-555-1000")
                    .build();
            officer.getRoles().add(Role.BOOKING_OFFICER);
            User saved = userRepository.save(officer);
            
            return "✅ Booking Officer Created Successfully!\n" +
                   "================================\n" +
                   "📧 Email: bookingofficer@wildtrack.com\n" +
                   "🔑 Password: booking123\n" +
                   "👤 Name: " + saved.getFullName() + "\n" +
                   "🎯 Roles: " + saved.getRoles() + "\n" +
                   "✅ Email Verified: " + saved.isEmailVerified() + "\n" +
                   "🆔 User ID: " + saved.getId() + "\n" +
                   "================================\n" +
                   "🔗 Login at: http://localhost:8080/login\n" +
                   "🔗 Dashboard: http://localhost:8080/booking-officer/dashboard";
                   
        } catch (Exception e) {
            return "❌ Error creating booking officer: " + e.getMessage();
        }
    }

    @GetMapping("/database")
    @ResponseBody
    public String databaseStatus() {
        try {
            long userCount = userRepository.count();
            return "✅ Database connection OK\n" +
                   "📊 Total users in database: " + userCount + "\n" +
                   "🗄️ Database: wildtrack_db\n" +
                   "🔑 Table: users";
        } catch (Exception e) {
            return "❌ Database error: " + e.getMessage();
        }
    }

    @GetMapping("/debug/create-test-user")
    @ResponseBody
    public String createTestUser() {
        try {
            // Check if user already exists
            var existingUser = userRepository.findByEmail("user123@gmail.com");
            if (existingUser.isPresent()) {
                User user = existingUser.get();
                return "✅ User user123@gmail.com already exists!\n" +
                       "🔑 Email: " + user.getEmail() + "\n" +
                       "🔑 Password: user123\n" +
                       "✅ Email Verified: " + user.isEmailVerified() + "\n" +
                       "👤 Roles: " + user.getRoles() + "\n" +
                       "🆔 ID: " + user.getId() + "\n" +
                       "🌐 Login at: http://localhost:8080/login";
            }

            // Create new user
            User testUser = User.builder()
                    .fullName("Test User")
                    .email("user123@gmail.com")
                    .passwordHash(passwordEncoder.encode("user123"))
                    .emailVerified(true)  // Pre-verified, no OTP needed
                    .build();
            testUser.getRoles().add(Role.TOURIST);
            User savedUser = userRepository.save(testUser);

            return "✅ Test user created successfully!\n" +
                   "🔑 Email: " + savedUser.getEmail() + "\n" +
                   "🔑 Password: user123\n" +
                   "✅ Email Verified: " + savedUser.isEmailVerified() + "\n" +
                   "👤 Role: " + savedUser.getRoles() + "\n" +
                   "🆔 ID: " + savedUser.getId() + "\n" +
                   "🌐 Login at: http://localhost:8080/login";

        } catch (Exception e) {
            return "❌ Failed to create test user: " + e.getMessage() + "\n" +
                   "📋 Stack trace: " + e.getClass().getSimpleName();
        }
    }

    @GetMapping("/debug/fix-test-user")
    @ResponseBody
    public String fixTestUser() {
        try {
            var userOpt = userRepository.findByEmail("user123@gmail.com");
            if (userOpt.isEmpty()) {
                return "❌ User user123@gmail.com not found. Create it first at /debug/create-test-user";
            }

            User user = userOpt.get();
            user.setEmailVerified(true);
            if (user.getRoles().isEmpty()) {
                user.getRoles().add(Role.TOURIST);
            }
            User savedUser = userRepository.save(user);

            return "✅ Test user fixed successfully!\n" +
                   "🔑 Email: " + savedUser.getEmail() + "\n" +
                   "🔑 Password: user123\n" +
                   "✅ Email Verified: " + savedUser.isEmailVerified() + "\n" +
                   "👤 Roles: " + savedUser.getRoles() + "\n" +
                   "🆔 ID: " + savedUser.getId() + "\n" +
                   "🌐 Ready to login at: http://localhost:8080/login";

        } catch (Exception e) {
            return "❌ Failed to fix test user: " + e.getMessage();
        }
    }

    @GetMapping("/debug/delete-test-user")
    @ResponseBody
    public String deleteTestUser() {
        try {
            var userOpt = userRepository.findByEmail("user123@gmail.com");
            if (userOpt.isEmpty()) {
                return "❌ User user123@gmail.com not found.";
            }

            userRepository.delete(userOpt.get());
            return "✅ User user123@gmail.com deleted successfully!\n" +
                   "💡 Now visit /debug/create-test-user to recreate it properly.";

        } catch (Exception e) {
            return "❌ Failed to delete test user: " + e.getMessage();
        }
    }

    @GetMapping("/debug/force-create-user")
    @ResponseBody
    public String forceCreateUser() {
        try {
            // Delete existing user if exists
            userRepository.findByEmail("user123@gmail.com").ifPresent(userRepository::delete);

            // Create fresh user with detailed logging
            String rawPassword = "user123";
            String encodedPassword = passwordEncoder.encode(rawPassword);
            
            User testUser = new User();
            testUser.setFullName("Test User");
            testUser.setEmail("user123@gmail.com");
            testUser.setPasswordHash(encodedPassword);
            testUser.setEmailVerified(true);
            testUser.getRoles().add(Role.TOURIST);
            
            User savedUser = userRepository.save(testUser);

            // Verify the saved user
            var verifyUser = userRepository.findByEmail("user123@gmail.com");
            if (verifyUser.isEmpty()) {
                return "❌ User creation failed - not found after save";
            }

            User verified = verifyUser.get();
            boolean passwordMatches = passwordEncoder.matches(rawPassword, verified.getPasswordHash());

            return "✅ FORCE CREATED Test User Successfully!\n" +
                   "🔑 Email: " + verified.getEmail() + "\n" +
                   "🔑 Password: " + rawPassword + "\n" +
                   "🔐 Password Hash: " + verified.getPasswordHash().substring(0, 20) + "...\n" +
                   "✅ Email Verified: " + verified.isEmailVerified() + "\n" +
                   "👤 Roles: " + verified.getRoles() + "\n" +
                   "🆔 ID: " + verified.getId() + "\n" +
                   "🔍 Password Test: " + (passwordMatches ? "✅ MATCHES" : "❌ MISMATCH") + "\n" +
                   "🌐 Ready to login at: http://localhost:8080/login";

        } catch (Exception e) {
            return "❌ Failed to force create user: " + e.getMessage() + "\n" +
                   "📋 Error type: " + e.getClass().getSimpleName();
        }
    }

    @GetMapping("/debug/test-login")
    @ResponseBody
    public String testLogin(@RequestParam String email, @RequestParam String password) {
        try {
            var userOpt = userRepository.findByEmail(email);
            if (userOpt.isEmpty()) {
                return "❌ User not found: " + email;
            }

            User user = userOpt.get();
            boolean passwordMatches = passwordEncoder.matches(password, user.getPasswordHash());

            return "🔍 LOGIN TEST RESULTS:\n" +
                   "📧 Email: " + user.getEmail() + "\n" +
                   "👤 Name: " + user.getFullName() + "\n" +
                   "✅ Email Verified: " + user.isEmailVerified() + "\n" +
                   "👤 Roles: " + user.getRoles() + "\n" +
                   "🔐 Password Hash: " + user.getPasswordHash().substring(0, 20) + "...\n" +
                   "🔍 Password Match: " + (passwordMatches ? "✅ CORRECT" : "❌ WRONG") + "\n" +
                   "🆔 User ID: " + user.getId() + "\n" +
                   "\n" +
                   (passwordMatches && user.isEmailVerified() ? 
                    "✅ LOGIN SHOULD WORK!" : 
                    "❌ LOGIN WILL FAIL - Check password or email verification");

        } catch (Exception e) {
            return "❌ Test login failed: " + e.getMessage();
        }
    }
}
