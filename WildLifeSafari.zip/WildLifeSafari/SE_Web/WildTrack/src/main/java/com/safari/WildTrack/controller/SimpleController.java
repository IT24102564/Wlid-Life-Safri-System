package com.safari.WildTrack.controller;

import com.safari.WildTrack.model.User;
import com.safari.WildTrack.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class SimpleController {

    private static final Logger log = LoggerFactory.getLogger(SimpleController.class);
    private final UserRepository userRepository;

    public SimpleController(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @GetMapping("/simple-success")
    @ResponseBody
    public String simpleSuccess(Authentication auth) {
        log.info("🎉 Simple success page accessed");
        
        if (auth == null) {
            log.warn("❌ No authentication found");
            return "❌ No authentication found. <a href='/login'>Login here</a>";
        }

        String email = auth.getName();
        log.info("✅ User authenticated: {}", email);
        
        User user = userRepository.findByEmail(email).orElse(null);
        if (user == null) {
            log.error("❌ User not found in database: {}", email);
            return "❌ User not found. <a href='/login'>Login again</a>";
        }

        log.info("✅ Login completely successful for: {}", email);
        
        return "<!DOCTYPE html>" +
               "<html><head><title>WildTrack - Login Success</title>" +
               "<style>body{font-family:Arial,sans-serif;margin:50px;background:#f5f7fa;}" +
               ".card{background:white;padding:30px;border-radius:8px;box-shadow:0 2px 8px rgba(0,0,0,0.1);max-width:600px;margin:0 auto;}" +
               ".success{background:#d4edda;color:#155724;padding:15px;border-radius:4px;margin:20px 0;}" +
               ".btn{background:#1f7a56;color:white;padding:10px 20px;text-decoration:none;border-radius:4px;display:inline-block;margin:5px;}" +
               "</style></head><body>" +
               "<div class='card'>" +
               "<h1>🎉 Login Successful!</h1>" +
               "<div class='success'><strong>✅ Welcome to WildTrack Safari!</strong></div>" +
               "<p><strong>Name:</strong> " + user.getFullName() + "</p>" +
               "<p><strong>Email:</strong> " + email + "</p>" +
               "<p><strong>Roles:</strong> " + user.getRoles() + "</p>" +
               "<p><strong>Status:</strong> ✅ Successfully Authenticated</p>" +
               "<div style='margin-top:30px;'>" +
               "<a href='/dashboard' class='btn'>🏠 Go to Dashboard</a>" +
               "<a href='/packages' class='btn'>🦁 Browse Safaris</a>" +
               "<a href='/logout' class='btn' style='background:#dc3545;'>🚪 Logout</a>" +
               "</div>" +
               "<div style='margin-top:30px;padding-top:20px;border-top:1px solid #eee;color:#666;'>" +
               "<p>🔧 <strong>Debug Info:</strong> Login system is working perfectly!</p>" +
               "<p>📅 Login Time: " + java.time.LocalDateTime.now() + "</p>" +
               "</div>" +
               "</div></body></html>";
    }

    @GetMapping("/health-check")
    @ResponseBody
    public String healthCheck() {
        return "✅ WildTrack Application is running!\n" +
               "🕐 Time: " + java.time.LocalDateTime.now() + "\n" +
               "🗄️ Database Users: " + userRepository.count() + "\n" +
               "🌐 Status: All systems operational";
    }

    @GetMapping("/test-error")
    @ResponseBody
    public String testError() {
        log.info("🧪 Testing error handling");
        throw new RuntimeException("This is a test error to verify error handling works");
    }

    @GetMapping("/test-404")
    public String test404() {
        log.info("🧪 Testing 404 handling");
        return "non-existent-template";
    }

    @GetMapping("/test-booking-service")
    @ResponseBody
    public String testBookingService() {
        try {
            long userCount = userRepository.count();
            return "✅ Database connection OK\n" +
                   "📊 Total users: " + userCount + "\n" +
                   "🔧 BookingService test: Ready to test\n" +
                   "💡 Try: /test-booking-service?email=user123@gmail.com";
        } catch (Exception e) {
            return "❌ Database error: " + e.getMessage();
        }
    }

    @GetMapping("/status")
    public String systemStatusPage() {
        return "system-status";
    }

    @GetMapping("/login-info")
    public String loginInfoPage() {
        return "login-info";
    }

    @GetMapping("/access-denied")
    public String accessDenied() {
        return "access-denied";
    }
}
