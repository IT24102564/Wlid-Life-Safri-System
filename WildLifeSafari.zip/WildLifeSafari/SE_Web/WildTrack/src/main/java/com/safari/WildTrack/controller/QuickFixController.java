package com.safari.WildTrack.controller;

import com.safari.WildTrack.enums.Role;
import com.safari.WildTrack.model.User;
import com.safari.WildTrack.repository.UserRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class QuickFixController {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public QuickFixController(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @GetMapping("/quick-fix-user")
    public String quickFixUser() {
        try {
            // Delete existing user if exists
            userRepository.findByEmail("user123@gmail.com").ifPresent(userRepository::delete);

            // Create new user with manual approach (not using Builder)
            User testUser = new User();
            testUser.setFullName("Test User");
            testUser.setEmail("user123@gmail.com");
            testUser.setPasswordHash(passwordEncoder.encode("user123"));
            testUser.setEmailVerified(true);
            
            // Initialize roles manually
            testUser.getRoles().clear();
            testUser.getRoles().add(Role.TOURIST);
            
            User savedUser = userRepository.save(testUser);
            userRepository.flush(); // Force immediate save

            // Verify the user was saved
            var verifyUser = userRepository.findByEmail("user123@gmail.com");
            if (verifyUser.isEmpty()) {
                return "❌ FAILED: User not found after save";
            }

            User verified = verifyUser.get();
            boolean passwordMatches = passwordEncoder.matches("user123", verified.getPasswordHash());

            return "✅ QUICK FIX SUCCESSFUL!\n" +
                   "🔑 Email: " + verified.getEmail() + "\n" +
                   "🔑 Password: user123\n" +
                   "✅ Email Verified: " + verified.isEmailVerified() + "\n" +
                   "👤 Roles: " + verified.getRoles() + "\n" +
                   "🆔 ID: " + verified.getId() + "\n" +
                   "🔍 Password Test: " + (passwordMatches ? "✅ MATCHES" : "❌ MISMATCH") + "\n" +
                   "🌐 LOGIN NOW: http://localhost:8080/login\n" +
                   "\n" +
                   "📋 Database Count: " + userRepository.count() + " users total";

        } catch (Exception e) {
            return "❌ QUICK FIX FAILED: " + e.getMessage() + "\n" +
                   "📋 Error: " + e.getClass().getSimpleName() + "\n" +
                   "🔧 Try restarting the application";
        }
    }
}
