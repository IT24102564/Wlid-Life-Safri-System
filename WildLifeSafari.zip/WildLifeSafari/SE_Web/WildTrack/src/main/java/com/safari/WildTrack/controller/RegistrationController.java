package com.safari.WildTrack.controller;

import com.safari.WildTrack.service.AuthService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class RegistrationController {

    private static final Logger log = LoggerFactory.getLogger(RegistrationController.class);

    private final AuthService authService;

    public RegistrationController(AuthService authService) {
        this.authService = authService;
    }

    @GetMapping("/register")
    public String showRegistrationForm(Model model) {
        return "register";
    }

    @PostMapping("/register")
    public String registerUser(@RequestParam String fullName,
                               @RequestParam String email,
                               @RequestParam String password,
                               RedirectAttributes ra) {
        log.info("🌐 Registration request received for: {}", email);
        log.info("📝 Full Name: {}", fullName);
        
        try {
            authService.registerTourist(fullName, email, password);
            log.info("✅ Registration successful for: {}", email);
            ra.addFlashAttribute("success", "Registration successful! Please check your email for the OTP verification code.");
            ra.addAttribute("email", email);
            return "redirect:/verify";
        } catch (IllegalArgumentException e) {
            log.warn("❌ Registration failed for {}: {}", email, e.getMessage());
            ra.addFlashAttribute("error", e.getMessage());
            return "redirect:/register";
        } catch (Exception e) {
            log.error("💥 Unexpected registration error for {}: {}", email, e.getMessage(), e);
            ra.addFlashAttribute("error", "Registration failed. Please try again.");
            return "redirect:/register";
        }
    }

    @GetMapping("/verify")
    public String showVerificationForm(@RequestParam(required = false) String email, Model model) {
        model.addAttribute("email", email);
        return "verify-otp";
    }

    @PostMapping("/verify")
    public String verifyOtp(@RequestParam String email,
                            @RequestParam String otp,
                            RedirectAttributes ra) {
        try {
            boolean verified = authService.verifyEmail(email, otp);
            if (verified) {
                ra.addFlashAttribute("success", "Email verified successfully! You can now login to your account.");
                return "redirect:/login?verified=true";
            } else {
                ra.addFlashAttribute("error", "Invalid or expired OTP. Please try again.");
                ra.addAttribute("email", email);
                return "redirect:/verify";
            }
        } catch (Exception e) {
            ra.addFlashAttribute("error", "Verification failed. Please try again.");
            ra.addAttribute("email", email);
            return "redirect:/verify";
        }
    }
}
