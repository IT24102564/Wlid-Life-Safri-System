package com.safari.WildTrack.controller;

import com.safari.WildTrack.enums.BookingStatus;
import com.safari.WildTrack.model.Booking;
import com.safari.WildTrack.model.SafariPackage;
import com.safari.WildTrack.repository.BookingRepository;
import com.safari.WildTrack.repository.SafariPackageRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/bookings")
public class BookingController {

    private final BookingRepository bookingRepository;
    private final SafariPackageRepository packageRepository;

    public BookingController(BookingRepository bookingRepository, SafariPackageRepository packageRepository) {
        this.bookingRepository = bookingRepository;
        this.packageRepository = packageRepository;
    }

    @GetMapping
    public List<Booking> list(@RequestParam(required = false) String date) {
        if (date != null) {
            return bookingRepository.findBySafariDate(LocalDate.parse(date));
        }
        return bookingRepository.findAll();
    }

    @PostMapping
    public ResponseEntity<?> create(@RequestBody Map<String, String> body) {
        Long packageId = Long.parseLong(body.get("packageId"));
        LocalDate safariDate = LocalDate.parse(body.get("safariDate"));
        int numGuests = Integer.parseInt(body.get("numGuests"));

        SafariPackage pkg = packageRepository.findById(packageId).orElseThrow();
        BigDecimal total = pkg.getPrice().multiply(BigDecimal.valueOf(numGuests));

        Booking booking = Booking.builder()
                .safariPackage(pkg)
                .safariDate(safariDate)
                .numGuests(numGuests)
                .status(BookingStatus.PENDING)
                .totalPrice(total)
                .createdAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .build();
        bookingRepository.save(booking);
        return ResponseEntity.ok(booking);
    }
}


