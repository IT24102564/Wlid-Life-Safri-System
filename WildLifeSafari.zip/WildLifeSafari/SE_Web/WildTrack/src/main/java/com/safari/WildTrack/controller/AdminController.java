package com.safari.WildTrack.controller;

import com.safari.WildTrack.enums.Role;
import com.safari.WildTrack.model.User;
import com.safari.WildTrack.repository.UserRepository;
import com.safari.WildTrack.service.AuthService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/admin")
public class AdminController {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public AdminController(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @GetMapping("/users")
    public String manageUsers(Model model) {
        model.addAttribute("users", userRepository.findAll());
        return "admin-users";
    }

    @GetMapping("/staff/new")
    public String newStaffForm(Model model) {
        model.addAttribute("roles", Role.values());
        return "admin-new-staff";
    }

    @PostMapping("/staff/create")
    public String createStaff(@RequestParam String fullName,
                              @RequestParam String email,
                              @RequestParam String password,
                              @RequestParam String role,
                              RedirectAttributes ra) {
        try {
            if (userRepository.existsByEmail(email)) {
                ra.addFlashAttribute("error", "Email already exists");
                return "redirect:/admin/staff/new";
            }

            User staff = User.builder()
                    .fullName(fullName)
                    .email(email)
                    .passwordHash(passwordEncoder.encode(password))
                    .emailVerified(true)
                    .build();
            
            staff.getRoles().add(Role.valueOf(role));
            userRepository.save(staff);
            
            ra.addFlashAttribute("success", "Staff account created successfully");
            return "redirect:/admin/users";
        } catch (Exception e) {
            ra.addFlashAttribute("error", "Error creating staff account: " + e.getMessage());
            return "redirect:/admin/staff/new";
        }
    }

    @PostMapping("/users/{id}/toggle-status")
    public String toggleUserStatus(@PathVariable Long id, RedirectAttributes ra) {
        User user = userRepository.findById(id).orElse(null);
        if (user != null) {
            user.setEmailVerified(!user.isEmailVerified());
            userRepository.save(user);
            ra.addFlashAttribute("success", "User status updated");
        } else {
            ra.addFlashAttribute("error", "User not found");
        }
        return "redirect:/admin/users";
    }
}
