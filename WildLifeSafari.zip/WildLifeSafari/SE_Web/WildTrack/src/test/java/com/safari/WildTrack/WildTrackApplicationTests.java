package com.safari.WildTrack;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WildTrackApplicationTests {

	@Test
	void contextLoads() {
	}

}
